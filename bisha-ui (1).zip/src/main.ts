import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { provideHttpClient } from '@angular/common/http'; // Import for HttpClient
import { RouterModule } from '@angular/router'; // Import RouterModule
import { routes } from './app/app.routes'; // Import your routes
import { provideRouter } from '@angular/router'; // Import provideRouter
import { provideAnimations } from '@angular/platform-browser/animations';

// bootstrapApplication(AppComponent, appConfig)
//   .catch((err) => console.error(err));

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(), // Add this line to provide HttpClient
    provideRouter(routes), // Use provideRouter
    provideAnimations()
  ],
}).catch((err) => console.error(err));