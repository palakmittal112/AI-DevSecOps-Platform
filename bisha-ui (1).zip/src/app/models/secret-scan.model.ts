export interface SecretScan {
  _id: string;
  RuleID: string;
  Commit: string;
  File: string;
  Secret: string;
  Match: string;
  StartLine: number;
  EndLine: number;
  StartColumn: number;
  EndColumn: number;
  Author: string;
  Message: string;
  Date: string;
  Email: string;
  Fingerprint: string;
  branch: string;
  projectId: string;
  state: string;
  Tags: string;
  falsePositive: boolean;
  riskAccepted: boolean;
  notes: string;
  SymlinkFile: string;
}
