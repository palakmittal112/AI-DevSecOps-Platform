// src/app/models/user.model.ts

export interface RegistrationData {
    username: string;
    password: string;
    email: string;
    role: string;
    team: string;
    projects?: string[]; // projects is an array of ObjectId, can be optional
  }
  
  // You might also define a User interface for when you fetch user data
  // export interface User {
  //   _id: string;
  //   username: string;
  //   email: string;
  //   role: string;
  //   team: string;
  //   projects: string[];
  //   // Add other fields returned by your backend if any
  // }