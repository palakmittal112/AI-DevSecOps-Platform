export interface LoginResponse {
  token: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}
