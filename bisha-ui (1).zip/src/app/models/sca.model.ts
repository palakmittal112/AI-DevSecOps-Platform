// export interface Sca {
//   _id: string;
//   branchName: String,
//   packageName: String,
//   version: String,
//   ecosystem: String,
//   vulnerabilityId: String,
//   aliases: String,  // Alternative vulnerability identifiers (CVE, GHSA)
//   summary: String,
//   details: String,
//   severity: String,
//   affectedVersions: String,  // List of affected versions
//   identifiedDate: Date,  // Date when it was first published
//   lastUpdated: Date,  // Date when last modified
//   fixedVersion: String,  // Fixed version if available
//   references: String,  // External links (advisories, reports)
// }
export interface Sca {
  _id: string;
  branchName: string;
  packageName: string;
  version: string;
  ecosystem: string;
  vulnerabilityId: string;
  aliases: string; // Alternative vulnerability identifiers (CVE, GHSA)
  summary: string;
  details: string;
  severity: string;
  affectedVersions: string; // List of affected versions
  identifiedDate: Date; // Date when it was first published
  lastUpdated: Date; // Date when last modified
  fixedVersion: string; // Fixed version if available
  references: string; // External links (advisories, reports)
}
