export interface Hash {
  alg: string;
  content: string;
}

export interface License {
  license: {
    id: string;
  };
}

export interface EvidenceMethod {
  technique: string;
  confidence: number;
  value: string;
}

export interface Evidence {
  identity: {
    field: string;
    confidence: number;
    methods: EvidenceMethod[];
  };
}

export interface Property {
  name: string;
  value: string;
}

export interface RawData {
  group?: string;
  name: string;
  version: string;
  description?: string;
  scope?: string;
  purl: string;
  type: string;
  ['bom-ref']: string;
  hashes?: Hash[];
  licenses?: License[];
  evidence?: Evidence;
  properties?: Property[];
}

export interface SBOM {
  _id: string;
  project: string;
  branch: string;
  libraryName: string;
  version: string;
  license?: string;
  description?: string;
  purl: string;
  rawData: RawData;
  state: string;
  dependencies: string[];
  firstFound: string;
  lastUpdated: string;
  bomRef: string;
  __v?: number;
}
