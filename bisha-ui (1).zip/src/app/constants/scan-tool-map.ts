export type ReportTab = 'secretScan' | 'sca' | 'sast' | 'sbom';

export const TOOL_TO_TAB_MAP: Record<string, ReportTab> = {
  // Secret scanning tools
  gitleaks: 'secretScan',
  trivy: 'secretScan',
  'trivy-secret': 'secretScan',

  // Software Composition Analysis (SCA)
  osv: 'sca',
  trivy_vuln: 'sca',
  'trivy-vuln': 'sca',

  // Static Application Security Testing (SAST)
  semgrep: 'sast',

  // Software Bill of Materials
  sbom: 'sbom',
  'trivy-sbom': 'sbom'
};
