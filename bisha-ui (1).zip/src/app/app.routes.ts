// import { Routes } from '@angular/router';
// import { LoginComponent } from './components/login/login.component';
// import { LayoutComponent } from './components/layout/layout.component';
// import { HomeComponent } from './components/home/home.component';
// import { SecretScanComponent } from './components/secret-scan/secret-scan.component';
// import { SbomComponent } from './components/sbom/sbom.component';
// import { ProjectsPageComponent } from './components/projects-page/projects-page.component';
// import { ReportsPageComponent } from './components/reports-page/reports-page.component';
// import { ScaComponent } from './components/scacomponent/sca.component';
// import { RegistrationComponent } from './components/registration/registration.component';
// import { VulnerabilitiesPageComponent } from './components/vulnerabilites-page/vulnerabilities-page.component';

// export const routes: Routes = [
//     { path: '', redirectTo: '/login', pathMatch: 'full' },
//     { path: 'login', component: LoginComponent },
//     { path: 'secretScan', component: SecretScanComponent },
//     { path: 'register', component: RegistrationComponent },
//     { path: 'sbom', component: SbomComponent },
//     { path: 'sca', component: ScaComponent },
//     { path: 'projects', component: ProjectsPageComponent},
//     { path: 'reports', component: ReportsPageComponent },
//     { path: 'vulnerabilities/:id', component: VulnerabilitiesPageComponent},
//     { path: 'reports/:id', component: ReportsPageComponent },
//     { path: 'secret-scan/:projectId', component: SecretScanComponent },
//     { path: 'sbom/:projectId', component: SbomComponent },
//     { path: 'sca/:projectId', component: ScaComponent },
//     { path: 'osvReport', component: ScaComponent},
//     { path: '', component: LayoutComponent,
//         children: [
//             { path: 'home', component: HomeComponent }
//         ]
//     },
//     // { path: 'home', component: HomeComponent, canActivate: [AuthGuard] }
//   ];


import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { LayoutComponent } from './components/layout/layout.component';
import { HomeComponent } from './components/home/home.component';
import { SecretScanComponent } from './components/secret-scan/secret-scan.component';
import { SbomComponent } from './components/sbom/sbom.component';
import { ProjectsPageComponent } from './components/projects-page/projects-page.component';
import { ReportsPageComponent } from './components/reports-page/reports-page.component';
import { ScaComponent } from './components/scacomponent/sca.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { VulnerabilitiesPageComponent } from './components/vulnerabilites-page/vulnerabilities-page.component';

// ⭐ NEW IMPORT
import { SecurityComponent } from './components/security/security.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },

  { path: 'secretScan', component: SecretScanComponent },
  { path: 'register', component: RegistrationComponent },
  { path: 'sbom', component: SbomComponent },
  { path: 'sca', component: ScaComponent },

  { path: 'projects', component: ProjectsPageComponent },
  { path: 'reports', component: ReportsPageComponent },

  { path: 'vulnerabilities/:id', component: VulnerabilitiesPageComponent },
  { path: 'reports/:id', component: ReportsPageComponent },

  { path: 'secret-scan/:projectId', component: SecretScanComponent },
  { path: 'sbom/:projectId', component: SbomComponent },
  { path: 'sca/:projectId', component: ScaComponent },

  // ⭐ NEW SECURITY PAGE ROUTE
  { path: 'security/:id', component: SecurityComponent },

  {
    path: '',
    component: LayoutComponent,
    children: [{ path: 'home', component: HomeComponent }],
  }
];

