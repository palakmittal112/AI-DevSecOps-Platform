import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ChatWidgetComponent } from './components/chat-widget/chat-widget.component';
import { AuthService } from './services/auth.service';
 
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ChatWidgetComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'bisha-new';
  isAuthenticated = false;
 
  constructor(private auth: AuthService) {}
 
  ngOnInit() {
    // Check if user is authenticated
    this.isAuthenticated = !!this.auth.user && !!this.auth.token;
  }
}
 
 