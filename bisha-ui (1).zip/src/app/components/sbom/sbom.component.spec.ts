import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SbomComponent } from './sbom.component';

describe('SbomComponent', () => {
  let component: SbomComponent;
  let fixture: ComponentFixture<SbomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SbomComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SbomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
