import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatGridList, MatGridTile } from '@angular/material/grid-list';
import { SbomService } from '../../services/sbom.service';
import { SBOM } from '../../models/sbom.model';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderComponent } from '../header/header.component';

import { ActivatedRoute, Router } from '@angular/router'; // Import ActivatedRoute and Router
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';


@Component({
  selector: 'app-sbom',
  imports: [
    SideNavComponent,
    HeaderComponent,
    MatTableModule,
    MatPaginatorModule,
    //MatFormField,
   // MatLabel,
    //MatGridList,
    //MatGridTile,
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatSlideToggleModule
  ],
  templateUrl: './sbom.component.html',
  styleUrl: './sbom.component.css'
})
export class SbomComponent implements OnInit { // Implement OnInit

  displayedColumns: string[] = ['libraryName', 'version', 'bomRef', 'description', 'Actions'];
  dataSource = new MatTableDataSource<SBOM>([]);
  itemsPerPageOptions = [25, 50, 100];

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  projectId: string | null = null; // To store the project ID from the route

  constructor(
    private sbomService: SbomService,
    private route: ActivatedRoute, // Inject ActivatedRoute
    private router: Router // Inject Router for back navigation
  ) { }

  ngOnInit(): void { // Implement ngOnInit
    this.route.paramMap.subscribe(params => {
      this.projectId = params.get('projectId'); // Get 'projectId' from the route
      console.log('SBOM Component - Project ID received:', this.projectId);

      if (this.projectId) {
        this.fetchData(this.projectId); // Call fetchData with the dynamic projectId
      } else {
        console.error('SBOM Component: Project ID not found in route parameters.');
        // Optionally, redirect or show an error to the user
      }
    });
  }

  fetchData(projectId: string) { // Now accepts projectId
    this.sbomService.getSbom(projectId).subscribe( // Pass projectId to service
      (data) => {
        console.log("SBOM Data fetched:", data);
        this.dataSource.data = data;
        if (this.paginator) {
          this.dataSource.paginator = this.paginator;
        }
      },
      (error) => {
        console.error('Error fetching SBOM data:', error);
        // Handle error, e.g., display a message to the user
      }
    );
  }

  deleteSbom(id: string) {
    if (this.projectId) {
      this.sbomService.deleteSbom(id, this.projectId).subscribe(() => { // Pass projectId
        this.dataSource.data = this.dataSource.data.filter((item) => item._id !== id);
      },
      (error) => {
        console.error('Error deleting SBOM entry:', error);
      });
    } else {
      console.error('Cannot delete SBOM entry: Project ID is missing.');
    }
  }

  editSbom(sbom: SBOM) {
    console.log('Edit SBOM:', sbom);
    // Implement your edit logic here.
  }

  goBackToReports(): void {
    if (this.projectId) {
      this.router.navigate(['/reports', this.projectId]);
    } else {
      this.router.navigate(['/projects']); // Fallback
    }
  }
}
