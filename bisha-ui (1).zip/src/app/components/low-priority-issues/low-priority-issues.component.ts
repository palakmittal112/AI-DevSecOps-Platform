import { Component } from '@angular/core';

@Component({
  selector: 'app-low-priority-issues',
  imports: [],
  templateUrl: './low-priority-issues.component.html',
  styleUrl: './low-priority-issues.component.css'
})
export class LowPriorityIssuesComponent {

}
