import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LowPriorityIssuesComponent } from './low-priority-issues.component';

describe('LowPriorityIssuesComponent', () => {
  let component: LowPriorityIssuesComponent;
  let fixture: ComponentFixture<LowPriorityIssuesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LowPriorityIssuesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LowPriorityIssuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
