import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BaseChartDirective } from 'ng2-charts';
import { Chart, ChartData, ChartOptions, BarController, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend, ArcElement, PieController, DoughnutController } from 'chart.js';
import { DashboardService, VulnerabilitySummaryResponse, TotalCountsResponse } from '../../services/dashboard.service';
import { Subject, of } from 'rxjs';
import { takeUntil, debounceTime } from 'rxjs/operators';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderComponent } from '../header/header.component';
import { ChatComponent } from "../chat/chat.component";
import { AppUser, AuthService } from '../../services/auth.service';

Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
  PieController,
  DoughnutController,
  ArcElement
);

interface CategoryRow {
  name: string;
  critical: number;
  high: number;
  medium: number;
  low: number;
  total: number;
}

interface Project {
  id: string; // Changed to string for MongoDB ObjectID
  name: string;
}

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, FormsModule, BaseChartDirective, SideNavComponent, HeaderComponent],
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit, OnDestroy {
  @ViewChild('barChart') barChartRef!: BaseChartDirective;
  @ViewChild('pieChart') pieChartRef!: BaseChartDirective;

  private destroy$ = new Subject<void>();
  loggedInUser: AppUser | null = null;


  // Data
  summaryData: VulnerabilitySummaryResponse['data'] | null = null;
  totalData: TotalCountsResponse['data'] | null = null;
  categoryRows: CategoryRow[] = [];
  projects: Project[] = [];
  selectedProjectId: string | null = null; // Changed to string | null
  projectsLoading = false;
  projectsError = false;

  // Bar Chart (Security Findings)
  barChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  barChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: 'x',
    plugins: {
      legend: { display: false },
      title: { display: false }
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { size: 11 }, color: '#6b7280' },
        border: { display: false }
      },
      y: {
        beginAtZero: true,
        grid: { color: '#f3f4f6' },
        ticks: { font: { size: 11 }, color: '#6b7280', stepSize: 50 },
        border: { display: false },
        title: { display: true, text: 'Number of Findings', color: '#6b7280', font: { size: 12, weight: 500 } }
      }
    }
  };
  barChartType = 'bar' as const;

  // Pie Chart (Issues by Category)
  pieChartData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  pieChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        display: true,
        labels: {
          usePointStyle: false,
          padding: 12,
          font: { size: 11, family: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' },
          color: '#374151',
          generateLabels: (chart: any) => {
            const data = chart.data;
            if (data.labels.length && data.datasets.length) {
              return data.labels.map((label: string, i: number) => {
                const value = data.datasets[0].data[i];
                const total = data.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
                const percentage = ((value / total) * 100).toFixed(1);
                return {
                  text: `${label}: ${percentage}%`,
                  fillStyle: data.datasets[0].backgroundColor[i],
                  hidden: false,
                  index: i,
                  fontColor: '#374151'
                };
              });
            }
            return [];
          }
        }
      },
      title: { display: false },
      tooltip: {
        backgroundColor: '#1f2937',
        padding: 12,
        cornerRadius: 6,
        titleFont: { size: 13, weight: 600 },
        bodyFont: { size: 12 },
        callbacks: {
          label: (context: any) => {
            const label = context.label || '';
            const value = context.parsed;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = ((value / total) * 100).toFixed(1);
            return `${label}: ${value} (${percentage}%)`;
          }
        }
      }
    },
    cutout: '50%'
  };
  pieChartType = 'doughnut' as const;

  // UI State
  loading = true;
  isRefreshing = false;
  errorMessage = '';
  lastUpdated: Date | null = null;

  // constructor(private dashboardService: DashboardService) {}
  constructor(
  private dashboardService: DashboardService,
  private authService: AuthService   // <-- add this
) {}


  ngOnInit(): void {
    // Use the AuthService user (AuthService already loads from localStorage in its constructor)
    this.loggedInUser = this.authService.user || null;
    console.log("Logged-in user on dashboard:", this.loggedInUser);

    // Restore selected project from local storage
    const savedProjectId = localStorage.getItem('selectedProjectId');
    this.selectedProjectId = savedProjectId && savedProjectId !== 'null' ? savedProjectId : null;
    console.log('Restored selectedProjectId:', this.selectedProjectId, 'from saved:', savedProjectId);

    this.loadProjects();
    this.loadDashboardData();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Load list of projects for dropdown
   */
  private loadProjects(): void {
    this.projectsLoading = true;
    this.projectsError = false;
    console.log('Loading projects...');
    this.dashboardService.getProjects()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          // Map _id to id and validate
          this.projects = response.data
            .map(project => {
              if (!project._id || typeof project._id !== 'string') {
                console.warn(`Invalid project _id for project: ${project.name}, _id: ${project._id}`);
                return null;
              }
              return { id: project._id, name: project.name };
            })
            .filter((project): project is Project => project !== null);
          this.projectsLoading = false;
          console.log('Projects loaded:', this.projects);
          // Validate selectedProjectId
          if (this.selectedProjectId && !this.projects.some(p => p.id === this.selectedProjectId)) {
            console.warn('Selected project ID not found in projects, resetting to null');
            this.selectedProjectId = null;
            localStorage.setItem('selectedProjectId', '');
          }
          // Set default project for testing
          if (this.projects.length > 0 && this.selectedProjectId === null) {
            this.selectedProjectId = this.projects[0].id;
            localStorage.setItem('selectedProjectId', this.selectedProjectId);
            console.log('Set default projectId:', this.selectedProjectId);
            this.onProjectChange();
          }
        },
        error: (err) => {
          console.error('Error loading projects:', err);
          this.errorMessage = 'Failed to load projects. Showing overall data.';
          this.projectsError = true;
          this.projectsLoading = false;
          this.selectedProjectId = null;
          localStorage.setItem('selectedProjectId', '');
          console.log('Falling back to overall data due to projects error');
          this.loadDashboardData();
        }
      });
  }

  /**
   * Handle project selection change
   */
  onProjectChange(): void {
    console.log('Project selection changed to:', this.selectedProjectId, typeof this.selectedProjectId);
    if (this.selectedProjectId && typeof this.selectedProjectId !== 'string') {
      console.warn('Invalid selectedProjectId, resetting to null');
      this.selectedProjectId = null;
    }
    localStorage.setItem('selectedProjectId', this.selectedProjectId || '');
    of(this.selectedProjectId)
      .pipe(debounceTime(300), takeUntil(this.destroy$))
      .subscribe(() => this.loadDashboardData());
  }

  /**
   * Clear project filter
   */
  clearProjectFilter(): void {
    this.selectedProjectId = null;
    localStorage.setItem('selectedProjectId', '');
    console.log('Cleared project filter');
    this.onProjectChange();
  }

  /**
   * Load summary and total counts data
   */
  // loadDashboardData(): void {
  //   this.loading = true;
  //   this.errorMessage = this.projectsError ? 'Failed to load projects. Showing overall data.' : '';
  //   console.log('Loading dashboard data for projectId:', this.selectedProjectId || 'Overall');

  //   this.dashboardService.refreshAllData(this.selectedProjectId || undefined)
  //     .pipe(takeUntil(this.destroy$))
  //     .subscribe({
  //       next: ({ summary, counts }) => {
  //         console.log('Dashboard data loaded:', { summary, counts });
  //         this.summaryData = summary.data;
  //         this.totalData = counts.data;
  //         this.prepareCategoryRows();
  //         this.prepareBarChart();
  //         this.preparePieChart();
  //         this.loading = false;
  //         this.lastUpdated = new Date();
  //       },
  //       error: (err) => {
  //         console.error('Error loading dashboard:', err);
  //         this.errorMessage = err.message.includes('401')
  //           ? 'Unauthorized: Please login again.'
  //           : 'Failed to load dashboard data. Please try again.';
  //         this.loading = false;
  //       }
  //     });
  // }

  // loadDashboardData(): void {
  //   this.loading = true;
  //   this.errorMessage = this.projectsError
  //     ? 'Failed to load projects. Showing overall data.'
  //     : '';

  //   console.log(
  //     'Loading dashboard data for projectId:',
  //     this.selectedProjectId || 'Overall'
  //   );

  //   /* ----------------------------------------------------
  //     🔥 CASE 1: NO PROJECT SELECTED → GLOBAL DASHBOARD
  //   ---------------------------------------------------- */
  //   if (!this.selectedProjectId) {
  //     this.dashboardService.getGlobalSeveritySummary()
  //       .pipe(takeUntil(this.destroy$))
  //       .subscribe(res => {
  //         this.summaryData = res.data;

  //         const totals: any = {};
  //         let grandTotal = 0;

  //         Object.entries(res.data).forEach(([scan, sev]: any) => {
  //           const sum =
  //             sev.CRITICAL + sev.HIGH + sev.MEDIUM + sev.LOW;
  //           totals[scan] = sum;
  //           grandTotal += sum;
  //         });

  //         totals['Total Vulnerabilities'] = grandTotal;
  //         this.totalData = totals;

  //         this.prepareCategoryRows();
  //         this.prepareBarChart();
  //         this.preparePieChart();

  //         this.loading = false;
  //         this.lastUpdated = new Date();
  //       });

  //     return;
  //   }

  //   /* ----------------------------------------------------
  //     🔥 CASE 2: PROJECT SELECTED → EXISTING FLOW
  //   ---------------------------------------------------- */
  //   this.dashboardService.refreshAllData(this.selectedProjectId)
  //     .pipe(takeUntil(this.destroy$))
  //     .subscribe({
  //       next: ({ summary, counts }) => {
  //         console.log('Project dashboard data loaded:', { summary, counts });

  //         this.summaryData = summary.data;
  //         this.totalData = counts.data;

  //         this.prepareCategoryRows();
  //         this.prepareBarChart();
  //         this.preparePieChart();

  //         this.loading = false;
  //         this.lastUpdated = new Date();
  //       },
  //       error: (err) => {
  //         console.error('Error loading dashboard:', err);
  //         this.errorMessage = err.message?.includes('401')
  //           ? 'Unauthorized: Please login again.'
  //           : 'Failed to load dashboard data. Please try again.';
  //         this.loading = false;
  //       }
  //     });
  // }

  loadDashboardData(): void {
    this.loading = true;
    this.errorMessage = '';

    console.log('Loading GLOBAL dashboard data');

    this.dashboardService.getGlobalSeveritySummary()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.summaryData = res.data;

          const totals: any = {};
          let grandTotal = 0;

          Object.entries(res.data).forEach(([scan, sev]: any) => {
            const sum =
              (sev.CRITICAL || 0) +
              (sev.HIGH || 0) +
              (sev.MEDIUM || 0) +
              (sev.LOW || 0);

            totals[scan] = sum;
            grandTotal += sum;
          });

          totals['Total Vulnerabilities'] = grandTotal;
          this.totalData = totals;

          this.prepareCategoryRows();
          this.prepareBarChart();
          this.preparePieChart();

          this.loading = false;
          this.lastUpdated = new Date();
        },
        error: (err) => {
          console.error('Global dashboard error:', err);
          this.errorMessage = 'Failed to load global dashboard data.';
          this.loading = false;
        }
      });
  }

    complianceChartData: ChartData<'bar'> = {
    labels: ['ISO 27001', 'EISHA', 'ASVS', 'CIS Benchmark'],
    datasets: [
      {
        label: 'Compliant',
        data: [12, 8, 15, 10],
        // one color per label (same index)
        backgroundColor: ['#22c55e', '#22c55e', '#22c55e', '#22c55e'],
        borderRadius: 6,
        barThickness: 35,
        stack: 'stack1'
      },
      {
        label: 'Non-Compliant',
        data: [3, 7, 4, 6],
        backgroundColor: ['#ef4444', '#ef4444', '#ef4444', '#ef4444'],
        borderRadius: 6,
        barThickness: 35,
        stack: 'stack1'
      }
    ]
  };

  complianceChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: 'y',
    plugins: {
      legend: {
        position: 'top',
        labels: { font: { size: 12 } }
      },
      title: {
        display: true,
        text: 'Compliance Overview by Standard',
        font: { size: 14, weight: 600 }
      },
      tooltip: {
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${ctx.parsed.x ?? ctx.parsed}`
        }
      }
    },
    scales: {
      x: { ticks: { font: { size: 11 } }, grid: { display: false }, stacked: true },
      y: { beginAtZero: true, ticks: { font: { size: 11 } }, grid: { color: '#e5e7eb' }, stacked: true, title: { display: true, text: 'Count' } }
    }
  };


  /**
   * Prepare bar chart for Security Findings by scan type
   */
  private prepareBarChart(): void {
    if (!this.totalData) return;


    const categories = Object.keys(this.totalData)
    .filter(k => k !== 'Total Vulnerabilities' && k !== 'SBOM');

    const counts = categories.map(cat => this.totalData![cat]);

    const colors = categories.map(cat => this.getScanTypeColor(cat));

    this.barChartData = {
      labels: categories,
      datasets: [
        {
          label: '',
          data: counts,
          backgroundColor: colors,
          borderColor: '#3b82f6',
          borderWidth: 0,
          borderRadius: 4,
          barThickness: 40
        }
      ]
    };

    setTimeout(() => {
      if (this.barChartRef) {
        this.barChartRef.chart?.update('none');
      }
    }, 0);
  }

  /**
   * Prepare pie chart for Issues by Category
   */
  private preparePieChart(): void {
    if (!this.totalData) return;

    const labels = Object.keys(this.totalData)
    .filter(k => k !== 'Total Vulnerabilities' && k !== 'SBOM');

    const values = labels.map(k => this.totalData![k]);

    const chartColors = labels.map(label => this.getScanTypeColor(label));

    this.pieChartData = {
      labels,
      datasets: [
        {
          data: values,
          backgroundColor: chartColors.slice(0, labels.length),
          borderColor: '#ffffff',
          borderWidth: 2,
          hoverBorderWidth: 3,
          hoverBorderColor: '#ffffff'
        }
      ]
    };

    setTimeout(() => {
      if (this.pieChartRef) {
        this.pieChartRef.chart?.update('none');
      }
    }, 0);
  }

  /**
   * Prepare category rows for summary table
   */
  private prepareCategoryRows(): void {
    if (!this.summaryData) return;

    this.categoryRows = Object.entries(this.summaryData).map(([category, severities]) => {
      const critical = (severities as any)['CRITICAL'] || 0;
      const high = (severities as any)['HIGH'] || 0;
      const medium = (severities as any)['MEDIUM'] || 0;
      const low = (severities as any)['LOW'] || 0;

      return {
        name: category,
        critical,
        high,
        medium,
        low,
        total: critical + high + medium + low
      };
    });
    console.log('Category rows prepared:', this.categoryRows);
  }

  /**
   * Generates colors for new scan types
   */
  private getScanTypeColor(scanType: string): string {
    const colorMap: { [key: string]: string } = {
      'CS Scan': '#1F77B4',
      'SCA': '#FF7F0E',
      'Secret Scan': '#2CA02C',
      'SAST': '#D62728',
      'DAST': '#9467BD',
      'SBOM': '#8C564B',
      'IaC Scan': '#E377C2',
      'Cloud Posture': '#17A2B8',
      'KAST': '#6F42C1'
    };

    return colorMap[scanType] || this.generateColorFromString(scanType);
  }

  /**
   * Generate a deterministic color from a string
   */
  private generateColorFromString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }

    const hue = Math.abs(hash) % 360;
    const saturation = 70 + (Math.abs(hash) % 20);
    const lightness = 50;

    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }

  /**
   * Get severity color
   */
  getSeverityColor(severity: string): string {
    const colorMap: { [key: string]: string } = {
      'CRITICAL': '#D62728',
      'HIGH': '#FF7F0E',
      'MEDIUM': '#FFC700',
      'LOW': '#2CA02C'
    };
    return colorMap[severity] || '#666';
  }

  /**
   * Get total vulnerabilities
   */
  getTotalVulnerabilities(): number {
    return this.totalData?.['Total Vulnerabilities'] || 0;
  }

  /**
   * Get total count for a specific severity
   */
  getSeverityCount(severity: string): number {
    if (!this.summaryData) return 0;
    return Object.values(this.summaryData).reduce((sum, severities) => sum + (severities[severity] || 0), 0);
  }

  /**
   * Manual refresh dashboard
   */
  // refreshDashboard(): void {
  //   if (this.isRefreshing) return;
  //   this.isRefreshing = true;
  //   this.dashboardService.clearCache();
  //   console.log('Refreshing dashboard for projectId:', this.selectedProjectId || 'Overall');

  //   this.dashboardService.refreshAllData(this.selectedProjectId || undefined)
  //     .pipe(takeUntil(this.destroy$))
  //     .subscribe({
  //       next: ({ summary, counts }) => {
  //         console.log('Refresh response:', { summary, counts });
  //         this.summaryData = summary.data;
  //         this.totalData = counts.data;
  //         this.prepareCategoryRows();
  //         this.prepareBarChart();
  //         this.preparePieChart();
  //         this.lastUpdated = new Date();
  //         this.isRefreshing = false;
  //       },
  //       error: (err) => {
  //         console.error('Error refreshing dashboard:', err);
  //         this.errorMessage = 'Failed to refresh dashboard data.';
  //         this.isRefreshing = false;
  //       }
  //     });
  // }

  refreshDashboard(): void {
    if (this.isRefreshing) return;

    this.isRefreshing = true;
    this.dashboardService.clearCache();

    this.dashboardService.getGlobalSeveritySummary()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.summaryData = res.data;

          const totals: any = {};
          let total = 0;

          Object.entries(res.data).forEach(([k, v]: any) => {
            const sum = v.CRITICAL + v.HIGH + v.MEDIUM + v.LOW;
            totals[k] = sum;
            total += sum;
          });

          totals['Total Vulnerabilities'] = total;
          this.totalData = totals;

          this.prepareCategoryRows();
          this.prepareBarChart();
          this.preparePieChart();

          this.lastUpdated = new Date();
          this.isRefreshing = false;
        },
        error: () => {
          this.errorMessage = 'Failed to refresh global dashboard.';
          this.isRefreshing = false;
        }
      });
  }


  /**
   * Get last updated time
   */
  getLastUpdatedTime(): string {
    if (!this.lastUpdated) return 'Never';

    const now = new Date();
    const diff = Math.floor((now.getTime() - this.lastUpdated.getTime()) / 1000);

    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  }

  /**
   * Track by function for ngFor
   */
  trackByName(index: number, item: CategoryRow): string {
    return item.name;
  }

  /**
   * Track by function for projects ngFor
   */
  trackByProjectId(index: number, item: Project): string {
    return item.id;
  }
}
