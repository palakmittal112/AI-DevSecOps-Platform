// src/app/registration/registration.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { RegistrationData } from '../../models/user.model'; // Import the interface
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm!: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      role: ['project_user', Validators.required],
      team: ['default_team', Validators.required],
      projects: [[]] // Default empty array for new registrations
    });
  }

  onSubmit(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (this.registrationForm.valid) {
      // Cast the form value to your interface for type safety
      const userData: RegistrationData = this.registrationForm.value;

      this.authService.register(userData).subscribe(
        response => {
          this.successMessage = 'Registration successful! You can now log in.';
          console.log('Registration successful:', response);
          this.router.navigate(['/login']);
        },
        error => {
          this.errorMessage = error.error.message || 'Registration failed. Please try again.';
          console.error('Registration failed:', error);
        }
      );
    } else {
      this.errorMessage = 'Please fill out all required fields correctly.';
      this.registrationForm.markAllAsTouched();
    }
  }
}