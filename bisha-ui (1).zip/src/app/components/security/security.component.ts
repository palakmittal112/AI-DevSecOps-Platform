import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SideNavComponent } from "../side-nav/side-nav.component";
import { HeaderComponent } from "../header/header.component";

@Component({
  selector: 'app-security',
  standalone: true,
  imports: [CommonModule, SideNavComponent, HeaderComponent],
  templateUrl: './security.component.html',
  styleUrl: './security.component.css'
})
export class SecurityComponent {

  projectId: string | null = null;

  constructor(private route: ActivatedRoute) {
    this.projectId = this.route.snapshot.paramMap.get('id');
  }

  securityTopics = [
    {
      title: 'Secure Design',
      icon: 'architecture',
      color: '#1e88e5',
      open: false,
      children: ['Threat and Risk Analysis', 'Residual Risk Tracker']
    },
    {
      title: 'Secure Implementation',
      icon: 'construction',
      color: '#43a047',
      open: false,
      children: ['Security Concept']
    },
    {
      title: 'Secure Validation & Verification',
      icon: 'verified',
      color: '#fb8c00',
      open: false,
      children: [
        'Vulnerability Management',
        'Compliance Management',
        'Penetration Testing Results'
      ]
    },
    {
      title: 'Secure Maintenance',
      icon: 'build_circle',
      color: '#8e24aa',
      open: false,
      children: [
        'Vulnerability Management',
        'SBOM Dashboard',
        'Compliance Management',
        'Change Management'
      ]
    },
    {
      title: 'Secure Decommissioning',
      icon: 'delete_forever',
      color: '#e53935',
      open: false,
      children: ['Decommissioning Concept']
    }
  ];

  toggleTopic(topic: any) {
    topic.open = !topic.open;
  }
}
