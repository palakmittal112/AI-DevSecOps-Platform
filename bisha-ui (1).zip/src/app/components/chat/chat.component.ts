// import { Component, ElementRef, ViewChild } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { MatButtonModule } from '@angular/material/button';
// import { MatIconModule } from '@angular/material/icon';
// import { MatInputModule } from '@angular/material/input';
// import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
// import { ChatService } from '../../services/chat.service';

// interface ChatMessage { sender: 'user' | 'bot'; text: string; }

// @Component({
//   selector: 'app-chat',
//   standalone: true,
//   imports: [
//     CommonModule,
//     FormsModule,
//     MatButtonModule,
//     MatIconModule,
//     MatInputModule,
//     MatProgressSpinnerModule
//   ],
//   templateUrl: './chat.component.html',
//   styleUrls: ['./chat.component.css']
// })
// export class ChatComponent {
//   @ViewChild('chatWindow', { static: false }) chatWindow!: ElementRef;
//   messages: ChatMessage[] = [];
//   userInput = '';
//   loading = false;

//   constructor(private chatService: ChatService) {}

//   sendMessage() {
//   const text = this.userInput.trim();
//   if (!text) return;

//   // Push user message
//   this.messages.push({ sender: 'user', text });
//   this.userInput = '';
//   this.loading = true;
//   this.scrollToBottom();

//   // Call backend
//   this.chatService.sendMessage(text).subscribe({
//     next: (res) => {
//       const reply = (res && (res.reply ?? res)) || 'No reply';
//       this.loading = false;

//       // Push an empty bot message first
//       this.messages.push({ sender: 'bot', text: '' });

//       // Type the reply word by word
//       this.typeBotResponse(reply);
//     },
//     error: (err) => {
//       console.error('Chat error', err);
//       this.loading = false;
//       this.messages.push({
//         sender: 'bot',
//         text: '❌ Error communicating with server.'
//       });
//       this.scrollToBottom();
//     }
//   });
// }

// /** Animates the bot’s reply word by word */
// private typeBotResponse(fullText: string) {
//   const words = fullText.split(' ');
//   const index = this.messages.length - 1;

//   let i = 0;
//   const interval = setInterval(() => {
//     if (i < words.length) {
//       this.messages[index].text += (i === 0 ? '' : ' ') + words[i];
//       this.scrollToBottom();
//       i++;
//     } else {
//       clearInterval(interval);
//     }
//   }, 40); // typing speed in ms (lower = faster)
// }


//   private scrollToBottom() {
//     setTimeout(() => {
//       const el = this.chatWindow?.nativeElement;
//       if (el) el.scrollTop = el.scrollHeight;
//     }, 50);
//   }
// }

import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ChatService } from '../../services/chat.service';

interface ChatMessage { sender: 'user' | 'bot'; text: string; }

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
  @ViewChild('chatWindow', { static: false }) chatWindow!: ElementRef;

  messages: ChatMessage[] = [];
  userInput = '';
  loading = false;

  // typing speed in ms per word
  private typingSpeed = 40;

  constructor(private chatService: ChatService) {}

  sendMessage() {
    const text = this.userInput.trim();
    if (!text) return;

    // push user message
    this.messages.push({ sender: 'user', text });
    this.userInput = '';
    this.loading = true;
    this.scrollToBottom();

    this.chatService.sendMessage(text).subscribe({
      next: (res) => {
        const reply = res?.reply ?? 'No reply';
        this.loading = false;

        // add placeholder bot message
        this.messages.push({ sender: 'bot', text: '' });
        this.typeBotResponse(reply);
      },
      error: (err) => {
        console.error('Chat error', err);
        this.loading = false;
        this.messages.push({ sender: 'bot', text: '❌ Error communicating with server.' });
        this.scrollToBottom();
      }
    });
  }

  private typeBotResponse(fullText: string) {
    const words = fullText.split(' ');
    const idx = this.messages.length - 1; // index of placeholder
    let i = 0;

    const interval = setInterval(() => {
      if (i < words.length) {
        // append word (with space if not first)
        this.messages[idx].text += (i === 0 ? '' : ' ') + words[i];
        this.scrollToBottom();
        i++;
      } else {
        clearInterval(interval);
      }
    }, this.typingSpeed);
  }

  private scrollToBottom() {
    setTimeout(() => {
      try {
        const el = this.chatWindow?.nativeElement;
        if (el) el.scrollTop = el.scrollHeight;
      } catch (e) {}
    }, 60);
  }
}

