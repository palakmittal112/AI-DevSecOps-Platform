import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScaComponent } from './sca.component';

describe('ScacomponentComponent', () => {
  let component: ScaComponent;
  let fixture: ComponentFixture<ScaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ScaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
