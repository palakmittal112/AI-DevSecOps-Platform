// import { Component, OnInit, ViewChild } from '@angular/core';
// import { MatTableDataSource, MatTableModule } from '@angular/material/table';
// import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
// import { MatButtonModule } from '@angular/material/button';
// import { MatIconModule } from '@angular/material/icon';
// import { MatFormField, MatLabel } from '@angular/material/form-field';
// import { FormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { MatGridList, MatGridTile } from '@angular/material/grid-list';
// import { ScaService } from '../../services/sca.service';
// import { Sca } from '../../models/sca.model';

// import { ActivatedRoute, Router } from '@angular/router'; // Import ActivatedRoute and Router
// import { MatInputModule } from '@angular/material/input';
// import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatSlideToggleModule } from '@angular/material/slide-toggle';


// @Component({
//   selector: 'app-sca',
//   imports: [
//     MatTableModule,
//     MatPaginatorModule,
//     //MatFormField,
//    // MatLabel,
//     //MatGridList,
//     //MatGridTile,
//     CommonModule,
//     FormsModule,
//     MatButtonModule,
//     MatIconModule,
//     MatInputModule,
//     MatCheckboxModule,
//     MatSlideToggleModule
//   ],
//   templateUrl: './sca.component.html',
//   styleUrl: './sca.component.css'
// })
// export class ScaComponent implements OnInit { // Implement OnInit

//   displayedColumns: string[] = ['packageName', 'version', 'vulnerabilityId', 'summary', 'fixedVersion'];
//   dataSource = new MatTableDataSource<Sca>([]);
//   itemsPerPageOptions = [25, 50, 100];

//   @ViewChild(MatPaginator) paginator!: MatPaginator;

//   projectId: string | null = null; // To store the project ID from the route

//   constructor(
//     private scaService: ScaService,
//     private route: ActivatedRoute, // Inject ActivatedRoute
//     private router: Router // Inject Router for back navigation
//   ) { }

//   ngOnInit(): void { // Implement ngOnInit
//     this.route.paramMap.subscribe(params => {
//       this.projectId = params.get('projectId'); // Get 'projectId' from the route
//       console.log('Sca Component - Project ID received:', this.projectId);

//       if (this.projectId) {
//         this.fetchData(this.projectId); // Call fetchData with the dynamic projectId
//       } else {
//         console.error('Sca Component: Project ID not found in route parameters.');
//         // Optionally, redirect or show an error to the user
//       }
//     });
//   }

//   fetchData(projectId: string) { // Now accepts projectId
//     this.scaService.getSca(projectId).subscribe( // Pass projectId to service
//       (data) => {
//         console.log("Sca Data fetched:", data);
//         this.dataSource.data = data;
//         if (this.paginator) {
//           this.dataSource.paginator = this.paginator;
//         }
//       },
//       (error) => {
//         console.error('Error fetching Sca data:', error);
//         // Handle error, e.g., display a message to the user
//       }
//     );
//   }

//   deleteSca(id: string) {
//     if (this.projectId) {
//       this.scaService.deleteSca(id, this.projectId).subscribe(() => { // Pass projectId
//         this.dataSource.data = this.dataSource.data.filter((item) => item._id !== id);
//       },
//       (error) => {
//         console.error('Error deleting Sca entry:', error);
//       });
//     } else {
//       console.error('Cannot delete Sca entry: Project ID is missing.');
//     }
//   }

//   editSca(sca: Sca) {
//     console.log('Edit SCA:', sca);
//     // Implement your edit logic here.
//   }

//   goBackToReports(): void {
//     if (this.projectId) {
//       this.router.navigate(['/reports', this.projectId]);
//     } else {
//       this.router.navigate(['/projects']); // Fallback
//     }
//   }
// }
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ScaService } from '../../services/sca.service';
import { Sca } from '../../models/sca.model';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderComponent } from '../header/header.component';

import { ActivatedRoute, Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';


@Component({
  selector: 'app-sca',
  imports: [
    SideNavComponent,
    HeaderComponent,
    MatTableModule,
    MatPaginatorModule,
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatSlideToggleModule
  ],
  templateUrl: './sca.component.html',
  styleUrl: './sca.component.css'
})
export class ScaComponent implements OnInit {

  displayedColumns: string[] = ['packageName', 'version', 'vulnerabilityId', 'summary', 'fixedVersion'];
  dataSource = new MatTableDataSource<Sca>([]);
  itemsPerPageOptions = [25, 50, 100];

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  projectId: string | null = null;

  constructor(
    private scaService: ScaService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.projectId = params.get('projectId');
      console.log('Sca Component - Project ID received:', this.projectId);

      if (this.projectId) {
        this.fetchData(this.projectId);
      } else {
        console.error('Sca Component: Project ID not found in route parameters.');
      }
    });
  }

  fetchData(projectId: string) {
    this.scaService.getSca(projectId).subscribe(
      (data) => {
        console.log("Sca Data fetched:", data);
        this.dataSource.data = data; // Directly assign data as it's a direct array
        if (this.paginator) {
          this.dataSource.paginator = this.paginator;
        }
      },
      (error) => {
        console.error('Error fetching Sca data:', error);
      }
    );
  }

  deleteSca(id: string) {
    if (this.projectId) {
      this.scaService.deleteSca(id, this.projectId).subscribe(() => {
        this.dataSource.data = this.dataSource.data.filter((item) => item._id !== id);
      },
      (error) => {
        console.error('Error deleting Sca entry:', error);
      });
    } else {
      console.error('Cannot delete Sca entry: Project ID is missing.');
    }
  }

  editSca(sca: Sca) {
    console.log('Edit SCA:', sca);
  }

  goBackToReports(): void {
    if (this.projectId) {
      this.router.navigate(['/reports', this.projectId]);
    } else {
      this.router.navigate(['/projects']);
    }
  }
}
