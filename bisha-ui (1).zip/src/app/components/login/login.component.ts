import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
 
@Component({
  selector: 'app-login',
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 
  userName = '';
  password = '';
  errorMessage = '';
  showErrorMessage = false;
 
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}
 
  login(loginForm: NgForm): void {
    if (loginForm.invalid) {
      this.errorMessage = 'Please enter both username and password.';
      this.showErrorMessageTemporarily();
      return;
    }
 
    this.errorMessage = '';
 
    this.authService.login({
      username: this.userName,
      password: this.password,
    })
    .subscribe({
      next: (res) => {
        console.log('Login successful:', res);
        // AuthService automatically stored token + user into localStorage
        this.router.navigate(['/home']);
      },
      error: (err) => {
        console.error('Login error:', err);
        this.errorMessage = err.error?.message || 'Login failed.';
        this.showErrorMessageTemporarily();
      }
    });
  }
 
  private showErrorMessageTemporarily(): void {
    this.showErrorMessage = true;
    setTimeout(() => {
      this.showErrorMessage = false;
      this.errorMessage = ''; // Optionally clear the message after it disappears
    }, 5000); // Adjust the time in milliseconds (e.g., 5000 for 5 seconds)
  }
}
 
 
 
 
 
 