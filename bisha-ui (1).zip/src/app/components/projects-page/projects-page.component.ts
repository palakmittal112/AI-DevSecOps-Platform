// import { Component, OnInit } from '@angular/core';
// import { ProjectService } from '../../services/project.service';
// import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { RouterModule, Router } from '@angular/router'; // Import Router
// import { CommonModule } from '@angular/common';

// interface Project {
//   _id: string;
//   name: string;
// }

// @Component({
//   selector: 'app-projects-page',
//   templateUrl: './projects-page.component.html',
//   styleUrls: ['./projects-page.component.css'],
//   standalone: true,
//   imports: [RouterModule, CommonModule, ReactiveFormsModule],
// })
// export class ProjectsPageComponent implements OnInit {
//   projects: Project[] = [];
//   showCreateModal = false;
//   createProjectForm: FormGroup;
//   selectedProjectDetails: any = null; // KEPT: For showing details in a modal

//   constructor(
//     private projectService: ProjectService,
//     private fb: FormBuilder,
//     private router: Router // ADDED: Inject Router
//   ) {
//     this.createProjectForm = this.fb.group({
//       name: ['', Validators.required]
//     });
//   }

//   ngOnInit(): void {
//     this.loadProjects();
//   }

//   loadProjects(): void {
//     this.projectService.getAllProjects().subscribe(
//       (response) => {
//         this.projects = response.data;
//       },
//       (error) => {
//         console.error('Error loading projects:', error);
//       }
//     );
//   }

//   openCreateModal(): void {
//     this.showCreateModal = true;
//     this.createProjectForm.reset();
//   }

//   closeCreateModal(): void {
//     this.showCreateModal = false;
//   }

//   onCreateProject(): void {
//     if (this.createProjectForm.valid) {
//       const projectName = this.createProjectForm.get('name')?.value;

//       this.projectService.createProject(projectName).subscribe(
//         (response) => {
//           const newProject = response.data;
//           this.projects.push(newProject);
//           this.closeCreateModal();
//         },
//         (error) => {
//           console.error('Error creating project:', error);
//         }
//       );
//     }
//   }

//   /**
//    * Shows project details in a modal (existing functionality).
//    * @param project The project object to show details for.
//    */
//   showProjectDetails(project: Project): void { // KEPT: Original method for modal
//     this.projectService.getProjectDetails(project._id).subscribe(
//       (details) => {
//         this.selectedProjectDetails = details;
//       },
//       (error) => {
//         console.error('Error fetching project details:', error);
//       }
//     );
//   }

//   /**
//    * Closes the project details modal (existing functionality).
//    */
//   closeProjectDetails(): void { // KEPT: Original method for modal
//     this.selectedProjectDetails = null;
//   }

//   /**
//    * Navigates to the reports page for the selected project.
//    * This is the NEW method for redirection.
//    * @param project The project object to navigate for.
//    */
//   goToReportsPage(project: Project): void { // ADDED: New method for navigation
//     this.router.navigate(['/reports', project._id]);
//   }
// }

import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../../services/project.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderComponent } from '../header/header.component';

interface Project {
  _id: string;
  name: string;
}

interface SeveritySummary {
  critical: number;
  high: number;
  medium: number;
  low: number;
}

interface ScanResult {
  type: string;
  vulnerabilities: number;
  lastScanned: string;
}

@Component({
  selector: 'app-projects-page',
  templateUrl: './projects-page.component.html',
  styleUrls: ['./projects-page.component.css'],
  standalone: true,
  imports: [
    RouterModule,
    CommonModule,
    ReactiveFormsModule,
    SideNavComponent,
    HeaderComponent
  ],
})
export class ProjectsPageComponent implements OnInit {
  projects: Project[] = [];
  showCreateModal = false;
  createProjectForm: FormGroup;
  selectedProjectDetails: any = null;
  projectSeverity: Record<string, SeveritySummary> = {};

  projectScans: Record<string, ScanResult[]> = {};

  constructor(
    private projectService: ProjectService,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.createProjectForm = this.fb.group({
      name: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadProjects();
  }

  loadProjects(): void {
    this.projectService.getAllProjects().subscribe(
      (response) => {
        this.projects = response.data;
        console.log('Projects loaded:', this.projects);

        // Fetch severity summary for each project
        this.projects.forEach(project => {
          this.projectService.getProjectSeveritySummary(project._id).subscribe(
            (response) => {
              console.log('Severity response for project', project._id, ':', response);

              // Extract the data object from the response
              if (response && response.data) {
                this.projectSeverity[project._id] = {
                  critical: response.data.critical || 0,
                  high: response.data.high || 0,
                  medium: response.data.medium || 0,
                  low: response.data.low || 0
                };
              } else {
                // Fallback if response structure is different
                this.projectSeverity[project._id] = {
                  critical: 0,
                  high: 0,
                  medium: 0,
                  low: 0
                };
              }

              console.log('Project severity updated:', this.projectSeverity);
            },
            (error) => {
              console.error('Error fetching severity summary for project:', project._id, error);
              // Set default values on error
              this.projectSeverity[project._id] = {
                critical: 0,
                high: 0,
                medium: 0,
                low: 0
              };
            }
          );
        });
      },
      (error) => {
        console.error('Error loading projects:', error);
      }
    );
  }

  openCreateModal(): void {
    this.showCreateModal = true;
    this.createProjectForm.reset();
  }

  closeCreateModal(): void {
    this.showCreateModal = false;
  }

  onCreateProject(): void {
    if (this.createProjectForm.valid) {
      const projectName = this.createProjectForm.get('name')?.value;

      this.projectService.createProject(projectName).subscribe(
        (response) => {
          const newProject = response.data;
          this.projects.push(newProject);
          this.closeCreateModal();

          // Initialize severity counts for the new project
          this.projectSeverity[newProject._id] = {
            critical: 0,
            high: 0,
            medium: 0,
            low: 0
          };
        },
        (error) => {
          console.error('Error creating project:', error);
        }
      );
    }
  }

  showProjectDetails(project: Project): void {
    this.projectService.getProjectDetails(project._id).subscribe(
      (details) => {
        this.selectedProjectDetails = details;
      },
      (error) => {
        console.error('Error fetching project details:', error);
      }
    );
  }

  closeProjectDetails(): void {
    this.selectedProjectDetails = null;
  }

  // goToReportsPage(project: Project): void {
  //   this.router.navigate(['/vulnerabilities', project._id]);
  // }
  goToProjectSecurityPage(project: Project): void {
  this.router.navigate(['/security', project._id]);
}


  // Helper method to check if severity data is loaded
  hasSeverityData(projectId: string): boolean {
    return !!this.projectSeverity[projectId];
  }

  // Helper method to get total vulnerabilities for a project
  getTotalVulnerabilities(projectId: string): number {
    const severity = this.projectSeverity[projectId];
    if (!severity) return 0;
    return severity.critical + severity.high + severity.medium + severity.low;
  }

  getCurrentDate(): string {
    const today = new Date();
    return today.toLocaleDateString(); // or use toISOString().slice(0,10) for yyyy-mm-dd
  }

}
