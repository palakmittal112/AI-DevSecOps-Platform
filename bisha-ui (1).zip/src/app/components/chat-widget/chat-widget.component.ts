import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthService, AppUser } from '../../services/auth.service';

interface ChatMessage {
  from: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.css'],
})
export class ChatWidgetComponent implements OnInit, AfterViewChecked {
  @ViewChild('messagesContainer') messagesContainer!: ElementRef<HTMLDivElement>;

  isOpen = false;
  input = '';
  messages: ChatMessage[] = [];
  typing = false;

  user: AppUser | null = null;
  sessionId: string = 'session-' + Date.now();
  activeTab: 'home' | 'messages' | 'help' = 'messages';


  // 👉 Your n8n chat webhook
  private n8nChatUrl =
    'https://wme1cob.app.n8n.cloud/webhook/32f1b61c-d1ca-408d-8de4-6c9fb3e87f38/chat';

  constructor(
    private auth: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    // Get logged-in user from AuthService (already loads from localStorage)
    this.user = this.auth.user;

    // Optional: system greeting in message list (not from n8n)
    if (this.user) {
      this.messages.push({
        from: 'bot',
        text: `Hi ${this.user.username}! 👋\nHow can I help you with your projects today?`,
        timestamp: new Date(),
      });
    } else {
      this.messages.push({
        from: 'bot',
        text: `Hi there! 👋\nHow can help you with your projects.`,
        timestamp: new Date(),
      });
    }
  }

  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }

  toggleChat(): void {
    this.isOpen = !this.isOpen;

     if (this.isOpen) {
    this.activeTab = 'home';
  }
  }

  send(): void {
    const text = this.input.trim();
    if (!text) return;

    // Show user's message in UI
    this.messages.push({ from: 'user', text, timestamp: new Date() });
    this.input = '';
    this.typing = true;

    // Build payload for n8n chat trigger
    const body: any = {
      action: 'sendMessage',      // required for n8n Chat Trigger
      chatInput: text,            // message text
      sessionId: this.sessionId,  // keep same session across messages
    };

    // Attach user metadata if available
    if (this.user) {
      body.metadata = {
        userId: this.user._id,
        username: this.user.username,
        email: this.user.email,
        role: this.user.role,
        team: this.user.team,
      };
    }

    this.http.post(this.n8nChatUrl, body).subscribe({
      next: (resp: any) => {
        console.log('🔥 RAW RESPONSE FROM N8N:', resp);
        this.typing = false;

        let botText = '';

        // CASE 1 — Standard n8n Chat Trigger response
        if (resp?.messages && Array.isArray(resp.messages)) {
          resp.messages.forEach((m: any) => {
            const replyText =
              typeof m?.text === 'string' ? m.text : JSON.stringify(m);
            this.messages.push({
              from: 'bot',
              text: replyText,
              timestamp: new Date(),
            });
          });
          return;
        }

        // CASE 2 — Orchestrator response (user_message)
        if (resp?.user_message) {
          botText = resp.user_message;
          this.messages.push({
            from: 'bot',
            text: botText,
            timestamp: new Date(),
          });
          return;
        }

        // CASE 3 — Onboarder workflow response (`message`)
        if (resp?.message) {
          botText = resp.message;
          this.messages.push({
            from: 'bot',
            text: botText,
            timestamp: new Date(),
          });
          return;
        }

        // CASE 4 — If resp is plain string
        if (typeof resp === 'string') {
          this.messages.push({
            from: 'bot',
            text: resp,
            timestamp: new Date(),
          });
          return;
        }

        // CASE 5 — Unknown format
        this.messages.push({
          from: 'bot',
          text: '⚠️ Bot sent an unrecognized response format.',
          timestamp: new Date(),
        });
      },
      error: (err) => {
        console.error('Chat error', err);
        this.typing = false;
        this.messages.push({
          from: 'bot',
          text:
            '❌ There was an error talking to the assistant. Please try again in a moment.',
          timestamp: new Date(),
        });
      },
    });
  }

  private scrollToBottom(): void {
    try {
      if (!this.messagesContainer) return;
      const el = this.messagesContainer.nativeElement;
      el.scrollTop = el.scrollHeight;
    } catch {}
  }

  getCurrentTime(): string {
  const now = new Date();
  return now.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

continueConversation() {
  this.activeTab = 'messages';

  // Wait a moment then scroll down
  setTimeout(() => this.scrollToBottom(), 100);
}

autoResize(event: any) {
  const textarea = event.target;
  textarea.style.height = 'auto';
  textarea.style.height = textarea.scrollHeight + 'px';
}

handleEnter(event: Event) {
  const keyboardEvent = event as KeyboardEvent;

  if (!keyboardEvent.shiftKey) {
    keyboardEvent.preventDefault();
    this.send();
  }
}

}

