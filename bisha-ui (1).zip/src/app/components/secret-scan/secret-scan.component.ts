import { Component, OnInit, ViewChild } from '@angular/core'; // Import OnInit
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { SecretScan } from '../../models/secret-scan.model';
import { SecretScanService } from '../../services/secret-scan.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatGridList, MatGridTile } from '@angular/material/grid-list';
import { MatCheckboxModule } from '@angular/material/checkbox'; // ADDED: For mat-checkbox
import { MatSlideToggleModule } from '@angular/material/slide-toggle'; // ADDED: For mat-slide-toggle
import { MatInputModule } from '@angular/material/input'; // ADDED: For matInput
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderComponent } from '../header/header.component';
import { ActivatedRoute, Router } from '@angular/router'; // ADDED: Import ActivatedRoute and Router

@Component({
  selector: 'app-secret-scan',
  imports: [
    SideNavComponent,
    HeaderComponent,
    MatTableModule,
    MatPaginatorModule,
    MatFormField,
    MatLabel,
    MatGridList,
    MatGridTile,
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule, // ADDED
    MatSlideToggleModule, // ADDED
    MatInputModule // ADDED
  ],
  templateUrl: './secret-scan.component.html',
  styleUrl: './secret-scan.component.css',
  // animations: [
  //   trigger('slideInOut', [
  //     state('hidden', style({ transform: 'translateX(100%)', opacity: 0 })),
  //     state('visible', style({ transform: 'translateX(0)', opacity: 1 })),
  //     transition('hidden => visible', animate('300ms ease-in')),
  //     transition('visible => hidden', animate('300ms ease-out'))
  //   ])
  // ]
})
export class SecretScanComponent implements OnInit { // IMPLEMENT OnInit

  displayedColumns: string[] = ['RuleID', 'File', 'Author', 'Date', 'Actions'];
  dataSource = new MatTableDataSource<SecretScan>([]);
  itemsPerPageOptions = [25, 50, 100];

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  editScreenState: boolean = false;
  projectId: string | null = null; // ADDED: To store the project ID from the route

  selectedSecret: SecretScan = {
    _id: '',
    RuleID: '',
    Commit: '',
    File: '',
    SymlinkFile: '',
    Secret: '',
    Match: '',
    StartLine: 0,
    EndLine: 0,
    StartColumn: 0,
    EndColumn: 0,
    Author: '',
    Message: '',
    Date: '',
    Email: '',
    Fingerprint: '',
    Tags: '',
    branch: '',
    projectId: '',
    state: '',
    falsePositive: false,
    riskAccepted: false,
    notes: '',
  };

  constructor(
    private secretScanService: SecretScanService,
    private route: ActivatedRoute, // ADDED: Inject ActivatedRoute
    private router: Router // ADDED: Inject Router for potential back navigation
  ) {
    // The fetchData call needs to be in ngOnInit now that we depend on route params
    // debugger; // Keep if needed for initial debugging, otherwise remove
  }

  ngOnInit(): void { // IMPLEMENT ngOnInit
    this.route.paramMap.subscribe(params => {
      this.projectId = params.get('projectId'); // Get 'projectId' from the route
      console.log('SecretScanComponent - Project ID received:', this.projectId);

      if (this.projectId) {
        this.fetchData(this.projectId); // Call fetchData with the dynamic projectId
      } else {
        console.error('SecretScanComponent: Project ID not found in route parameters.');
        // Optionally, redirect or show an error to the user
        // this.router.navigate(['/projects']);
      }
    });
  }

  fetchData(projectId: string) { // MODIFIED: now accepts projectId
    this.secretScanService.getSecrets(projectId).subscribe( // Pass projectId to service
      (data) => {
        this.dataSource.data = data;
        // Ensure paginator is set AFTER data is loaded, if it's not already
        if (this.paginator) {
          this.dataSource.paginator = this.paginator;
        }
      },
      (error) => {
        console.error('Error fetching secret scan data:', error);
        // Handle error, e.g., display a message to the user
      }
    );
  }

  deleteSecret(id: string) {
    if (this.projectId) { // Ensure projectId is available for deletion
      this.secretScanService.deleteSecret(id, this.projectId).subscribe(() => { // Pass projectId
        this.dataSource.data = this.dataSource.data.filter((item) => item._id !== id);
      });
    } else {
      console.error('Cannot delete secret: Project ID is missing.');
    }
  }

  editSecret(secret: SecretScan) {
    this.selectedSecret = { ...secret };
    console.log(this.selectedSecret);
    this.editScreenState = true;
  }

  closeEditScreen() {
    this.editScreenState = false;
  }

  updateSecret() {
    if (this.selectedSecret && this.projectId) { // Ensure projectId is available for update
      this.secretScanService.updateSecret(this.selectedSecret._id, this.selectedSecret, this.projectId).subscribe(() => { // Pass projectId
        this.fetchData(this.projectId!); // Re-fetch data after update, ensuring projectId is not null
        this.closeEditScreen();
      });
    } else {
      console.error('Cannot update secret: Selected secret or Project ID is missing.');
    }
  }

  // Optional: Add a back button method to navigate to the reports overview
  goBackToReports(): void {
    if (this.projectId) {
      this.router.navigate(['/reports', this.projectId]);
    } else {
      this.router.navigate(['/projects']); // Fallback
    }
  }
}
