import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecretScanComponent } from './secret-scan.component';

describe('SecretScanComponent', () => {
  let component: SecretScanComponent;
  let fixture: ComponentFixture<SecretScanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SecretScanComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SecretScanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
