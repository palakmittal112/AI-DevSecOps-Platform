// // import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
// // import { CommonModule } from '@angular/common';
// // import { ActivatedRoute, Router } from '@angular/router';
// // import { HeaderComponent } from '../header/header.component';
// // import { SideNavComponent } from '../side-nav/side-nav.component';
// // import { ReportsService } from '../../services/reports.service';
// // import { ProjectService } from '../../services/project.service';
// // import { MatTableModule, MatTableDataSource } from '@angular/material/table';
// // import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
// // import { MatButtonModule } from '@angular/material/button';
// // import { MatIconModule } from '@angular/material/icon';
// // import { MatFormFieldModule } from '@angular/material/form-field';
// // import { MatInputModule } from '@angular/material/input';
// // import { MatCheckboxModule } from '@angular/material/checkbox';
// // import { MatGridListModule } from '@angular/material/grid-list';
// // import { MatSlideToggleModule } from '@angular/material/slide-toggle';
// // import { MatSelectModule } from '@angular/material/select';
// // import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
// // import { Subject, of } from 'rxjs';
// // import { takeUntil, debounceTime } from 'rxjs/operators';
// // import { FormsModule } from '@angular/forms';
// // import { environment } from '../../../environments/environment';
// // import { ScanResultsService } from '../../services/scan-results.service';
// // import { ReportTab } from '../../constants/scan-tool-map';
// // import { TOOL_TO_TAB_MAP } from '../../constants/scan-tool-map';

// // interface ScanRow {
// //   [key: string]: any;
// // }

// // @Component({
// //   selector: 'app-vulnerabilities-page',
// //   standalone: true,
// //   imports: [
// //     CommonModule,
// //     FormsModule,
// //     HeaderComponent,
// //     SideNavComponent,
// //     MatTableModule,
// //     MatPaginatorModule,
// //     MatButtonModule,
// //     MatIconModule,
// //     MatFormFieldModule,
// //     MatInputModule,
// //     MatCheckboxModule,
// //     MatGridListModule,
// //     MatSlideToggleModule,
// //     MatSelectModule,
// //     MatProgressSpinnerModule
// //   ],
// //   templateUrl: './vulnerabilities-page.component.html',
// //   styleUrls: ['./vulnerabilities-page.component.css']
// // })
// // export class VulnerabilitiesPageComponent implements OnInit, AfterViewInit {

// //   projectId: string = '';
// //   branch: string = environment.branch;

// //   projectDetails: any = {};
// //   severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };

// //   // Projects dropdown state
// //   projects: { _id: string; name: string }[] = [];
// //   selectedProjectId: string | null = null;
// //   projectsLoading = false;
// //   projectsError = false;

// //   // Loading state for reports
// //   loadingReport = false;
// //   reportError: string | null = null;

// //   // debounce / destroy helpers
// //   private projectChange$ = new Subject<string | null>();
// //   private destroy$ = new Subject<void>();

// //   selectedReportType: ReportTab | null = null;
// //   scanResults: any[] = [];
// //   displayedColumns: string[] = [];
// //   dataSource = new MatTableDataSource<ScanRow>([]);

// //   @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;

// //   constructor(
// //     private route: ActivatedRoute,
// //     private router: Router,
// //     private reportService: ReportsService,
// //     private projectService: ProjectService,
// //     private scanResultsService: ScanResultsService,
// //     private cdr: ChangeDetectorRef
// //   ) {}

// //   ngOnInit(): void {
// //     const saved = localStorage.getItem('vul_selectedProjectId');
// //     this.selectedProjectId = saved && saved !== 'null' ? saved : null;

// //     this.route.paramMap.subscribe(params => {
// //       const routeProject = params.get('id') || environment.projectId;
// //       if (!this.selectedProjectId && routeProject) {
// //         this.selectedProjectId = routeProject;
// //       }
// //       this.projectId = this.selectedProjectId || routeProject || '';

// //       console.log('🔍 Initialized with Project ID:', this.projectId);

// //       if (this.projectId) {
// //         this.loadProjectDetails(this.projectId);
// //         this.loadSeverityCounts(this.projectId);
// //       }
// //     });

// //     this.loadProjects();

// //     this.projectChange$
// //       .pipe(debounceTime(300), takeUntil(this.destroy$))
// //       .subscribe((projId) => {
// //         this.projectId = projId || '';
// //         console.log('🔄 Project changed to:', this.projectId);

// //         if (this.projectId) {
// //           this.loadProjectDetails(this.projectId);
// //           this.loadSeverityCounts(this.projectId);
// //         } else {
// //           this.projectDetails = {};
// //           this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
// //         }

// //         if (this.selectedReportType) {
// //           this.viewReport(this.selectedReportType);
// //         }
// //       });
// //   }

// //   ngAfterViewInit(): void {
// //     this.dataSource.paginator = this.paginator;
// //     this.cdr.detectChanges();
// //   }

// //   ngOnDestroy(): void {
// //     this.destroy$.next();
// //     this.destroy$.complete();
// //     this.projectChange$.complete();
// //   }

// //   private loadProjects(): void {
// //     this.projectsLoading = true;
// //     this.projectsError = false;
// //     this.projectService.getAllProjects().subscribe({
// //       next: (res: any) => {
// //         this.projects = (res?.data || []).map((p: any) => ({ _id: p._id, name: p.name }));
// //         this.projectsLoading = false;
// //         console.log('📋 Loaded projects:', this.projects.length);

// //         if (this.selectedProjectId && !this.projects.some(p => p._id === this.selectedProjectId)) {
// //           this.selectedProjectId = null;
// //         }
// //       },
// //       error: (err) => {
// //         console.error('❌ Failed to load projects:', err);
// //         this.projectsError = true;
// //         this.projectsLoading = false;
// //       }
// //     });
// //   }

// //   onProjectDropdownChange(newProjectId: string | null): void {
// //     this.selectedProjectId = newProjectId;
// //     localStorage.setItem('vul_selectedProjectId', this.selectedProjectId || '');
// //     this.projectChange$.next(this.selectedProjectId);
// //   }

// //   clearProjectFilter(): void {
// //     this.selectedProjectId = null;
// //     localStorage.setItem('vul_selectedProjectId', '');
// //     this.projectChange$.next(null);
// //   }

// //   loadProjectDetails(projectId: string): void {
// //     this.projectService.getProjectDetails(projectId).subscribe({
// //       next: (res) => {
// //         this.projectDetails = res?.data || res;
// //         console.log('📦 Project details loaded:', this.projectDetails);
// //         this.cdr.detectChanges();
// //       },
// //       error: (err) => {
// //         console.error('❌ Error fetching project details:', err);
// //       }
// //     });
// //   }

// //   loadSeverityCounts(projectId: string): void {
// //     this.projectService.getProjectSeveritySummary(projectId).subscribe({
// //       next: (response) => {
// //         const counts = response?.data || {};
// //         this.severityCounts = {
// //           critical: counts.critical || 0,
// //           high: counts.high || 0,
// //           medium: counts.medium || 0,
// //           low: counts.low || 0,
// //           total: (counts.critical || 0) + (counts.high || 0) + (counts.medium || 0) + (counts.low || 0)
// //         };
// //         console.log('📊 Severity counts:', this.severityCounts);
// //         this.cdr.detectChanges();
// //       },
// //       error: (error) => {
// //         console.error('❌ Error fetching severity summary:', error);
// //         this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
// //         this.cdr.detectChanges();
// //       }
// //     });
// //   }

// //   trackByProject(index: number, item: any) {
// //     return item ? item._id : index;
// //   }

// //   viewReport(type: ReportTab): void {
// //     console.log('🔍 viewReport called with type:', type, 'projectId:', this.projectId);

// //     if (!this.projectId) {
// //       console.warn('⚠️ No project ID available, cannot load report');
// //       this.reportError = 'Please select a project first';
// //       return;
// //     }

// //     this.selectedReportType = type;
// //     this.scanResults = [];
// //     this.dataSource.data = [];
// //     this.loadingReport = true;
// //     this.reportError = null;

// //     // Column configuration based on report type
// //     switch (type) {
// //       case 'sca':
// //         this.displayedColumns = [
// //           'package_name',
// //           'installed_version',
// //           'vulnerability_id',
// //           'severity',
// //           'description',
// //           'references'
// //         ];
// //       break;

// //       case 'sast':
// //         this.displayedColumns = ['ruleId', 'file', 'line', 'severity', 'message'];
// //         break;

// //       case 'sbom':
// //         this.displayedColumns = ['libraryName', 'version', 'bomRef', 'purl'];
// //         break;
// //     }

// //     console.log('📋 Configured columns:', this.displayedColumns);

// //     // 🔥 DEDUPLICATED FLOW (SCA + Secret Scan)
// //     if (type === 'sca' || type === 'secretScan') {
// //       console.log('📊 Using deduplicated endpoint for:', type);

// //       // 🔑 Decide source_tool(s) based on tab
// //       const sourceTools =
// //         type === 'sca'
// //           ? ['osv']
// //           : ['trivy', 'gitleaks'];

// //       this.scanResultsService.getDeduplicatedScanResults().subscribe({
// //         next: (res) => {
// //           console.log('📥 Deduplicated response:', res);

// //           // ✅ Filter by tool on frontend (safe + explicit)
// //           const allData = res?.data || [];
// //           this.scanResults = allData.filter((item: any) =>
// //             sourceTools.includes(item.source_tool)
// //           );

// //           this.dataSource.data = this.scanResults;
// //           this.loadingReport = false;

// //           if (this.scanResults.length === 0) {
// //             this.reportError = `No ${type} results found for this project`;
// //           }

// //           this.resetPaginator();
// //         },
// //         error: (err) => {
// //           console.error('❌ Error loading deduplicated results:', err);
// //           this.scanResults = [];
// //           this.dataSource.data = [];
// //           this.loadingReport = false;
// //           this.reportError = 'Failed to load scan results. Please try again.';
// //           this.cdr.detectChanges();
// //         }
// //       });

// //       return;
// //     }

// //     // 🔥 RAW FLOW (SAST + SBOM)
// //     console.log('📊 Using raw scan results for:', type);

// //     // Extended TOOL_TO_TAB_MAP to include hyphenated tools
// //     const extendedToolMap: Record<string, ReportTab> = {
// //       ...TOOL_TO_TAB_MAP,
// //       'trivy-secret': 'secretScan',
// //       'trivy-vuln': 'sca',
// //       'trivy-sbom': 'sbom'
// //     };

// //     this.scanResultsService.getAllScanResults().subscribe({
// //       next: (res) => {
// //         console.log('📥 Raw API response:', res);

// //         const allGroups = Array.isArray(res?.data) ? res.data : [];
// //         console.log('📦 Total groups received:', allGroups.length);

// //         const availableTools = allGroups.map((g: any) => g.source_tool);
// //         console.log('🔧 Available tools:', availableTools);
// //         console.log('🎯 Looking for type:', type);

// //         const filteredResults = allGroups
// //           .filter((group: any) => {
// //             const tab = extendedToolMap[group.source_tool];
// //             const matches = tab === type;
// //             console.log(`  Tool: ${group.source_tool} → Tab: ${tab} → Matches ${type}? ${matches}`);
// //             return matches;
// //           })
// //           .flatMap((group: any) => {
// //             console.log('  Processing group:', group.source_tool, 'Results count:', group.results?.length || 0);

// //             return (group.results ?? []).flatMap((r: any, idx: number) => {
// //               const report = r.raw_report;
// //               console.log(`    Result[${idx}] raw_report type:`, typeof report, Array.isArray(report) ? 'array' : 'object');

// //               // ✅ SAST (Semgrep)
// //               if (type === 'sast') {
// //                 if (Array.isArray(report?.results)) {
// //                   const mapped = report.results.map((item: any) => ({
// //                     ruleId: item.check_id || '',
// //                     file: item.path || '',
// //                     line: item.start?.line || '',
// //                     severity: item.extra?.metadata?.severity || item.extra?.severity || '',
// //                     message: item.extra?.message || ''
// //                   }));
// //                   console.log(`    Extracted ${mapped.length} SAST items`);
// //                   return mapped;
// //                 }
// //                 return [];
// //               }

// //               // ✅ SBOM
// //               if (type === 'sbom') {
// //                 // SBOM can have components directly or nested in metadata
// //                 let components = report?.components;

// //                 if (!components && report?.metadata?.component) {
// //                   // Sometimes SBOM has a single component in metadata
// //                   components = [report.metadata.component];
// //                 }

// //                 if (Array.isArray(components)) {
// //                   const mapped = components.map((comp: any) => ({
// //                     libraryName: comp.name || 'Unknown',
// //                     version: comp.version || 'Unknown',
// //                     bomRef: comp['bom-ref'] || comp.bomRef || '',
// //                     description: comp.description || '',
// //                     purl: comp.purl || ''
// //                   }));
// //                   console.log(`    Extracted ${mapped.length} SBOM components`);
// //                   return mapped;
// //                 }

// //                 console.log('    No SBOM components found in report');
// //                 return [];
// //               }

// //               return [];
// //             });
// //           });

// //         console.log('✅ Total filtered results:', filteredResults.length);

// //         if (filteredResults.length > 0) {
// //           console.log('📝 First result sample:', filteredResults[0]);
// //         }

// //         this.scanResults = filteredResults;
// //         this.dataSource.data = this.scanResults;
// //         this.loadingReport = false;

// //         if (filteredResults.length === 0) {
// //           this.reportError = `No ${type} results found for this project`;
// //         }

// //         setTimeout(() => {
// //           if (this.paginator) {
// //             this.dataSource.paginator = this.paginator;
// //             this.paginator.firstPage();
// //           }
// //           this.cdr.detectChanges();
// //         });
// //       },
// //       error: (err) => {
// //         console.error('❌ Error loading scan results:', err);
// //         this.scanResults = [];
// //         this.dataSource.data = [];
// //         this.loadingReport = false;
// //         this.reportError = 'Failed to load scan results. Please try again.';
// //         this.cdr.detectChanges();
// //       }
// //     });
// //   }

// //   private resetPaginator(): void {
// //     setTimeout(() => {
// //       if (this.paginator) {
// //         this.dataSource.paginator = this.paginator;
// //         this.paginator.firstPage();
// //       }
// //       this.cdr.detectChanges();
// //     });
// //   }

// //   getColumnHeader(col: string): string {
// //     const headers: Record<string, string> = {
// //       // SBOM
// //       libraryName: 'Library Name',
// //       version: 'Version',
// //       bomRef: 'BOM Reference',
// //       description: 'Description',
// //       purl: 'Package URL',

// //       // Secret Scan
// //       RuleID: 'Rule ID',
// //       File: 'File',
// //       Author: 'Author',
// //       Date: 'Date',

// //       // SCA
// //       packageName: 'Package Name',
// //       vulnerabilityId: 'Vulnerability ID',
// //       severity: 'Severity',
// //       summary: 'Summary',
// //       fixedVersion: 'Fixed Version',
// //       VulnerabilityID: 'Vulnerability ID',
// //       Title: 'Title',
// //       InstalledVersion: 'Installed Version',
// //       PkgName: 'Package Name',
// //       PrimaryURL: 'Primary URL',

// //       // SAST (Semgrep)
// //       check_id: 'Rule ID',
// //       path: 'File Path',
// //       start_line: 'Line',
// //       end_line: 'End Line',
// //       message: 'Message',
// //       extra: 'Details'
// //     };
// //     return headers[col] || col;
// //   }

// //   exportReport(): void {
// //     console.log('📤 Export clicked for:', this.selectedReportType);
// //     console.log('📊 Data to export:', this.scanResults);
// //     // TODO: Implement actual export functionality
// //   }
// // }


// import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { ActivatedRoute, Router } from '@angular/router';
// import { HeaderComponent } from '../header/header.component';
// import { SideNavComponent } from '../side-nav/side-nav.component';
// import { ReportsService } from '../../services/reports.service';
// import { ProjectService } from '../../services/project.service';
// import { MatTableModule, MatTableDataSource } from '@angular/material/table';
// import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
// import { MatButtonModule } from '@angular/material/button';
// import { MatIconModule } from '@angular/material/icon';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';
// import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatGridListModule } from '@angular/material/grid-list';
// import { MatSlideToggleModule } from '@angular/material/slide-toggle';
// import { MatSelectModule } from '@angular/material/select';
// import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
// import { Subject, of } from 'rxjs';
// import { takeUntil, debounceTime } from 'rxjs/operators';
// import { FormsModule } from '@angular/forms';
// import { environment } from '../../../environments/environment';
// import { ScanResultsService } from '../../services/scan-results.service';
// import { ReportTab } from '../../constants/scan-tool-map';
// import { TOOL_TO_TAB_MAP } from '../../constants/scan-tool-map';

// interface ScanRow {
//   [key: string]: any;
// }

// interface GlobalSeveritySummary {
//   SCA: {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
//   SAST: {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
//   'Secret Scan': {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
// }

// @Component({
//   selector: 'app-vulnerabilities-page',
//   standalone: true,
//   imports: [
//     CommonModule,
//     FormsModule,
//     HeaderComponent,
//     SideNavComponent,
//     MatTableModule,
//     MatPaginatorModule,
//     MatButtonModule,
//     MatIconModule,
//     MatFormFieldModule,
//     MatInputModule,
//     MatCheckboxModule,
//     MatGridListModule,
//     MatSlideToggleModule,
//     MatSelectModule,
//     MatProgressSpinnerModule
//   ],
//   templateUrl: './vulnerabilities-page.component.html',
//   styleUrls: ['./vulnerabilities-page.component.css']
// })
// export class VulnerabilitiesPageComponent implements OnInit, AfterViewInit {

//   projectId: string = '';
//   branch: string = environment.branch;

//   projectDetails: any = {};
//   severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };

//   // Global severity summary
//   globalSeveritySummary: GlobalSeveritySummary | null = null;
//   loadingGlobalSummary = false;
//   globalSummaryError: string | null = null;

//   // Projects dropdown state
//   projects: { _id: string; name: string }[] = [];
//   selectedProjectId: string | null = null;
//   projectsLoading = false;
//   projectsError = false;

//   // Loading state for reports
//   loadingReport = false;
//   reportError: string | null = null;

//   // debounce / destroy helpers
//   private projectChange$ = new Subject<string | null>();
//   private destroy$ = new Subject<void>();

//   selectedReportType: ReportTab | null = null;
//   scanResults: any[] = [];
//   displayedColumns: string[] = [];
//   dataSource = new MatTableDataSource<ScanRow>([]);

//   @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;

//   constructor(
//     private route: ActivatedRoute,
//     private router: Router,
//     private reportService: ReportsService,
//     private projectService: ProjectService,
//     private scanResultsService: ScanResultsService,
//     private cdr: ChangeDetectorRef
//   ) {}

//   ngOnInit(): void {
//     const saved = localStorage.getItem('vul_selectedProjectId');
//     this.selectedProjectId = saved && saved !== 'null' ? saved : null;

//     this.route.paramMap.subscribe(params => {
//       const routeProject = params.get('id') || environment.projectId;
//       if (!this.selectedProjectId && routeProject) {
//         this.selectedProjectId = routeProject;
//       }
//       this.projectId = this.selectedProjectId || routeProject || '';

//       console.log('🔍 Initialized with Project ID:', this.projectId);

//       if (this.projectId) {
//         this.loadProjectDetails(this.projectId);
//         this.loadSeverityCounts(this.projectId);
//       }
//     });

//     // Load global severity summary on init
//     this.loadGlobalSeveritySummary();

//     this.loadProjects();

//     this.projectChange$
//       .pipe(debounceTime(300), takeUntil(this.destroy$))
//       .subscribe((projId) => {
//         this.projectId = projId || '';
//         console.log('🔄 Project changed to:', this.projectId);

//         if (this.projectId) {
//           this.loadProjectDetails(this.projectId);
//           this.loadSeverityCounts(this.projectId);
//         } else {
//           this.projectDetails = {};
//           this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//         }

//         if (this.selectedReportType) {
//           this.viewReport(this.selectedReportType);
//         }
//       });
//   }

//   ngAfterViewInit(): void {
//     this.dataSource.paginator = this.paginator;
//     this.cdr.detectChanges();
//   }

//   ngOnDestroy(): void {
//     this.destroy$.next();
//     this.destroy$.complete();
//     this.projectChange$.complete();
//   }

//   private loadProjects(): void {
//     this.projectsLoading = true;
//     this.projectsError = false;
//     this.projectService.getAllProjects().subscribe({
//       next: (res: any) => {
//         this.projects = (res?.data || []).map((p: any) => ({ _id: p._id, name: p.name }));
//         this.projectsLoading = false;
//         console.log('📋 Loaded projects:', this.projects.length);

//         if (this.selectedProjectId && !this.projects.some(p => p._id === this.selectedProjectId)) {
//           this.selectedProjectId = null;
//         }
//       },
//       error: (err) => {
//         console.error('❌ Failed to load projects:', err);
//         this.projectsError = true;
//         this.projectsLoading = false;
//       }
//     });
//   }

//   loadGlobalSeveritySummary(): void {
//     this.loadingGlobalSummary = true;
//     this.globalSummaryError = null;

//     this.reportService.getGlobalSeveritySummary().subscribe({
//       next: (response) => {
//         this.globalSeveritySummary = response?.data || null;
//         this.loadingGlobalSummary = false;
//         console.log('📊 Global severity summary loaded:', this.globalSeveritySummary);
//         this.cdr.detectChanges();
//       },
//       error: (err) => {
//         console.error('❌ Error fetching global severity summary:', err);
//         this.globalSummaryError = 'Failed to load severity summary';
//         this.loadingGlobalSummary = false;
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   getScanTypeSeverity(scanType: 'SCA' | 'SAST' | 'Secret Scan'): { critical: number; high: number; medium: number; low: number; total: number } {
//     if (!this.globalSeveritySummary || !this.globalSeveritySummary[scanType]) {
//       return { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//     }

//     const data = this.globalSeveritySummary[scanType];
//     return {
//       critical: data.CRITICAL || 0,
//       high: data.HIGH || 0,
//       medium: data.MEDIUM || 0,
//       low: data.LOW || 0,
//       total: (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0)
//     };
//   }

//   getTotalVulnerabilities(): number {
//     if (!this.globalSeveritySummary) return 0;

//     let total = 0;
//     const scanTypes: Array<'SCA' | 'SAST' | 'Secret Scan'> = ['SCA', 'SAST', 'Secret Scan'];

//     scanTypes.forEach(type => {
//       const data = this.globalSeveritySummary![type];
//       total += (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0);
//     });

//     return total;
//   }

//   onProjectDropdownChange(newProjectId: string | null): void {
//     this.selectedProjectId = newProjectId;
//     localStorage.setItem('vul_selectedProjectId', this.selectedProjectId || '');
//     this.projectChange$.next(this.selectedProjectId);
//   }

//   clearProjectFilter(): void {
//     this.selectedProjectId = null;
//     localStorage.setItem('vul_selectedProjectId', '');
//     this.projectChange$.next(null);
//   }

//   loadProjectDetails(projectId: string): void {
//     this.projectService.getProjectDetails(projectId).subscribe({
//       next: (res) => {
//         this.projectDetails = res?.data || res;
//         console.log('📦 Project details loaded:', this.projectDetails);
//         this.cdr.detectChanges();
//       },
//       error: (err) => {
//         console.error('❌ Error fetching project details:', err);
//       }
//     });
//   }

//   loadSeverityCounts(projectId: string): void {
//     this.projectService.getProjectSeveritySummary(projectId).subscribe({
//       next: (response) => {
//         const counts = response?.data || {};
//         this.severityCounts = {
//           critical: counts.critical || 0,
//           high: counts.high || 0,
//           medium: counts.medium || 0,
//           low: counts.low || 0,
//           total: (counts.critical || 0) + (counts.high || 0) + (counts.medium || 0) + (counts.low || 0)
//         };
//         console.log('📊 Severity counts:', this.severityCounts);
//         this.cdr.detectChanges();
//       },
//       error: (error) => {
//         console.error('❌ Error fetching severity summary:', error);
//         this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   trackByProject(index: number, item: any) {
//     return item ? item._id : index;
//   }

//   viewReport(type: ReportTab): void {
//     console.log('🔍 viewReport called with type:', type, 'projectId:', this.projectId);

//     if (!this.projectId) {
//       console.warn('⚠️ No project ID available, cannot load report');
//       this.reportError = 'Please select a project first';
//       return;
//     }

//     this.selectedReportType = type;
//     this.scanResults = [];
//     this.dataSource.data = [];
//     this.loadingReport = true;
//     this.reportError = null;

//     // Column configuration based on report type
//     switch (type) {
//       case 'sca':
//         this.displayedColumns = [
//           'package_name',
//           'installed_version',
//           'vulnerability_id',
//           'severity',
//           'description',
//           'references'
//         ];
//       break;

//       case 'sast':
//         this.displayedColumns = ['ruleId', 'file', 'line', 'severity', 'message'];
//         break;

//       case 'sbom':
//         this.displayedColumns = ['libraryName', 'version', 'bomRef', 'purl'];
//         break;
//     }

//     console.log('📋 Configured columns:', this.displayedColumns);

//     // 🔥 DEDUPLICATED FLOW (SCA + Secret Scan)
//     if (type === 'sca' || type === 'secretScan') {
//       console.log('📊 Using deduplicated endpoint for:', type);

//       // 🔑 Decide source_tool(s) based on tab
//       const sourceTools =
//         type === 'sca'
//           ? ['osv']
//           : ['trivy', 'gitleaks'];

//       this.scanResultsService.getDeduplicatedScanResults().subscribe({
//         next: (res) => {
//           console.log('📥 Deduplicated response:', res);

//           // ✅ Filter by tool on frontend (safe + explicit)
//           const allData = res?.data || [];
//           this.scanResults = allData.filter((item: any) =>
//             sourceTools.includes(item.source_tool)
//           );

//           this.dataSource.data = this.scanResults;
//           this.loadingReport = false;

//           if (this.scanResults.length === 0) {
//             this.reportError = `No ${type} results found for this project`;
//           }

//           this.resetPaginator();
//         },
//         error: (err) => {
//           console.error('❌ Error loading deduplicated results:', err);
//           this.scanResults = [];
//           this.dataSource.data = [];
//           this.loadingReport = false;
//           this.reportError = 'Failed to load scan results. Please try again.';
//           this.cdr.detectChanges();
//         }
//       });

//       return;
//     }

//     // 🔥 RAW FLOW (SAST + SBOM)
//     console.log('📊 Using raw scan results for:', type);

//     // Extended TOOL_TO_TAB_MAP to include hyphenated tools
//     const extendedToolMap: Record<string, ReportTab> = {
//       ...TOOL_TO_TAB_MAP,
//       'trivy-secret': 'secretScan',
//       'trivy-vuln': 'sca',
//       'trivy-sbom': 'sbom'
//     };

//     this.scanResultsService.getAllScanResults().subscribe({
//       next: (res) => {
//         console.log('📥 Raw API response:', res);

//         const allGroups = Array.isArray(res?.data) ? res.data : [];
//         console.log('📦 Total groups received:', allGroups.length);

//         const availableTools = allGroups.map((g: any) => g.source_tool);
//         console.log('🔧 Available tools:', availableTools);
//         console.log('🎯 Looking for type:', type);

//         const filteredResults = allGroups
//           .filter((group: any) => {
//             const tab = extendedToolMap[group.source_tool];
//             const matches = tab === type;
//             console.log(`  Tool: ${group.source_tool} → Tab: ${tab} → Matches ${type}? ${matches}`);
//             return matches;
//           })
//           .flatMap((group: any) => {
//             console.log('  Processing group:', group.source_tool, 'Results count:', group.results?.length || 0);

//             return (group.results ?? []).flatMap((r: any, idx: number) => {
//               const report = r.raw_report;
//               console.log(`    Result[${idx}] raw_report type:`, typeof report, Array.isArray(report) ? 'array' : 'object');

//               // ✅ SAST (Semgrep)
//               if (type === 'sast') {
//                 if (Array.isArray(report?.results)) {
//                   const mapped = report.results.map((item: any) => ({
//                     ruleId: item.check_id || '',
//                     file: item.path || '',
//                     line: item.start?.line || '',
//                     severity: item.extra?.metadata?.severity || item.extra?.severity || '',
//                     message: item.extra?.message || ''
//                   }));
//                   console.log(`    Extracted ${mapped.length} SAST items`);
//                   return mapped;
//                 }
//                 return [];
//               }

//               // ✅ SBOM
//               if (type === 'sbom') {
//                 // SBOM can have components directly or nested in metadata
//                 let components = report?.components;

//                 if (!components && report?.metadata?.component) {
//                   // Sometimes SBOM has a single component in metadata
//                   components = [report.metadata.component];
//                 }

//                 if (Array.isArray(components)) {
//                   const mapped = components.map((comp: any) => ({
//                     libraryName: comp.name || 'Unknown',
//                     version: comp.version || 'Unknown',
//                     bomRef: comp['bom-ref'] || comp.bomRef || '',
//                     description: comp.description || '',
//                     purl: comp.purl || ''
//                   }));
//                   console.log(`    Extracted ${mapped.length} SBOM components`);
//                   return mapped;
//                 }

//                 console.log('    No SBOM components found in report');
//                 return [];
//               }

//               return [];
//             });
//           });

//         console.log('✅ Total filtered results:', filteredResults.length);

//         if (filteredResults.length > 0) {
//           console.log('📝 First result sample:', filteredResults[0]);
//         }

//         this.scanResults = filteredResults;
//         this.dataSource.data = this.scanResults;
//         this.loadingReport = false;

//         if (filteredResults.length === 0) {
//           this.reportError = `No ${type} results found for this project`;
//         }

//         setTimeout(() => {
//           if (this.paginator) {
//             this.dataSource.paginator = this.paginator;
//             this.paginator.firstPage();
//           }
//           this.cdr.detectChanges();
//         });
//       },
//       error: (err) => {
//         console.error('❌ Error loading scan results:', err);
//         this.scanResults = [];
//         this.dataSource.data = [];
//         this.loadingReport = false;
//         this.reportError = 'Failed to load scan results. Please try again.';
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   private resetPaginator(): void {
//     setTimeout(() => {
//       if (this.paginator) {
//         this.dataSource.paginator = this.paginator;
//         this.paginator.firstPage();
//       }
//       this.cdr.detectChanges();
//     });
//   }

//   getColumnHeader(col: string): string {
//     const headers: Record<string, string> = {
//       // SBOM
//       libraryName: 'Library Name',
//       version: 'Version',
//       bomRef: 'BOM Reference',
//       description: 'Description',
//       purl: 'Package URL',

//       // Secret Scan
//       RuleID: 'Rule ID',
//       File: 'File',
//       Author: 'Author',
//       Date: 'Date',

//       // SCA
//       packageName: 'Package Name',
//       vulnerabilityId: 'Vulnerability ID',
//       severity: 'Severity',
//       summary: 'Summary',
//       fixedVersion: 'Fixed Version',
//       VulnerabilityID: 'Vulnerability ID',
//       Title: 'Title',
//       InstalledVersion: 'Installed Version',
//       PkgName: 'Package Name',
//       PrimaryURL: 'Primary URL',

//       // SAST (Semgrep)
//       check_id: 'Rule ID',
//       path: 'File Path',
//       start_line: 'Line',
//       end_line: 'End Line',
//       message: 'Message',
//       extra: 'Details'
//     };
//     return headers[col] || col;
//   }

//   exportReport(): void {
//     console.log('📤 Export clicked for:', this.selectedReportType);
//     console.log('📊 Data to export:', this.scanResults);
//     // TODO: Implement actual export functionality
//   }
// }

// import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { ActivatedRoute, Router } from '@angular/router';
// import { HeaderComponent } from '../header/header.component';
// import { SideNavComponent } from '../side-nav/side-nav.component';
// import { ReportsService } from '../../services/reports.service';
// import { ProjectService } from '../../services/project.service';
// import { MatTableModule, MatTableDataSource } from '@angular/material/table';
// import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
// import { MatButtonModule } from '@angular/material/button';
// import { MatIconModule } from '@angular/material/icon';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';
// import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatGridListModule } from '@angular/material/grid-list';
// import { MatSlideToggleModule } from '@angular/material/slide-toggle';
// import { MatSelectModule } from '@angular/material/select';
// import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
// import { Subject, of } from 'rxjs';
// import { takeUntil, debounceTime } from 'rxjs/operators';
// import { FormsModule } from '@angular/forms';
// import { environment } from '../../../environments/environment';
// import { ScanResultsService } from '../../services/scan-results.service';
// import { ReportTab } from '../../constants/scan-tool-map';
// import { TOOL_TO_TAB_MAP } from '../../constants/scan-tool-map';

// interface ScanRow {
//   [key: string]: any;
// }

// interface GlobalSeveritySummary {
//   SCA: {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
//   SAST: {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
//   'Secret Scan': {
//     CRITICAL: number;
//     HIGH: number;
//     MEDIUM: number;
//     LOW: number;
//   };
// }

// @Component({
//   selector: 'app-vulnerabilities-page',
//   standalone: true,
//   imports: [
//     CommonModule,
//     FormsModule,
//     HeaderComponent,
//     SideNavComponent,
//     MatTableModule,
//     MatPaginatorModule,
//     MatButtonModule,
//     MatIconModule,
//     MatFormFieldModule,
//     MatInputModule,
//     MatCheckboxModule,
//     MatGridListModule,
//     MatSlideToggleModule,
//     MatSelectModule,
//     MatProgressSpinnerModule
//   ],
//   templateUrl: './vulnerabilities-page.component.html',
//   styleUrls: ['./vulnerabilities-page.component.css']
// })
// export class VulnerabilitiesPageComponent implements OnInit, AfterViewInit {

//   projectId: string = '';
//   branch: string = environment.branch;

//   projectDetails: any = {};
//   severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };

//   // Global severity summary
//   globalSeveritySummary: GlobalSeveritySummary | null = null;
//   loadingGlobalSummary = false;
//   globalSummaryError: string | null = null;

//   // Projects dropdown state
//   projects: { _id: string; name: string }[] = [];
//   selectedProjectId: string | null = null;
//   projectsLoading = false;
//   projectsError = false;

//   // Loading state for reports
//   loadingReport = false;
//   reportError: string | null = null;

//   // debounce / destroy helpers
//   private projectChange$ = new Subject<string | null>();
//   private destroy$ = new Subject<void>();

//   selectedReportType: ReportTab | null = null;
//   scanResults: any[] = [];
//   displayedColumns: string[] = [];
//   dataSource = new MatTableDataSource<ScanRow>([]);

//   @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;

//   constructor(
//     private route: ActivatedRoute,
//     private router: Router,
//     private reportService: ReportsService,
//     private projectService: ProjectService,
//     private scanResultsService: ScanResultsService,
//     private cdr: ChangeDetectorRef
//   ) {}

//   ngOnInit(): void {
//     const saved = localStorage.getItem('vul_selectedProjectId');
//     this.selectedProjectId = saved && saved !== 'null' ? saved : null;

//     this.route.paramMap.subscribe(params => {
//       const routeProject = params.get('id') || environment.projectId;
//       if (!this.selectedProjectId && routeProject) {
//         this.selectedProjectId = routeProject;
//       }
//       this.projectId = this.selectedProjectId || routeProject || '';

//       console.log('🔍 Initialized with Project ID:', this.projectId);

//       if (this.projectId) {
//         this.loadProjectDetails(this.projectId);
//         this.loadSeverityCounts(this.projectId);
//       }
//     });

//     // Load global severity summary on init
//     this.loadGlobalSeveritySummary();

//     this.loadProjects();

//     this.projectChange$
//       .pipe(debounceTime(300), takeUntil(this.destroy$))
//       .subscribe((projId) => {
//         this.projectId = projId || '';
//         console.log('🔄 Project changed to:', this.projectId);

//         if (this.projectId) {
//           this.loadProjectDetails(this.projectId);
//           this.loadSeverityCounts(this.projectId);
//         } else {
//           this.projectDetails = {};
//           this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//         }

//         if (this.selectedReportType) {
//           this.viewReport(this.selectedReportType);
//         }
//       });
//   }

//   ngAfterViewInit(): void {
//     this.dataSource.paginator = this.paginator;
//     this.cdr.detectChanges();
//   }

//   ngOnDestroy(): void {
//     this.destroy$.next();
//     this.destroy$.complete();
//     this.projectChange$.complete();
//   }

//   private loadProjects(): void {
//     this.projectsLoading = true;
//     this.projectsError = false;
//     this.projectService.getAllProjects().subscribe({
//       next: (res: any) => {
//         this.projects = (res?.data || []).map((p: any) => ({ _id: p._id, name: p.name }));
//         this.projectsLoading = false;
//         console.log('📋 Loaded projects:', this.projects.length);

//         if (this.selectedProjectId && !this.projects.some(p => p._id === this.selectedProjectId)) {
//           this.selectedProjectId = null;
//         }
//       },
//       error: (err) => {
//         console.error('❌ Failed to load projects:', err);
//         this.projectsError = true;
//         this.projectsLoading = false;
//       }
//     });
//   }

//   loadGlobalSeveritySummary(): void {
//     this.loadingGlobalSummary = true;
//     this.globalSummaryError = null;

//     this.reportService.getGlobalSeveritySummary().subscribe({
//       next: (response) => {
//         this.globalSeveritySummary = response?.data || null;
//         this.loadingGlobalSummary = false;
//         console.log('📊 Global severity summary loaded:', this.globalSeveritySummary);
//         this.cdr.detectChanges();
//       },
//       error: (err) => {
//         console.error('❌ Error fetching global severity summary:', err);
//         this.globalSummaryError = 'Failed to load severity summary';
//         this.loadingGlobalSummary = false;
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   getScanTypeSeverity(scanType: 'SCA' | 'SAST' | 'Secret Scan'): { critical: number; high: number; medium: number; low: number; total: number } {
//     if (!this.globalSeveritySummary || !this.globalSeveritySummary[scanType]) {
//       return { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//     }

//     const data = this.globalSeveritySummary[scanType];
//     return {
//       critical: data.CRITICAL || 0,
//       high: data.HIGH || 0,
//       medium: data.MEDIUM || 0,
//       low: data.LOW || 0,
//       total: (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0)
//     };
//   }

//   getTotalVulnerabilities(): number {
//     if (!this.globalSeveritySummary) return 0;

//     let total = 0;
//     const scanTypes: Array<'SCA' | 'SAST' | 'Secret Scan'> = ['SCA', 'SAST', 'Secret Scan'];

//     scanTypes.forEach(type => {
//       const data = this.globalSeveritySummary![type];
//       total += (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0);
//     });

//     return total;
//   }

//   onProjectDropdownChange(newProjectId: string | null): void {
//     this.selectedProjectId = newProjectId;
//     localStorage.setItem('vul_selectedProjectId', this.selectedProjectId || '');
//     this.projectChange$.next(this.selectedProjectId);
//   }

//   clearProjectFilter(): void {
//     this.selectedProjectId = null;
//     localStorage.setItem('vul_selectedProjectId', '');
//     this.projectChange$.next(null);
//   }

//   loadProjectDetails(projectId: string): void {
//     this.projectService.getProjectDetails(projectId).subscribe({
//       next: (res) => {
//         this.projectDetails = res?.data || res;
//         console.log('📦 Project details loaded:', this.projectDetails);
//         this.cdr.detectChanges();
//       },
//       error: (err) => {
//         console.error('❌ Error fetching project details:', err);
//       }
//     });
//   }

//   loadSeverityCounts(projectId: string): void {
//     this.projectService.getProjectSeveritySummary(projectId).subscribe({
//       next: (response) => {
//         const counts = response?.data || {};
//         this.severityCounts = {
//           critical: counts.critical || 0,
//           high: counts.high || 0,
//           medium: counts.medium || 0,
//           low: counts.low || 0,
//           total: (counts.critical || 0) + (counts.high || 0) + (counts.medium || 0) + (counts.low || 0)
//         };
//         console.log('📊 Severity counts:', this.severityCounts);
//         this.cdr.detectChanges();
//       },
//       error: (error) => {
//         console.error('❌ Error fetching severity summary:', error);
//         this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   trackByProject(index: number, item: any) {
//     return item ? item._id : index;
//   }

//   viewReport(type: ReportTab): void {
//     console.log('🔍 viewReport called with type:', type, 'projectId:', this.projectId);

//     if (!this.projectId) {
//       console.warn('⚠️ No project ID available, cannot load report');
//       this.reportError = 'Please select a project first';
//       return;
//     }

//     this.selectedReportType = type;
//     this.scanResults = [];
//     this.dataSource.data = [];
//     this.loadingReport = true;
//     this.reportError = null;

//     // Column configuration based on report type
//     switch (type) {
//       case 'sca':
//         this.displayedColumns = [
//           'package_name',
//           'installed_version',
//           'vulnerability_id',
//           'severity',
//           'description',
//           'references'
//         ];
//       break;

//       case 'sast':
//         this.displayedColumns = ['ruleId', 'file', 'line', 'severity', 'message'];
//         break;

//       case 'sbom':
//         this.displayedColumns = ['libraryName', 'version', 'bomRef', 'purl'];
//         break;
//     }

//     console.log('📋 Configured columns:', this.displayedColumns);

//     // 🔥 DEDUPLICATED FLOW (SCA + Secret Scan)
//     if (type === 'sca' || type === 'secretScan') {
//       console.log('📊 Using deduplicated endpoint for:', type);

//       // 🔑 Decide source_tool(s) based on tab
//       const sourceTools =
//         type === 'sca'
//           ? ['osv']
//           : ['trivy', 'gitleaks'];

//       this.scanResultsService.getDeduplicatedScanResults().subscribe({
//         next: (res) => {
//           console.log('📥 Deduplicated response:', res);

//           // ✅ Filter by tool on frontend (safe + explicit)
//           const allData = res?.data || [];
//           this.scanResults = allData.filter((item: any) =>
//             sourceTools.includes(item.source_tool)
//           );

//           this.dataSource.data = this.scanResults;
//           this.loadingReport = false;

//           if (this.scanResults.length === 0) {
//             this.reportError = `No ${type} results found for this project`;
//           }

//           this.resetPaginator();
//         },
//         error: (err) => {
//           console.error('❌ Error loading deduplicated results:', err);
//           this.scanResults = [];
//           this.dataSource.data = [];
//           this.loadingReport = false;
//           this.reportError = 'Failed to load scan results. Please try again.';
//           this.cdr.detectChanges();
//         }
//       });

//       return;
//     }

//     // 🔥 RAW FLOW (SAST + SBOM)
//     console.log('📊 Using raw scan results for:', type);

//     // Extended TOOL_TO_TAB_MAP to include hyphenated tools
//     const extendedToolMap: Record<string, ReportTab> = {
//       ...TOOL_TO_TAB_MAP,
//       'trivy-secret': 'secretScan',
//       'trivy-vuln': 'sca',
//       'trivy-sbom': 'sbom'
//     };

//     this.scanResultsService.getAllScanResults().subscribe({
//       next: (res) => {
//         console.log('📥 Raw API response:', res);

//         const allGroups = Array.isArray(res?.data) ? res.data : [];
//         console.log('📦 Total groups received:', allGroups.length);

//         const availableTools = allGroups.map((g: any) => g.source_tool);
//         console.log('🔧 Available tools:', availableTools);
//         console.log('🎯 Looking for type:', type);

//         const filteredResults = allGroups
//           .filter((group: any) => {
//             const tab = extendedToolMap[group.source_tool];
//             const matches = tab === type;
//             console.log(`  Tool: ${group.source_tool} → Tab: ${tab} → Matches ${type}? ${matches}`);
//             return matches;
//           })
//           .flatMap((group: any) => {
//             console.log('  Processing group:', group.source_tool, 'Results count:', group.results?.length || 0);

//             return (group.results ?? []).flatMap((r: any, idx: number) => {
//               const report = r.raw_report;
//               console.log(`    Result[${idx}] raw_report type:`, typeof report, Array.isArray(report) ? 'array' : 'object');

//               // ✅ SAST (Semgrep)
//               if (type === 'sast') {
//                 if (Array.isArray(report?.results)) {
//                   const mapped = report.results.map((item: any) => ({
//                     ruleId: item.check_id || '',
//                     file: item.path || '',
//                     line: item.start?.line || '',
//                     severity: item.extra?.metadata?.severity || item.extra?.severity || '',
//                     message: item.extra?.message || ''
//                   }));
//                   console.log(`    Extracted ${mapped.length} SAST items`);
//                   return mapped;
//                 }
//                 return [];
//               }

//               // ✅ SBOM
//               if (type === 'sbom') {
//                 // SBOM can have components directly or nested in metadata
//                 let components = report?.components;

//                 if (!components && report?.metadata?.component) {
//                   // Sometimes SBOM has a single component in metadata
//                   components = [report.metadata.component];
//                 }

//                 if (Array.isArray(components)) {
//                   const mapped = components.map((comp: any) => ({
//                     libraryName: comp.name || 'Unknown',
//                     version: comp.version || 'Unknown',
//                     bomRef: comp['bom-ref'] || comp.bomRef || '',
//                     description: comp.description || '',
//                     purl: comp.purl || ''
//                   }));
//                   console.log(`    Extracted ${mapped.length} SBOM components`);
//                   return mapped;
//                 }

//                 console.log('    No SBOM components found in report');
//                 return [];
//               }

//               return [];
//             });
//           });

//         console.log('✅ Total filtered results:', filteredResults.length);

//         if (filteredResults.length > 0) {
//           console.log('📝 First result sample:', filteredResults[0]);
//         }

//         this.scanResults = filteredResults;
//         this.dataSource.data = this.scanResults;
//         this.loadingReport = false;

//         if (filteredResults.length === 0) {
//           this.reportError = `No ${type} results found for this project`;
//         }

//         setTimeout(() => {
//           if (this.paginator) {
//             this.dataSource.paginator = this.paginator;
//             this.paginator.firstPage();
//           }
//           this.cdr.detectChanges();
//         });
//       },
//       error: (err) => {
//         console.error('❌ Error loading scan results:', err);
//         this.scanResults = [];
//         this.dataSource.data = [];
//         this.loadingReport = false;
//         this.reportError = 'Failed to load scan results. Please try again.';
//         this.cdr.detectChanges();
//       }
//     });
//   }

//   private resetPaginator(): void {
//     setTimeout(() => {
//       if (this.paginator) {
//         this.dataSource.paginator = this.paginator;
//         this.paginator.firstPage();
//       }
//       this.cdr.detectChanges();
//     });
//   }

//   getColumnHeader(col: string): string {
//     const headers: Record<string, string> = {
//       // SBOM
//       libraryName: 'Library Name',
//       version: 'Version',
//       bomRef: 'BOM Reference',
//       description: 'Description',
//       purl: 'Package URL',

//       // Secret Scan
//       RuleID: 'Rule ID',
//       File: 'File',
//       Author: 'Author',
//       Date: 'Date',

//       // SCA
//       packageName: 'Package Name',
//       vulnerabilityId: 'Vulnerability ID',
//       severity: 'Severity',
//       summary: 'Summary',
//       fixedVersion: 'Fixed Version',
//       VulnerabilityID: 'Vulnerability ID',
//       Title: 'Title',
//       InstalledVersion: 'Installed Version',
//       PkgName: 'Package Name',
//       PrimaryURL: 'Primary URL',

//       // SAST (Semgrep)
//       check_id: 'Rule ID',
//       path: 'File Path',
//       start_line: 'Line',
//       end_line: 'End Line',
//       message: 'Message',
//       extra: 'Details'
//     };
//     return headers[col] || col;
//   }

//   exportReport(): void {
//     console.log('📤 Export clicked for:', this.selectedReportType);
//     console.log('📊 Data to export:', this.scanResults);
//     // TODO: Implement actual export functionality
//   }
// }

import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { ReportsService } from '../../services/reports.service';
import { ProjectService } from '../../services/project.service';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Subject, of } from 'rxjs';
import { takeUntil, debounceTime } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { ScanResultsService } from '../../services/scan-results.service';
import { ReportTab } from '../../constants/scan-tool-map';
import { TOOL_TO_TAB_MAP } from '../../constants/scan-tool-map';

interface ScanRow {
  [key: string]: any;
}

interface GlobalSeveritySummary {
  SCA: {
    CRITICAL: number;
    HIGH: number;
    MEDIUM: number;
    LOW: number;
  };
  SAST: {
    CRITICAL: number;
    HIGH: number;
    MEDIUM: number;
    LOW: number;
  };
  'Secret Scan': {
    CRITICAL: number;
    HIGH: number;
    MEDIUM: number;
    LOW: number;
  };
}

@Component({
  selector: 'app-vulnerabilities-page',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    SideNavComponent,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatGridListModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './vulnerabilities-page.component.html',
  styleUrls: ['./vulnerabilities-page.component.css']
})
export class VulnerabilitiesPageComponent implements OnInit, AfterViewInit {

  projectId: string = '';
  branch: string = environment.branch;

  projectDetails: any = {};
  severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };

  animateProjectChange = false;


  // Global severity summary
  globalSeveritySummary: GlobalSeveritySummary | null = null;
  loadingGlobalSummary = false;
  globalSummaryError: string | null = null;

  // Projects dropdown state
  projects: { _id: string; name: string }[] = [];
  selectedProjectId: string | null = null;
  projectsLoading = false;
  projectsError = false;

  // Loading state for reports
  loadingReport = false;
  reportError: string | null = null;

  // debounce / destroy helpers
  private projectChange$ = new Subject<string | null>();
  private destroy$ = new Subject<void>();

  selectedReportType: ReportTab | null = null;
  scanResults: any[] = [];
  displayedColumns: string[] = [];
  dataSource = new MatTableDataSource<ScanRow>([]);

  @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private reportService: ReportsService,
    private projectService: ProjectService,
    private scanResultsService: ScanResultsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const saved = localStorage.getItem('vul_selectedProjectId');
    this.selectedProjectId = saved && saved !== 'null' ? saved : null;

    this.route.paramMap.subscribe(params => {
      const routeProject = params.get('id') || environment.projectId;
      if (!this.selectedProjectId && routeProject) {
        this.selectedProjectId = routeProject;
      }
      this.projectId = this.selectedProjectId || routeProject || '';

      console.log('🔍 Initialized with Project ID:', this.projectId);

      if (this.projectId) {
        this.loadProjectDetails(this.projectId);
        this.loadSeverityCounts(this.projectId);
      }
    });

    // Load global severity summary on init
    this.loadGlobalSeveritySummary();

    this.loadProjects();

    this.projectChange$
    .pipe(debounceTime(300), takeUntil(this.destroy$))
    .subscribe((projId) => {
      this.projectId = projId || '';

      // 🔥 trigger animation
      this.animateProjectChange = false;
      setTimeout(() => {
        this.animateProjectChange = true;
      });

      if (this.projectId) {
        this.loadProjectDetails(this.projectId);
        this.loadSeverityCounts(this.projectId);
      } else {
        this.projectDetails = {};
        this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
      }

      if (this.selectedReportType) {
        this.viewReport(this.selectedReportType);
      }
    });

  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.projectChange$.complete();
  }

  private loadProjects(): void {
    this.projectsLoading = true;
    this.projectsError = false;
    this.projectService.getAllProjects().subscribe({
      next: (res: any) => {
        this.projects = (res?.data || []).map((p: any) => ({ _id: p._id, name: p.name }));
        this.projectsLoading = false;
        console.log('📋 Loaded projects:', this.projects.length);

        if (this.selectedProjectId && !this.projects.some(p => p._id === this.selectedProjectId)) {
          this.selectedProjectId = null;
        }
      },
      error: (err) => {
        console.error('❌ Failed to load projects:', err);
        this.projectsError = true;
        this.projectsLoading = false;
      }
    });
  }

  loadGlobalSeveritySummary(): void {
    this.loadingGlobalSummary = true;
    this.globalSummaryError = null;

    this.reportService.getGlobalSeveritySummary().subscribe({
      next: (response) => {
        this.globalSeveritySummary = response?.data || null;
        this.loadingGlobalSummary = false;
        console.log('📊 Global severity summary loaded:', this.globalSeveritySummary);
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('❌ Error fetching global severity summary:', err);
        this.globalSummaryError = 'Failed to load severity summary';
        this.loadingGlobalSummary = false;
        this.cdr.detectChanges();
      }
    });
  }
  

  getScanTypeSeverity(scanType: 'SCA' | 'SAST' | 'Secret Scan'): { critical: number; high: number; medium: number; low: number; total: number } {
    if (!this.globalSeveritySummary || !this.globalSeveritySummary[scanType]) {
      return { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
    }

    const data = this.globalSeveritySummary[scanType];
    return {
      critical: data.CRITICAL || 0,
      high: data.HIGH || 0,
      medium: data.MEDIUM || 0,
      low: data.LOW || 0,
      total: (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0)
    };
  }

  getTotalVulnerabilities(): number {
    if (!this.globalSeveritySummary) return 0;

    let total = 0;
    const scanTypes: Array<'SCA' | 'SAST' | 'Secret Scan'> = ['SCA', 'SAST', 'Secret Scan'];

    scanTypes.forEach(type => {
      const data = this.globalSeveritySummary![type];
      total += (data.CRITICAL || 0) + (data.HIGH || 0) + (data.MEDIUM || 0) + (data.LOW || 0);
    });

    return total;
  }

  onProjectDropdownChange(newProjectId: string | null): void {
    this.selectedProjectId = newProjectId;
    localStorage.setItem('vul_selectedProjectId', this.selectedProjectId || '');
    this.projectChange$.next(this.selectedProjectId);
  }

  clearProjectFilter(): void {
    this.selectedProjectId = null;
    localStorage.setItem('vul_selectedProjectId', '');
    this.projectChange$.next(null);
  }

  loadProjectDetails(projectId: string): void {
    this.projectService.getProjectDetails(projectId).subscribe({
      next: (res) => {
        this.projectDetails = res?.data || res;
        console.log('📦 Project details loaded:', this.projectDetails);
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('❌ Error fetching project details:', err);
      }
    });
  }

  loadSeverityCounts(projectId: string): void {
    this.projectService.getProjectSeveritySummary(projectId).subscribe({
      next: (response) => {
        const counts = response?.data || {};
        this.severityCounts = {
          critical: counts.critical || 0,
          high: counts.high || 0,
          medium: counts.medium || 0,
          low: counts.low || 0,
          total: (counts.critical || 0) + (counts.high || 0) + (counts.medium || 0) + (counts.low || 0)
        };
        console.log('📊 Severity counts:', this.severityCounts);
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('❌ Error fetching severity summary:', error);
        this.severityCounts = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
        this.cdr.detectChanges();
      }
    });
  }

  trackByProject(index: number, item: any) {
    return item ? item._id : index;
  }

  viewReport(type: ReportTab): void {
    console.log('🔍 viewReport called with type:', type, 'projectId:', this.projectId);

    if (!this.projectId) {
      console.warn('⚠️ No project ID available, cannot load report');
      this.reportError = 'Please select a project first';
      return;
    }

    this.selectedReportType = type;
    this.scanResults = [];
    this.dataSource.data = [];
    this.loadingReport = true;
    this.reportError = null;

    // Column configuration based on report type
    switch (type) {
      case 'sca':
        this.displayedColumns = [
          'package_name',
          'installed_version',
          'vulnerability_id',
          'severity',
          'description',
          'references'
        ];
        break;

      case 'secretScan':
        this.displayedColumns = [
          'Rule ID',
          'File',
          'Author',
          'Date',
          'description'
        ];
        break;

      case 'sast':
        this.displayedColumns = ['ruleId', 'file', 'line', 'severity', 'message'];
        break;

      case 'sbom':
        this.displayedColumns = ['libraryName', 'version', 'bomRef', 'purl'];
        break;
    }

    console.log('📋 Configured columns:', this.displayedColumns);

    // 🔥 DEDUPLICATED FLOW (SCA + Secret Scan)
    if (type === 'sca' || type === 'secretScan') {
      console.log('📊 Using deduplicated endpoint for:', type);

      // 🔑 Decide source_tool(s) based on tab
      const sourceTools =
        type === 'sca'
          ? ['osv', 'trivy-vuln']
          : ['trivy', 'gitleaks', 'trivy-secret', 'trufflehog'];

      this.scanResultsService.getDeduplicatedScanResults().subscribe({
        next: (res) => {
          console.log('📥 Deduplicated response:', res);
          console.log('📊 Total records:', res?.data?.length || 0);

          // ✅ Filter by tool on frontend (safe + explicit)
          const allData = res?.data || [];

          // Debug: Show available tools
          const availableTools = [...new Set(allData.map((item: any) => item.source_tool))];
          console.log('🔧 Available tools in response:', availableTools);
          console.log('🎯 Looking for tools:', sourceTools);

          let filtered = allData.filter((item: any) =>
            sourceTools.includes(item.source_tool)
          );

          console.log('✅ Filtered results:', filtered.length);

          // Map fields for Secret Scan to ensure consistency
          if (type === 'secretScan' && filtered.length > 0) {
            console.log('📝 First filtered record (before mapping):', filtered[0]);

            filtered = filtered.map((item: any) => ({
              rule_id: item.rule_id || item.RuleID || item.ruleId || '',
              file_path: item.file_path || item.File || item.filePath || '',
              line_number: item.line_number || item.StartLine || item.LineNumber || item.line || '',
              secret_type: item.secret_type || item.Title || item.Category || item.type || '',
              description: item.description || item.Match || item.Secret || item.message || '',
              severity: item.severity || 'HIGH'
            }));

            console.log('📝 First record (after mapping):', filtered[0]);
          }

          this.scanResults = filtered;
          this.dataSource.data = this.scanResults;
          this.loadingReport = false;

          if (this.scanResults.length === 0) {
            this.reportError = `No ${type} results found for this project`;
            console.warn('⚠️ No results after filtering. Check source_tool values.');
          }

          this.resetPaginator();
        },
        error: (err) => {
          console.error('❌ Error loading deduplicated results:', err);
          this.scanResults = [];
          this.dataSource.data = [];
          this.loadingReport = false;
          this.reportError = 'Failed to load scan results. Please try again.';
          this.cdr.detectChanges();
        }
      });

      return;
    }

    // 🔥 RAW FLOW (SAST + SBOM)
    console.log('📊 Using raw scan results for:', type);

    // Extended TOOL_TO_TAB_MAP to include hyphenated tools
    const extendedToolMap: Record<string, ReportTab> = {
      ...TOOL_TO_TAB_MAP,
      'trivy-secret': 'secretScan',
      'trivy-vuln': 'sca',
      'trivy-sbom': 'sbom'
    };

    this.scanResultsService.getAllScanResults().subscribe({
      next: (res) => {
        console.log('📥 Raw API response:', res);

        const allGroups = Array.isArray(res?.data) ? res.data : [];
        console.log('📦 Total groups received:', allGroups.length);

        const availableTools = allGroups.map((g: any) => g.source_tool);
        console.log('🔧 Available tools:', availableTools);
        console.log('🎯 Looking for type:', type);

        const filteredResults = allGroups
          .filter((group: any) => {
            const tab = extendedToolMap[group.source_tool];
            const matches = tab === type;
            console.log(`  Tool: ${group.source_tool} → Tab: ${tab} → Matches ${type}? ${matches}`);
            return matches;
          })
          .flatMap((group: any) => {
            console.log('  Processing group:', group.source_tool, 'Results count:', group.results?.length || 0);

            return (group.results ?? []).flatMap((r: any, idx: number) => {
              const report = r.raw_report;
              console.log(`    Result[${idx}] raw_report type:`, typeof report, Array.isArray(report) ? 'array' : 'object');

              // ✅ SAST (Semgrep)
              if (type === 'sast') {
                if (Array.isArray(report?.results)) {
                  const mapped = report.results.map((item: any) => ({
                    ruleId: item.check_id || '',
                    file: item.path || '',
                    line: item.start?.line || '',
                    severity: item.extra?.metadata?.severity || item.extra?.severity || '',
                    message: item.extra?.message || ''
                  }));
                  console.log(`    Extracted ${mapped.length} SAST items`);
                  return mapped;
                }
                return [];
              }

              // ✅ SBOM
              if (type === 'sbom') {
                // SBOM can have components directly or nested in metadata
                let components = report?.components;

                if (!components && report?.metadata?.component) {
                  // Sometimes SBOM has a single component in metadata
                  components = [report.metadata.component];
                }

                if (Array.isArray(components)) {
                  const mapped = components.map((comp: any) => ({
                    libraryName: comp.name || 'Unknown',
                    version: comp.version || 'Unknown',
                    bomRef: comp['bom-ref'] || comp.bomRef || '',
                    description: comp.description || '',
                    purl: comp.purl || ''
                  }));
                  console.log(`    Extracted ${mapped.length} SBOM components`);
                  return mapped;
                }

                console.log('    No SBOM components found in report');
                return [];
              }

              return [];
            });
          });

        console.log('✅ Total filtered results:', filteredResults.length);

        if (filteredResults.length > 0) {
          console.log('📝 First result sample:', filteredResults[0]);
        }

        this.scanResults = filteredResults;
        this.dataSource.data = this.scanResults;
        this.loadingReport = false;

        if (filteredResults.length === 0) {
          this.reportError = `No ${type} results found for this project`;
        }

        setTimeout(() => {
          if (this.paginator) {
            this.dataSource.paginator = this.paginator;
            this.paginator.firstPage();
          }
          this.cdr.detectChanges();
        });
      },
      error: (err) => {
        console.error('❌ Error loading scan results:', err);
        this.scanResults = [];
        this.dataSource.data = [];
        this.loadingReport = false;
        this.reportError = 'Failed to load scan results. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  private resetPaginator(): void {
    setTimeout(() => {
      if (this.paginator) {
        this.dataSource.paginator = this.paginator;
        this.paginator.firstPage();
      }
      this.cdr.detectChanges();
    });
  }

  getColumnHeader(col: string): string {
    const headers: Record<string, string> = {
      // SBOM
      libraryName: 'Library Name',
      version: 'Version',
      bomRef: 'BOM Reference',
      description: 'Description',
      purl: 'Package URL',

      // Secret Scan
      RuleID: 'Rule ID',
      File: 'File',
      Author: 'Author',
      Date: 'Date',

      // SCA
      package_name: 'Package Name',
      installed_version: 'Installed Version',
      vulnerability_id: 'Vulnerability ID',
      references: 'References',
      packageName: 'Package Name',
      vulnerabilityId: 'Vulnerability ID',
      severity: 'Severity',
      summary: 'Summary',
      fixedVersion: 'Fixed Version',
      VulnerabilityID: 'Vulnerability ID',
      Title: 'Title',
      InstalledVersion: 'Installed Version',
      PkgName: 'Package Name',
      PrimaryURL: 'Primary URL',

      // SAST (Semgrep)
      ruleId: 'Rule ID',
      file: 'File Path',
      line: 'Line',
      message: 'Message',
      check_id: 'Rule ID',
      path: 'File Path',
      start_line: 'Line',
      end_line: 'End Line',
      extra: 'Details'
    };
    return headers[col] || col;
  }

  exportReport(): void {
    console.log('📤 Export clicked for:', this.selectedReportType);
    console.log('📊 Data to export:', this.scanResults);
    // TODO: Implement actual export functionality
  }
}
