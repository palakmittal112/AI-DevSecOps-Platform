import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ProjectService } from '../../services/project.service';

interface Project {
  _id: string;
  name: string;
}

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  showDropdown = false;
  projects: Project[] = [];
  selectedProjectName = 'All Projects';

  @Output() projectSelected = new EventEmitter<string | null>();

  constructor(
    private router: Router,
    private projectService: ProjectService
  ) {}

  ngOnInit(): void {
    this.loadProjects();
  }

  toggleDropdown(): void {
    this.showDropdown = !this.showDropdown;
  }

  loadProjects(): void {
    this.projectService.getAllProjects().subscribe({
      next: (res) => {
        if (res && res.data) {
          this.projects = res.data;
        }
      },
      error: (err) => {
        console.error('Failed to load projects:', err);
      }
    });
  }

  selectProject(project: Project | null): void {
    this.selectedProjectName = project ? project.name : 'All Projects';
    this.showDropdown = false;

    const projectId = project ? project._id : null;
    localStorage.setItem('selectedProjectId', projectId ?? '');
    this.projectSelected.emit(projectId);
  }

  logout(): void {
    console.log('Logging out...');
    this.router.navigate(['/login']);
  }
}
