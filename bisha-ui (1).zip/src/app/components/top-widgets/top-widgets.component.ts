import { Component } from '@angular/core';

@Component({
  selector: 'app-top-widgets',
  imports: [],
  templateUrl: './top-widgets.component.html',
  styleUrl: './top-widgets.component.css'
})
export class TopWidgetsComponent {

}
