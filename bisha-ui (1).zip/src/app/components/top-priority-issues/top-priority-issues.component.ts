import { Component } from '@angular/core';

@Component({
  selector: 'app-top-priority-issues',
  imports: [],
  templateUrl: './top-priority-issues.component.html',
  styleUrl: './top-priority-issues.component.css'
})
export class TopPriorityIssuesComponent {

}
