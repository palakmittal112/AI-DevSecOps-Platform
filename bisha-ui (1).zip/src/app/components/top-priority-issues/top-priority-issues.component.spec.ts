import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopPriorityIssuesComponent } from './top-priority-issues.component';

describe('TopPriorityIssuesComponent', () => {
  let component: TopPriorityIssuesComponent;
  let fixture: ComponentFixture<TopPriorityIssuesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TopPriorityIssuesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopPriorityIssuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
