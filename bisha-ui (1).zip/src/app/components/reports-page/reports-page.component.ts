// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-reports-page',
//   templateUrl: './reports-page.component.html',
//   styleUrls: ['./reports-page.component.css'],
//   standalone: true,
//   imports: [CommonModule],
// })
// export class ReportsPageComponent implements OnInit {
//   projectId: string | null = null;
//   selectedReportType: string | null = null;

//   // defaultBranch: string = 'main'; // <--- REMOVED: No longer needed here for SBOM navigation

//   constructor(private route: ActivatedRoute, private router: Router) { }

//   ngOnInit(): void {
//     this.route.paramMap.subscribe(params => {
//       this.projectId = params.get('id');
//       console.log('Reports Page - Project ID received:', this.projectId);
//     });
//   }

//   /**
//    * Handles viewing a specific report type.
//    * Navigates to a dedicated page for 'secretScan' and 'sbom'.
//    * For other types, it sets selectedReportType.
//    * @param type The type of report to view (e.g., 'secretScan', 'sbom', 'sast').
//    */
//   viewReport(type: string): void {
//     if (!this.projectId) {
//       console.error('Project ID is not available for navigation.');
//       return;
//     }

//     if (type === 'secretScan') {
//       this.router.navigate(['/secret-scan', this.projectId]);
//     } else if (type === 'sbom') {
//       // Navigate to the dedicated SBOM page, passing only the projectId
//       this.router.navigate(['/sbom', this.projectId]); // <--- UPDATED: Removed branch parameter
//     }else if (type === 'sca') { // <--- ADDED: Navigation for SCA
//       this.router.navigate(['/sca', this.projectId]);
//     }
//     else {
//       this.selectedReportType = type;
//       console.log(`Viewing ${type} report for Project ID: ${this.projectId}`);
//     }
//   }
//   goBackToReports(): void {
//     if (this.projectId) {
//       this.router.navigate(['/projects']);
//     } else {
//       this.router.navigate(['/projects']); // Fallback
//     }
//   }
// }



import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { ProjectService } from '../../services/project.service';

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [CommonModule, HeaderComponent, SideNavComponent],
  templateUrl: './reports-page.component.html',
  styleUrls: ['./reports-page.component.css']
})
export class ReportsPageComponent implements OnInit {
  projectId: string | null = null;
  selectedReportType: string | null = null;

  severityCounts: { critical: number; high: number; medium: number; low: number; total: number } = {
    critical: 0, high: 0, medium: 0, low: 0, total: 0
  };

  constructor(private route: ActivatedRoute, private router: Router, private projectService: ProjectService) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.projectId = params.get('id');
      console.log('Reports Page - Project ID received:', this.projectId);
    });
    if (this.projectId) {
      this.loadSeverityCounts(this.projectId);
      console.log('Severity stats received for Project ID:', this.projectId);
    }
  }

  loadSeverityCounts(projectId: string): void {
    this.projectService.getProjectSeveritySummary(projectId).subscribe(
      (response) => {
        const counts = response.data;
        this.severityCounts = {
          critical: counts.critical || 0,
          high: counts.high || 0,
          medium: counts.medium || 0,
          low: counts.low || 0,
          total: (counts.critical || 0) + (counts.high || 0) + (counts.medium || 0) + (counts.low || 0)
        };
        console.log('Severity stats received for Project ID:', projectId, this.severityCounts);
      },
      (error) => {
        console.error('Error fetching severity summary:', error);
      }
    );
  }

  viewReport(type: string): void {
    if (!this.projectId) {
      console.error('Project ID is not available for navigation.');
      return;
    }

    if (type === 'secretScan') {
      this.router.navigate(['/secret-scan', this.projectId]);
    } else if (type === 'sbom') {
      this.router.navigate(['/sbom', this.projectId]);
    } else if (type === 'sca') {
      this.router.navigate(['/sca', this.projectId]);
    } else {
      this.selectedReportType = type;
      console.log(`Viewing ${type} report for Project ID: ${this.projectId}`);
    }
  }
  goBackToReports(): void {
    this.router.navigate(['/projects']);
  }

  exportReport(): void {
    console.log('Export report clicked!');
  }
}


