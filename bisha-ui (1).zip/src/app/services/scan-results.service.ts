import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ScanResultsService {

  private baseUrl = `${environment.baseUrl}/scan-results`; // raw
  private dedupBaseUrl = `${environment.baseUrl}/deduplicated`; // sca + secrets

  constructor(private http: HttpClient) {}

  /** RAW scan results (SAST, SBOM, fallback) */
  getAllScanResults() {
    return this.http.get<any>(this.baseUrl);
  }

  /** DEDUPLICATED results (SCA + Secret Scan ONLY) */
  getDeduplicatedScanResults(){
    return this.http.get<any>(this.dedupBaseUrl);
  }
}
