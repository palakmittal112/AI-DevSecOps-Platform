import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { RegistrationData } from '../models/user.model';
import { environment } from '../../environments/environment';
 
export interface AppUser {
  _id: string;
  username: string;
  email: string;
  role?: string;
  team?: string;
  projects?: string[];
}
 
export interface LoginResponse {
  token: string;
  user: AppUser;
}
 
@Injectable({
  providedIn: 'root',
})
export class AuthService {
 
  private apiUrl = environment.baseUrl;
 
  private _token: string | null = null;
  private _user: AppUser | null = null;
 
  constructor(private http: HttpClient) {
    this.loadFromStorage();
    console.log('✅ Auth Service initialized, user:', this._user);
  }
 
  // ---------- API CALLS ----------
 
  register(userData: RegistrationData): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, userData);
  }
 
  login(credentials: { username: string; password: string }): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        tap((res) => {
          this.setAuth(res.token, res.user);
        }),
      );
  }
 
  // ---------- SESSION MANAGEMENT ----------
 
  private setAuth(token: string, user: AppUser) {
    this._token = token;
    this._user = user;
 
    localStorage.setItem('authToken', token);
    localStorage.setItem('authUser', JSON.stringify(user));
  }
 
  loadFromStorage() {
    const token = localStorage.getItem('authToken');
    const userJson = localStorage.getItem('authUser');
 
    if (token && userJson) {
      this._token = token;
      try {
        this._user = JSON.parse(userJson);
      } catch {
        this._user = null;
      }
    }
  }
 
  logout() {
    this._token = null;
    this._user = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('authUser');
  }
 
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }
 
  // ---------- GETTERS ----------
 
  get token(): string | null {
    return this._token;
  }
 
  get user(): AppUser | null {
    return this._user;
  }
 
  get isLoggedIn(): boolean {
    return !!this._token && !!this._user;
  }
}
 
 