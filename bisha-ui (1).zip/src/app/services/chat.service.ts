// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';

// @Injectable({ providedIn: 'root' })
// export class ChatService {

//   private API_URL = 'http://localhost:5000/api/chat';

//   constructor(private http: HttpClient) {}

//   sendMessage(message: string): Observable<any> {
//     return this.http.post<any>(this.API_URL, { message });
//   }
// }


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ChatService {
  private ENDPOINT = `${environment.baseUrl}/api/chat`;

  constructor(private http: HttpClient) {}

  /**
   * Send a message to the backend chat endpoint.
   * Expects backend to reply with JSON { reply: "..." } or plain text.
   */
  sendMessage(message: string, context?: any): Observable<{ reply: string }> {
    const body: any = { message };
    if (context) body.context = context;

    return this.http.post<any>(this.ENDPOINT, body).pipe(
      map((res) => {
        // normalize response
        if (!res) return { reply: 'No response from server' };
        if (typeof res === 'string') return { reply: res };
        if (res.reply) return { reply: res.reply };
        // try common alternatives
        if (res.data && res.data.reply) return { reply: res.data.reply };
        // fallback: return JSON stringified
        return { reply: JSON.stringify(res) };
      })
    );
  }
}
