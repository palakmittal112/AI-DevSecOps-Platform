import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  private apiUrl = `${environment.baseUrl}`;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    });
  }

  // ==================== Project-specific Reports ====================

  getSecretScanReport(projectId: string, branch: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/secretScanReport/${projectId}/${branch}`, { headers });
  }

  getContainerScanReport(projectId: string, branch: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/csScanReport/${projectId}/${branch}`, { headers });
  }

  getOsvReport(projectId: string, branch: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/osvReport/${projectId}/${branch}`, { headers });
  }

  getSBOMReport(projectId: string, branch: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/sbom/${projectId}/${branch}`, { headers });
  }

  // ==================== All Projects Reports ====================

  getAllSecretScanReports(): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/allSecretScanReports`, { headers });
  }

  getAllContainerScanReports(): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/allCsScanReports`, { headers });
  }

  getAllOsvReports(): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/allOsvReports`, { headers });
  }

  getAllSBOMScanReports(): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get<any>(`${this.apiUrl}/allSBOMReports`, { headers });
  }

  getOverallSeveritySummary(): Observable<any> {
    const headers = this.getAuthHeaders();
    console.log('Calling Severity Summary API...');
    return this.http.get(`${this.apiUrl}/overall-severity-summary`, { headers });
  }

  getGlobalSeveritySummary(): Observable<any> {
    return this.http.get<any>(
      `${this.apiUrl}/global-severity-summary`,
      { headers: this.getAuthHeaders() }
    );
  }
}
