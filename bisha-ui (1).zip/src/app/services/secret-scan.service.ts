import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SecretScan } from '../models/secret-scan.model';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
@Injectable({
  providedIn: 'root',
})
export class SecretScanService {
  // Base URL is still good
  private baseUrl = environment.baseUrl;
  // Default branch can be 'main' as per your API example, or make it dynamic later
  private defaultBranch = 'main'; // Or get this from environment if it's dynamic but commonly used

  constructor(private http: HttpClient, private authService: AuthService) {}

  /**
   * Fetches secret scan reports for a given project ID and branch.
   * @param projectId The ID of the project.
   * @param branch The branch name (defaults to 'main' if not provided).
   * @returns An Observable of SecretScan[]
   */
  getSecrets(projectId: string, branch: string = this.defaultBranch): Observable<SecretScan[]> {
    const token = this.authService.getToken();
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    // Construct the API URL dynamically using the provided projectId and branch
    const apiUrl = `${this.baseUrl}/secretScanReport/${projectId}/${branch}/`;
    console.log('Fetching secret scan from URL:', apiUrl); // For debugging

    const result = this.http.get<SecretScan[]>(apiUrl, { headers });
    // Note: Logging the Observable directly often shows the Observable object,
    // not the data inside it until it's subscribed to.
    // console.log(result); // This line is generally not helpful for debugging the data itself.
    return result;
  }

  // Your deleteSecret and updateSecret methods will also need the projectId to construct the URL correctly
  // if their URLs are also projectId-specific. Assuming they are for now:
  deleteSecret(id: string, projectId: string, branch: string = this.defaultBranch): Observable<any> {
    const token = this.authService.getToken();
    const headers = new HttpHeaders({ 'Authorization': `Bearer ${token}` });
    const apiUrl = `${this.baseUrl}/secretScanReport/${projectId}/${branch}/${id}`; // Assuming ID is appended
    return this.http.delete(apiUrl, { headers });
  }

  updateSecret(id: string, data: Partial<SecretScan>, projectId: string, branch: string = this.defaultBranch): Observable<any> {
    const token = this.authService.getToken();
    const headers = new HttpHeaders({ 'Authorization': `Bearer ${token}` });
    const apiUrl = `${this.baseUrl}/secretScanReport/${projectId}/${branch}/${id}`; // Assuming ID is appended
    return this.http.put(apiUrl, data, { headers });
  }
}
