// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Sca } from '../models/sca.model';
// import { environment } from '../../environments/environment';
// import { authService } from './login.service'; // Import authService

// @Injectable({
//   providedIn: 'root'
// })
// export class ScaService {

//   private apiUrl = `${environment.baseUrl}/osvReport`;
//   private hardcodedBranch = 'main'; // Hardcoded branch as requested

//   constructor(
//     private http: HttpClient,
//     private authService: authService // Inject authService
//   ) {}

//   /**
//    * Helper method to get authorization headers with the bearer token.
//    */
//   private getAuthHeaders(): HttpHeaders {
//     const token = this.authService.getToken();
//     if (!token) {
//       console.error('Authentication token not found.');
//       // Handle error: e.g., throw an error, redirect to login
//       throw new Error('No authentication token available.');
//     }
//     return new HttpHeaders({
//       'Content-Type': 'application/json',
//       'Authorization': `Bearer ${token}`
//     });
//   }

//   /**
//    * Fetches SBOM reports for a given project ID (branch is hardcoded to 'main').
//    * @param projectId The ID of the project.
//    * @returns An Observable of SBOM[]
//    */
//   getSca(projectId: string): Observable<Sca[]> { // Removed branch parameter
//     const headers = this.getAuthHeaders();
//     const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}`; // Use hardcodedBranch
//     console.log(`Fetching SCA from URL: ${url}`);
//     return this.http.get<Sca[]>(url, { headers });
//   }

//   /**
//    * Deletes an SBOM entry by ID for a specific project (branch is hardcoded to 'main').
//    * @param id The ID of the SBOM entry to delete.
//    * @param projectId The ID of the project.
//    * @returns An Observable of any (response from deletion).
//    */
//   deleteSca(id: string, projectId: string): Observable<any> { // Removed branch parameter
//     const headers = this.getAuthHeaders();
//     const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}/${id}`; // Use hardcodedBranch
//     return this.http.delete(url, { headers });
//   }
// }
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Sca } from '../models/sca.model';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ScaService {

  private apiUrl = `${environment.baseUrl}/osvReport`;
  private hardcodedBranch = 'main'; // Hardcoded branch as requested

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    if (!token) {
      console.error('Authentication token not found.');
      throw new Error('No authentication token available.');
    }
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getSca(projectId: string): Observable<Sca[]> { // Returns Observable<Sca[]> directly
    const headers = this.getAuthHeaders();
    const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}`;
    console.log(`Fetching SCA from URL: ${url}`);
    return this.http.get<Sca[]>(url, { headers });
  }

  deleteSca(id: string, projectId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}/${id}`;
    return this.http.delete(url, { headers });
  }
}
