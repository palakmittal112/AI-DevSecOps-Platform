import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SBOM } from '../models/sbom.model';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
@Injectable({
  providedIn: 'root'
})
export class SbomService {

  private apiUrl = `${environment.baseUrl}/sbom`;
  private hardcodedBranch = 'main'; // Hardcoded branch as requested

  constructor(
    private http: HttpClient,
    private authService: AuthService // Inject authService
  ) {}

  /**
   * Helper method to get authorization headers with the bearer token.
   */
  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    if (!token) {
      console.error('Authentication token not found.');
      // Handle error: e.g., throw an error, redirect to login
      throw new Error('No authentication token available.');
    }
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  /**
   * Fetches SBOM reports for a given project ID (branch is hardcoded to 'main').
   * @param projectId The ID of the project.
   * @returns An Observable of SBOM[]
   */
  getSbom(projectId: string): Observable<SBOM[]> { // Removed branch parameter
    const headers = this.getAuthHeaders();
    const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}`; // Use hardcodedBranch
    console.log(`Fetching SBOM from URL: ${url}`);
    return this.http.get<SBOM[]>(url, { headers });
  }

  /**
   * Deletes an SBOM entry by ID for a specific project (branch is hardcoded to 'main').
   * @param id The ID of the SBOM entry to delete.
   * @param projectId The ID of the project.
   * @returns An Observable of any (response from deletion).
   */
  deleteSbom(id: string, projectId: string): Observable<any> { // Removed branch parameter
    const headers = this.getAuthHeaders();
    const url = `${this.apiUrl}/${projectId}/${this.hardcodedBranch}/${id}`; // Use hardcodedBranch
    return this.http.delete(url, { headers });
  }
}
