import { TestBed } from '@angular/core/testing';

import { SbomService } from './sbom.service';

describe('SbomService', () => {
  let service: SbomService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SbomService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
