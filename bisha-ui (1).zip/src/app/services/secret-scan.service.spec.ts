import { TestBed } from '@angular/core/testing';

import { SecretScanService } from './secret-scan.service';

describe('SecretScanService', () => {
  let service: SecretScanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SecretScanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
