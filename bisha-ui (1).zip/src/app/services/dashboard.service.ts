import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { catchError, retry, tap, shareReplay } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { forkJoin, of } from 'rxjs';
import { AuthService } from './auth.service';

export interface VulnerabilitySummaryResponse {
  message: string;
  data: { [key: string]: { [severity: string]: number } };
}

export interface TotalCountsResponse {
  message: string;
  data: { [key: string]: number };
}

export interface ProjectResponse {
  success: boolean;
  count: number;
  data: { _id: string; name: string; users?: any[]; defaultBranch?: string; __v?: number }[];
}

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private baseUrl = environment.baseUrl;
  private loadingSummarySubject = new BehaviorSubject<boolean>(false);
  private loadingCountsSubject = new BehaviorSubject<boolean>(false);
  private cache: { [key: string]: any } = {};

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({ Authorization: `Bearer ${token}` });
  }

  private handleError(error: any): Observable<never> {
    throw error;
  }

  /** Get list of projects */
  getProjects(): Observable<ProjectResponse> {
    const url = `${this.baseUrl}/project`;
    console.log('Fetching projects from:', url);
    return this.http
      .get<ProjectResponse>(url, { headers: this.getAuthHeaders() })
      .pipe(
        retry({ count: 2, delay: 1000 }),
        tap(response => console.log('Projects response:', response)),
        catchError(err => this.handleError(err))
      );
  }

  /** Refresh all data (summary + counts) with optional projectId */
  refreshAllData(projectId?: string): Observable<{ summary: VulnerabilitySummaryResponse; counts: TotalCountsResponse }> {
    this.clearCache();
    console.log('Refreshing all data for projectId:', projectId || 'Overall');

    if (projectId) {
      return this.refreshAllDataByProject(projectId);
    }

    return new Observable(observer => {
      let summary: VulnerabilitySummaryResponse | null = null;
      let counts: TotalCountsResponse | null = null;

      const checkComplete = () => {
        if (summary && counts) {
          console.log('Combined response:', { summary, counts });
          observer.next({ summary, counts });
          observer.complete();
        }
      };

      this.getVulnerabilitySummary(true).subscribe({
        next: data => { summary = data; checkComplete(); },
        error: err => observer.error(err)
      });

      this.getTotalCounts(true).subscribe({
        next: data => { counts = data; checkComplete(); },
        error: err => observer.error(err)
      });
    });
  }

  /** Combined call for summary + counts (specific project) */
  refreshAllDataByProject(projectId: string): Observable<{ summary: VulnerabilitySummaryResponse; counts: TotalCountsResponse }> {
    return forkJoin({
      summary: this.getVulnerabilitySummaryByProject(projectId),
      counts: this.getTotalCountsByProject(projectId)
    });
  }

  /** Get vulnerability summary for a specific project */
  getVulnerabilitySummaryByProject(projectId: string): Observable<VulnerabilitySummaryResponse> {
    this.loadingSummarySubject.next(true);
    console.log('Fetching summary for projectId:', projectId);
    return this.http
      .get<VulnerabilitySummaryResponse>(
        `${this.baseUrl}/summary?projectId=${projectId}`,
        { headers: this.getAuthHeaders() }
      )
      .pipe(
        retry({ count: 2, delay: 1000 }),
        tap(response => {
          console.log('Summary response for projectId', projectId, ':', response);
          this.loadingSummarySubject.next(false);
        }),
        catchError(err => {
          this.loadingSummarySubject.next(false);
          return this.handleError(err);
        })
      );
  }

  /** Get total counts for a specific project */
  getTotalCountsByProject(projectId: string): Observable<TotalCountsResponse> {
    this.loadingCountsSubject.next(true);
    console.log('Fetching total counts for projectId:', projectId);
    return this.http
      .get<TotalCountsResponse>(
        `${this.baseUrl}/total-counts?projectId=${projectId}`,
        { headers: this.getAuthHeaders() }
      )
      .pipe(
        retry({ count: 2, delay: 1000 }),
        tap(response => {
          console.log('Total counts response for projectId', projectId, ':', response);
          this.loadingCountsSubject.next(false);
        }),
        catchError(err => {
          this.loadingCountsSubject.next(false);
          return this.handleError(err);
        })
      );
  }

  /** Get overall vulnerability summary (cached or fresh) */
  getVulnerabilitySummary(forceRefresh = false): Observable<VulnerabilitySummaryResponse> {
    const cacheKey = 'vulnerabilitySummary';
    if (!forceRefresh && this.cache[cacheKey]) {
      console.log('Returning cached summary');
      return of(this.cache[cacheKey]);
    }
    this.loadingSummarySubject.next(true);
    console.log('Fetching overall summary');
    return this.http
      .get<VulnerabilitySummaryResponse>(`${this.baseUrl}/summary`, { headers: this.getAuthHeaders() })
      .pipe(
        retry({ count: 2, delay: 1000 }),
        tap(response => {
          console.log('Overall summary response:', response);
          this.cache[cacheKey] = response;
          this.loadingSummarySubject.next(false);
        }),
        catchError(err => {
          this.loadingSummarySubject.next(false);
          return this.handleError(err);
        })
      );
  }

  /** Get overall total counts (cached or fresh) */
  getTotalCounts(forceRefresh = false): Observable<TotalCountsResponse> {
    const cacheKey = 'totalCounts';
    if (!forceRefresh && this.cache[cacheKey]) {
      console.log('Returning cached total counts');
      return of(this.cache[cacheKey]);
    }
    this.loadingCountsSubject.next(true);
    console.log('Fetching overall total counts');
    return this.http
      .get<TotalCountsResponse>(`${this.baseUrl}/total-counts`, { headers: this.getAuthHeaders() })
      .pipe(
        retry({ count: 2, delay: 1000 }),
        tap(response => {
          console.log('Overall total counts response:', response);
          this.cache[cacheKey] = response;
          this.loadingCountsSubject.next(false);
        }),
        catchError(err => {
          this.loadingCountsSubject.next(false);
          return this.handleError(err);
        })
      );
  }

  /** Clear cache */
  clearCache(): void {
    this.cache = {};
    console.log('Cache cleared');
  }

  /** Observable for summary loading state */
  getSummaryLoading(): Observable<boolean> {
    return this.loadingSummarySubject.asObservable();
  }

  /** Observable for counts loading state */
  getCountsLoading(): Observable<boolean> {
    return this.loadingCountsSubject.asObservable();
  }

  getGlobalSeveritySummary(): Observable<any> {
    return this.http.get<any>(
      `${this.baseUrl}/global-severity-summary`,
      { headers: this.getAuthHeaders() }
    );
  }

}

