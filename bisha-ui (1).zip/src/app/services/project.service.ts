import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';
interface Project {
  _id: string;
  name: string;
}

@Injectable({
  providedIn: 'root',
})
export class ProjectService {

  private apiUrl = `${environment.baseUrl}/project`;

  private selectedProjectIdSubject = new BehaviorSubject<string | null>(null);
  selectedProjectId$ = this.selectedProjectIdSubject.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  /**
   * Generates HTTP headers with Content-Type and Authorization token.
   * @returns HttpHeaders object.
   */
  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    });
  }

  /**
   * Creates a new project by sending a POST request to the API.
   * Expects the API to return an object with 'success' and 'data' properties.
   * @param name The name of the project to create.
   * @returns An Observable of the API response containing success status and the created Project data.
   */
  createProject(name: string): Observable<{ success: boolean; data: Project }> {
    const headers = this.getAuthHeaders();
    return this.http.post<{ success: boolean; data: Project }>(
      this.apiUrl,
      { name },
      { headers }
    );
  }

  /**
   * Fetches all projects from the API.
   * IMPORTANT: This method now expects the API to return an object
   * with a 'data' property that contains the array of projects.
   * If your backend directly returns Project[], adjust the return type accordingly.
   * @returns An Observable of the API response containing success status and an array of Projects.
   */
  getAllProjects(): Observable<{ success: boolean; data: Project[] }> {
    const headers = this.getAuthHeaders();
    return this.http.get<{ success: boolean; data: Project[] }>(this.apiUrl, { headers });
  }

  /**
   * Fetches details for a specific project by its ID.
   * @param projectId The ID of the project to fetch details for.
   * @returns An Observable of the project details.
   */
  getProjectDetails(projectId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.apiUrl}/${projectId}`, { headers });
  }

  /**
 * Get project severity summary
 * @param projectId The project ID
 */
  getProjectSeveritySummary(projectId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.apiUrl}/${projectId}/severity-summary`, { headers });
  }
}
