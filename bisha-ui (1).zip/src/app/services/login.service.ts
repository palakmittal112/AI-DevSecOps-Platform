// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
// import { Observable, tap } from 'rxjs';
// import { environment } from '../../environments/environment';
// import { LoginRequest, LoginResponse } from '../models/login.model';



// @Injectable({
//   providedIn: 'root'
// })
// export class LoginService {


//     private apiUrl = `${environment.baseUrl}/login`;  // baseUrl from env file

//       // constructor(private http: HttpClient) {}

//       // login(username: string, password: string): Observable<String> {
//       //   return this.http.get<String>(`${this.apiUrl}`);
//       // }

//       private tokenKey = 'authToken'; // Key to store the token in local storage (adjust as needed)

//       constructor(private http: HttpClient) {}

//       // login(username: string, password: string): Observable<HttpResponse<AuthResponse>> {
//       //   const headers = new HttpHeaders({
//       //     'Content-Type': 'application/json'
//       //   });

//       //   return this.http.post<AuthResponse>(this.apiUrl, {}, { headers, observe: 'response' })
//       //     .pipe(
//       //       tap((response) => {
//       //         const token = response.body?.token;
//       //         if (token) {
//       //           this.storeToken(token);
//       //         }
//       //       })
//       //     );
//       // }

//       login(username: string, password: string): Observable<HttpResponse<LoginResponse>> {
//         const body: LoginRequest = { username, password };
//         const headers = new HttpHeaders({
//               'Content-Type': 'application/json'
//             });

//         return this.http.post<LoginResponse>(this.apiUrl, body, { headers, observe: 'response' })
//           .pipe(
//             tap((response) => {
//               const token = response.body?.token;
//               if (token) {
//                 this.storeToken(token);
//               }
//             })
//           );
//       }

//       getToken(): string | null {
//         return localStorage.getItem(this.tokenKey);
//       }

//       removeToken(): void {
//         localStorage.removeItem(this.tokenKey);
//       }

//       private storeToken(token: string): void {
//         localStorage.setItem(this.tokenKey, token);
//         console.log('JWT token stored successfully.');
//       }




// }
