export const environment = {
  production: false,
  baseUrl: 'http://mvp-bisha-alb-1785234871.ap-south-1.elb.amazonaws.com/api',
  //baseUrl: 'http://localhost:5000/api',
  projectId: '68297f62ce5cc836ca7ddd67',
  branch: 'main'
};
