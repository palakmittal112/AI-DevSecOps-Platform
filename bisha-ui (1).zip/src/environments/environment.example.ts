export const environment = {
  production: false,
  baseUrl: 'http://localhost:5000/api',
  projectId: '',
  branch: 'main'
};
