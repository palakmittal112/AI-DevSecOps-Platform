const mongoose = require('mongoose');

const RepoSchema = new mongoose.Schema({
  repoId: { type: String, index: true, unique: true },
  repoUrl: { type: String, required: true },
  repoName: { type: String, required: true },
  accessLevel: String,
  visibility: String,
  createdAtRemote: String,
  openIssues: Number,
  watchers: Number,
  forks: Number,
  metadata: {
    fileCount: Number,
    repoSizeMB: Number,
    defaultBranch: String,
    lastCommit: {
      date: String,
      author: String,
      hash: String
    },
    languagesPercent: Object,
    dependencies: Object
  },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Repo', RepoSchema);
