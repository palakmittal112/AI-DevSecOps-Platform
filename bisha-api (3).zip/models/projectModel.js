const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Project name is required'],
        trim: true
    },
    userId: {
        type: String,  // Store as String to match your data format
        required: [true, 'User ID is required'],
        index: true    // Index for faster queries
    },
    owner: {
        type: String,
        trim: true
    },
    repository: {
        type: String,
        trim: true
    },
    branch: {
        type: String,
        default: 'main',
        trim: true
    },
    full_name: {
        type: String,
        trim: true
    },
    visibility: {
        type: String,
        enum: ['public', 'private'],
        default: 'public'
    },
    description: {
        type: String,
        default: null
    },
    language: {
        type: String,
        trim: true
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    },
    pushed_at: {
        type: Date
    },
    size: {
        type: Number,
        default: 0
    },
    stargazers_count: {
        type: Number,
        default: 0
    },
    watchers_count: {
        type: Number,
        default: 0
    },
    forks_count: {
        type: Number,
        default: 0
    },
    open_issues_count: {
        type: Number,
        default: 0
    },
    has_issues: {
        type: Boolean,
        default: true
    },
    has_projects: {
        type: Boolean,
        default: true
    },
    has_wiki: {
        type: Boolean,
        default: true
    },
    default_branch: {
        type: String,
        default: 'main'
    },
    clone_url: {
        type: String,
        trim: true
    },
    api_url: {
        type: String,
        trim: true
    }
}, {
    timestamps: true  // This will add createdAt and updatedAt fields
});

// Indexes for better query performance
projectSchema.index({ userId: 1, created_at: -1 });
projectSchema.index({ name: 1, userId: 1 });

// Middleware to update the updated_at field before saving
projectSchema.pre('save', function(next) {
    this.updated_at = new Date();
    next();
});

// Virtual for formatted creation date
projectSchema.virtual('formattedCreatedAt').get(function() {
    return this.created_at ? this.created_at.toISOString() : null;
});

// Ensure virtuals are included when converting to JSON
projectSchema.set('toJSON', { virtuals: true });
projectSchema.set('toObject', { virtuals: true });

const Project = mongoose.model('Project', projectSchema);

module.exports = Project;