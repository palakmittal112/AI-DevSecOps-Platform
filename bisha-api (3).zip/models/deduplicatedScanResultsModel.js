const mongoose = require('mongoose');

const ScanResultDeduplicatedSchema = new mongoose.Schema(
  {
    source_tool: {
      type: String,
      required: true,
      index: true
    },

    vulnerability_id: {
      type: String,
      required: true,
      index: true
    },

    package_name: {
      type: String,
      required: true
    },

    installed_version: {
      type: String
    },

    severity: {
      type: String,
      enum: ['Critical', 'High', 'Medium', 'Low', 'Unknown'],
      index: true
    },

    description: {
      type: String
    },

    references: {
      type: [String],
      default: []
    },

    scan_id: {
      type: String,
      index: true
    },

    project_id: {
      type: String,
      required: true,
      index: true
    },

    created_at: {
      type: Date,
      default: Date.now
    }
  },
  {
    collection: 'scan_results_deduplicated',
    timestamps: false
  }
);

// Optional but recommended
ScanResultDeduplicatedSchema.index(
  { project_id: 1, vulnerability_id: 1 },
  { unique: true }
);

module.exports = mongoose.model(
  'ScanResultDeduplicated',
  ScanResultDeduplicatedSchema
);
