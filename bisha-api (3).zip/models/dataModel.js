const mongoose = require('mongoose');

const DataSchema = new mongoose.Schema({
    RuleID: String,
    Commit: String,
    File: String,
    SymlinkFile: String,
    Secret: String,
    Match: String,
    StartLine: Number,
    EndLine: Number,
    StartColumn: Number,
    EndColumn: Number,
    Author: String,
    Message: String,
    Date: Date,
    Email: String,
    Fingerprint: String,
    Tags: Array,
    Status: String,
    TicketLink: String,
    branch: String,
    projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
    state: { type: String },
    falsePositive: { type: Boolean, default: false },
    riskAccepted: { type: Boolean, default: false },
});

module.exports = mongoose.model('Data', DataSchema);