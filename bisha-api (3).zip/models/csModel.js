const mongoose = require('mongoose');

const PkgIdentifierSchema = new mongoose.Schema({
  PURL: String,
  UID: String
}, { _id: false });

const CVSSSchema = new mongoose.Schema({
  source: String,
  V2Vector: String,
  V2Score: Number,
  V3Vector: String,
  V3Score: Number
}, { _id: false });

const VulnerabilitySchema = new mongoose.Schema({
  VulnerabilityID: { type: String, required: true },
  Title: String,
  Description: String,
  Severity: String,
  InstalledVersion: String,
  PkgName: String,
  PkgID: String,
  Target: String,
  Class: String,
  Type: String,
  Project: String,
  Branch: String,
  State: {
    type: String,
    enum: ['open', 'fixed', 'deleted'],
    default: 'open'
  },
  LastSeen: Date,
  Notes: String,
  PkgIdentifier: PkgIdentifierSchema,
  CVSS: mongoose.Schema.Types.Mixed,
  VendorSeverity: mongoose.Schema.Types.Mixed,
  References: [String],
  PrimaryURL: String,
  DataSource: mongoose.Schema.Types.Mixed
}, { timestamps: true });

VulnerabilitySchema.index({
  VulnerabilityID: 1,
  Title: 1,
  InstalledVersion: 1,
  PkgName: 1,
  Target: 1,
  Class: 1,
  Type: 1
}, { unique: false });

module.exports = mongoose.model('ContainerImageVulnerability', VulnerabilitySchema);