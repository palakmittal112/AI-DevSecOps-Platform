const mongoose = require('mongoose');

/**
 * Generic raw finding schema
 * Works for Secret Scan, SCA, Container, IaC, etc.
 */
const RawFindingSchema = new mongoose.Schema(
  {
    RuleID: String,
    Description: String,

    StartLine: Number,
    EndLine: Number,
    StartColumn: Number,
    EndColumn: Number,

    Match: String,
    Secret: String,

    File: String,
    SymlinkFile: String,

    Commit: String,
    Link: String,

    Entropy: Number,

    Author: String,
    Email: String,

    Date: Date,
    Message: String,

    Tags: { type: [String], default: [] },
    Fingerprint: String
  },
  {
    _id: false,
    strict: false // ✅ allows tool-specific extra fields
  }
);

/**
 * Main scan result schema (generic)
 */
const ScanResultRawSchema = new mongoose.Schema(
  {
    scan_id: {
      type: String,
      required: true,
      index: true
    },

    source_tool: {
      type: String,
      required: true,
      index: true
      // examples: gitleaks, osv, trivy, grype, semgrep
    },

    scan_type: {
      type: String,
      required: true,
      index: true
      // examples: secret, sca, container, iac, sast, dast
    },

    raw_report: {
      type: [RawFindingSchema],
      default: []
    },

    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
      // repo, branch, commit, image, language, etc.
    },

    created_at: {
      type: Date,
      default: Date.now,
      index: true
    }
  },
  {
    collection: 'scan_results_raw',
    strict: false // ✅ allows different scan structures
  }
);

module.exports = mongoose.model('ScanResultRaw', ScanResultRawSchema);
