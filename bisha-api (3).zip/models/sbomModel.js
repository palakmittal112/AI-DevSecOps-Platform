// const mongoose = require('mongoose');

// const SBOMSchema = new mongoose.Schema({
//   project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
//   branchName: { type: String, required: true },
//   libraryName: { type: String, required: true },
//   version: { type: String, required: true },
//   reference: { type: String, required: true },
//   license: { type: String, required: true },
//   purl: { type: String, required: true },
//   otherDetails: { type: mongoose.Schema.Types.Mixed, required: true }
// });

// module.exports = mongoose.model('SBOM', SBOMSchema);


const mongoose = require('mongoose');

const SBOMSchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  branch: { type: String, required: true },
  libraryName: { type: String, required: true },
  version: { type: String, required: true },
  // reference: { type: String, required: true },
  license: { type: String },
  description: String,
  purl: { type: String, required: true },
  rawData: Object,
  state: {
    type: String,
    enum: ['created', 'updated', 'deleted'],
    default: 'created'
  },
  dependencies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'SBOM' }],

  firstFound: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  bomRef: String

});

module.exports = mongoose.model('SBOM', SBOMSchema);

