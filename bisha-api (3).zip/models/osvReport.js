const mongoose = require("mongoose");

const scaVulnerabilitySchema = new mongoose.Schema({
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  branchName: { type: String, required: true },
  packageName: { type: String, required: true },
  version: { type: String, required: true },
  ecosystem: { type: String, required: true },
  vulnerabilityId: { type: String, required: true },
  aliases: [{ type: String }],  // Alternative vulnerability identifiers (CVE, GHSA)
  summary: { type: String, required: true },
  details: { type: String },
  severity: { type: String },
  affectedVersions: [{ type: String }],  // List of affected versions
  identifiedDate: { type: Date },  // Date when it was first published
  lastUpdated: { type: Date },  // Date when last modified
  fixedVersion: { type: String },  // Fixed version if available
  references: [{ type: String }],  // External links (advisories, reports)
  affectedFunctions: [{ type: String }],  // Specific functions affected
  falsePositive: { type: Boolean, default: false },
  riskAccepted: { type: Boolean, default: false },
  notes: { type: String },
  state: { type: String, default: "open" },
  title: { type: String, required: true },
  otherDetails: { type: mongoose.Schema.Types.Mixed }

});

module.exports = mongoose.model("scaVulnerability", scaVulnerabilitySchema);