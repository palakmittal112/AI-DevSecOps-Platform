const mongoose = require('mongoose');

const patSchema = new mongoose.Schema({
  token: { type: String, required: true, unique: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  description: { type: String },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date }, // Will be set by default or provided by user
  active: { type: Boolean, default: true },
});

// Pre-save middleware to set default and validate expiresAt
patSchema.pre('save', function (next) {
  if (!this.expiresAt) {
    // Default expiration: 30 days from creation
    const defaultExpiry = new Date(this.createdAt);
    defaultExpiry.setDate(defaultExpiry.getDate() + 30);
    this.expiresAt = defaultExpiry;
  }

  // Max expiration: 180 days from creation
  const maxExpiry = new Date(this.createdAt);
  maxExpiry.setDate(maxExpiry.getDate() + 180);

  if (this.expiresAt > maxExpiry) {
    this.expiresAt = maxExpiry; // Enforce max expiry
  }

  next();
});

module.exports = mongoose.model('PAT', patSchema);