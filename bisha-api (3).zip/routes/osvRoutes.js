const express = require('express');
const router = express.Router();
const vulnerabilityController = require('../controllers/osvController');
const auth = require('../config/authPat');


// router.post('/osvReport', osvReportController.createOSVReport);
// router.put('/osvReport/:id', osvReportController.updateOSVReport);
// router.delete('/osvReport/:id', osvReportController.deleteOSVReport);
// router.get('/osvReport/:id', osvReportController.getOSVReport);
// router.get('/osvReport/project/:projectName/branch/:branchName', osvReportController.getOSVReportByProjectAndBranch);

// module.exports = router;


// const vulnerabilityController = require("../controllers/vulnerabilityController");

// Store vulnerabilities from JSON file
router.post("/osvReport/:projectId/:branchName/storeFromFile",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.storeVulnerabilitiesFromFile);

// Store vulnerabilities from JSON body
router.post("/osvReport/:projectId/:branchName/store",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.storeVulnerabilities);

// Store or update vulnerabilities from JSON body
router.post("/osvReport/:projectId/:branchName/storeOrUpdate",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.storeOrUpdateVulnerabilities);

// Get vulnerabilities by project and branch
router.get("/osvReport/:projectId/:branchName",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.getVulnerabilities);

router.get("/allOsvReports", auth(['admin', 'project_user', 'team_user']), vulnerabilityController.getAllVulnerabilities);

// Update a vulnerability by ID
router.put("/osvReport/:id",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.updateVulnerability);

// Delete a vulnerability by ID
router.delete("/osvReport/:id",auth(['admin', 'project_user', 'team_user']), vulnerabilityController.deleteVulnerability);

module.exports = router;
