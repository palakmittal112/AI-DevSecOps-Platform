const express = require('express');
const router = express.Router();
const csScanReportController = require('../controllers/containerScanController');
const auth = require('../config/authPat');



router.post("/csScanReport/:project/:branch/createOrUpdate",auth(['admin', 'project_user', 'team_user']), csScanReportController.createOrUpdateVulnerabilities);
// router.post('/secretScanReport', auth(['admin', 'project_user', 'team_user']), secretScanReportController.createSecretScanReport);
// router.put('/csScanReport/:id', auth(['admin', 'project_user', 'team_user']), csScanReportController.updateSecretScanReport);
// router.delete('/csScanReport/:id', auth(['admin', 'project_user']), csScanReportController.deleteSecretScanReport);

router.get("/csScanReport/:project/:branch",auth(['admin', 'project_user', 'team_user']), csScanReportController.getContainerScanReport);
// router.get("/secretScanReport/:projectId/:branch", secretScanReportController.getSecretReport);

router.get("/allCsScanReports", auth(['admin', 'project_user', 'team_user']), csScanReportController.getAllContainerScanReports);

module.exports = router;