const express = require('express');
const router = express.Router();
const sbomController = require('../controllers/sbomController');
const auth = require('../config/authPat');


// router.post('/sbom', sbomController.createSBOM);
router.post('/sbom/:project/:branch/createOrUpdate',auth(['admin', 'project_user', 'team_user']),sbomController.createOrUpdateSBOM);

router.put('/sbom/:id',auth(['admin', 'project_user', 'team_user']), sbomController.updateSBOM);
router.delete('/sbom/:id',auth(['admin', 'project_user', 'team_user']), sbomController.deleteSBOM);
router.get('/sbom/:id',auth(['admin', 'project_user', 'team_user']), sbomController.getSBOM);
// router.get('/sbom/project/:projectName/branch/:branchName',auth(['admin', 'project_user', 'team_user']), sbomController.getSBOMByProjectAndBranch);
// router.get('/sbom/:project/:branch',auth(['admin', 'project_user', 'team_user']), sbomController.getSBOMByProjectAndBranch);
router.get('/sbom/:project/:branch', sbomController.getSBOMByProjectAndBranch);
router.get('/allSBOMReports',auth(['admin', 'project_user', 'team_user']), sbomController.getAllSBOM);


module.exports = router;

