const express = require('express');
const router = express.Router();
const secretScanReportController = require('../controllers/secretScanReportController');
const auth = require('../config/authPat');


// Store vulnerabilities from JSON body
router.post("/secretScanReport/:projectId/:branchName/store",auth(['admin', 'project_user', 'team_user']), secretScanReportController.createSecretScanReport);
// Store vulnerabilities from JSON body
router.post("/secretScanReport/:projectId/:branch/createOrUpdate",auth(['admin', 'project_user', 'team_user']), secretScanReportController.createOrUpdateSecretScanReport);
// router.post('/secretScanReport', auth(['admin', 'project_user', 'team_user']), secretScanReportController.createSecretScanReport);
router.put('/secretScanReport/:id', auth(['admin', 'project_user', 'team_user']), secretScanReportController.updateSecretScanReport);
router.delete('/secretScanReport/:id', auth(['admin', 'project_user']), secretScanReportController.deleteSecretScanReport);

router.get("/secretScanReport/:projectId/:branch",auth(['admin', 'project_user', 'team_user']), secretScanReportController.getSecretReport);
// router.get("/secretScanReport/:projectId/:branch", secretScanReportController.getSecretReport);

router.get("/allSecretScanReports", auth(['admin', 'project_user', 'team_user']), secretScanReportController.getAllSecretReports);

module.exports = router;