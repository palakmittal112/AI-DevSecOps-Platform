const express = require('express');
const router = express.Router();
const projectController = require('../controllers/projectController');
const auth = require('../config/authPat');

/**
 * @route   POST /api/project
 * @desc    Create a new project (userId automatically attached)
 * @access  Private (admin, project_user)
 */
router.post('/project', auth(['admin', 'project_user']), projectController.createProject);

/**
 * @route   GET /api/project
 * @desc    Get all projects for the authenticated user
 * @access  Private (admin, project_user)
 */
router.get('/project', auth(['admin', 'project_user']), projectController.getProjectsByUser);

/**
 * @route   GET /api/project/:id
 * @desc    Get a single project by ID (only if user owns it)
 * @access  Private (admin, project_user)
 */
router.get('/project/:id', auth(['admin', 'project_user']), projectController.getProject);

/**
 * @route   PUT /api/project/:id
 * @desc    Update a project (only if user owns it)
 * @access  Private (admin, project_user)
 */
router.put('/project/:id', auth(['admin', 'project_user']), projectController.updateProject);

/**
 * @route   DELETE /api/project/:id
 * @desc    Delete a project (only if user owns it)
 * @access  Private (admin only)
 */
router.delete('/project/:id', auth(['admin']), projectController.deleteProject);

/**
 * @route   GET /api/project/:id/severity-summary
 * @desc    Get severity summary for a project
 * @access  Private (admin, project_user)
 * @note    Add this route if you have the controller method
 */
// router.get('/project/:id/severity-summary', auth(['admin', 'project_user']), projectController.getProjectSeveritySummary);

module.exports = router;