const express = require("express");
const router = express.Router();
const {
  getGlobalSeveritySummary,
  getTotalVulnerabilityCounts,
  getProjectSeveritySummary,
  getSastDetails,
  getSastSummary,
  getSbomDetails,
  getSbomSummary
} = require("../controllers/summaryController");
const auth = require("../config/authPat");

/* ====================================================================
   DASHBOARD - GLOBAL ANALYTICS
==================================================================== */

/**
 * GET /api/summary/global-severity-summary
 * Returns severity breakdown for all scan types (SCA, SAST, SBOM, Secret Scan)
 * Response: { SCA: {CRITICAL, HIGH, MEDIUM, LOW}, SAST: {...}, ... }
 */
router.get(
  "/global-severity-summary",
  auth(["admin", "project_user", "team_user"]),
  getGlobalSeveritySummary
);

/**
 * GET /api/summary/total-counts
 * Returns total vulnerability counts across all scan types
 * Response: { SCA: 10, SAST: 12, "Secret Scan": 5, SBOM: 150, "Total Vulnerabilities": 177 }
 */
router.get(
  "/total-counts",
  auth(["admin", "project_user", "team_user"]),
  getTotalVulnerabilityCounts
);

/* ====================================================================
   PROJECT-SPECIFIC ANALYTICS
==================================================================== */

/**
 * GET /api/summary/project/:projectId/severity-summary
 * Returns severity breakdown for a specific project
 * Params: projectId (required)
 * Response: { CRITICAL: 2, HIGH: 5, MEDIUM: 8, LOW: 3 }
 */
router.get(
  "/project/:projectId/severity-summary",
  auth(["admin", "project_user", "team_user"]),
  getProjectSeveritySummary
);

/* ====================================================================
   SAST (STATIC APPLICATION SECURITY TESTING) - SEMGREP
==================================================================== */

/**
 * GET /api/summary/sast/details
 * Returns detailed SAST findings from Semgrep scans
 * Query Params:
 *   - scanId (optional): Filter by specific scan ID
 *   - projectId (optional): Filter by project ID
 * Response: {
 *   success: true,
 *   count: 12,
 *   data: [{
 *     scan_id, check_id, path, line_start, line_end,
 *     severity, message, cwe, owasp, vulnerability_class,
 *     confidence, impact, likelihood, source_url, created_at
 *   }]
 * }
 */
router.get(
  "/sast/details",
  auth(["admin", "project_user", "team_user"]),
  getSastDetails
);

/**
 * GET /api/summary/sast/summary
 * Returns SAST summary statistics
 * Query Params:
 *   - scanId (optional): Filter by specific scan ID
 * Response: {
 *   success: true,
 *   data: {
 *     severitySummary: { CRITICAL: 0, HIGH: 5, MEDIUM: 6, LOW: 1 },
 *     topVulnerabilityClasses: [{ name: "CSRF", count: 3 }, ...],
 *     topCWEs: [{ cwe: "CWE-352", count: 1 }, ...]
 *   }
 * }
 */
router.get(
  "/sast/summary",
  auth(["admin", "project_user", "team_user"]),
  getSastSummary
);

/* ====================================================================
   SBOM (SOFTWARE BILL OF MATERIALS)
==================================================================== */

/**
 * GET /api/summary/sbom/details
 * Returns detailed SBOM component list (CycloneDX format)
 * Query Params:
 *   - scanId (optional): Filter by specific scan ID
 *   - projectId (optional): Filter by project ID
 * Response: {
 *   success: true,
 *   count: 150,
 *   metadata: { bomFormat, specVersion, timestamp, tools },
 *   data: [{
 *     scan_id, name, group, version, purl, type, scope,
 *     bom_ref, hashes, properties, created_at
 *   }]
 * }
 */
router.get(
  "/sbom/details",
  auth(["admin", "project_user", "team_user"]),
  getSbomDetails
);

/**
 * GET /api/summary/sbom/summary
 * Returns SBOM summary statistics
 * Query Params:
 *   - scanId (optional): Filter by specific scan ID
 * Response: {
 *   success: true,
 *   data: {
 *     totalComponents: 150,
 *     componentTypes: { library: 120, framework: 20, application: 10 },
 *     scopes: { required: 140, optional: 10 },
 *     topGroups: [{ group: "@rails", count: 3 }, ...]
 *   }
 * }
 */
router.get(
  "/sbom/summary",
  auth(["admin", "project_user", "team_user"]),
  getSbomSummary
);

module.exports = router;