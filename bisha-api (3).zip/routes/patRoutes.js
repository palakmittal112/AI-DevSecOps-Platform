const express = require('express');
const router = express.Router();
const patController = require('../controllers/patController');
const auth = require('../config/authPat'); //  existing auth middleware

router.post('/pat', auth(['admin']), patController.generatePAT); // Require authentication to create PATs
router.delete('/:token', auth(['admin']), patController.deletePAT); // authentication needed for deletion

module.exports = router;