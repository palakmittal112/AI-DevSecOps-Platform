const express = require('express');
const router = express.Router();
const scanResultsController = require('../controllers/rawScanResultsController')

router.get('/scan-results', scanResultsController.getAllScanResultsGroupedByTool);


module.exports = router;
