const express = require('express');
const router = express.Router();
const controller = require('../controllers/deduplicatedScanResultsController');

// GET /api/scan-results-deduplicated
router.get('/deduplicated', controller.getAllScanResults);


module.exports = router;
