const Data = require('../models/dataModel');
const Project = require('../models/projectModel');

exports.createSecretScanReport = async (req, res) => {
    try {
        const { projectId, branchName } = req.params;
        const data = req.body; // Read JSON data directly from the request body
          
        if (!data || !data.results || !Array.isArray(data.results)) {
            return res.status(400).json({ error: 'Invalid data format. Expected a JSON with a "results" array.' });
          }
        
        const project = await Project.findById(projectId);
        if (!project) return res.status(404).json({ message: 'Project not found' });
        
        // data.results.forEach((result) => {
        //     const newData = new Data({ ...data.results[result], project: project._id, branch: branchName });
        //     secretIssues.push(newData);
        // });

        // await Data.insertMany(secretIssues);

        // // await newData.save();
        // // res.status(201).json(newData);
        // res.status(201).json({ message: "Secret issues stored successfully" });


       
      
          const secrets = data.results.map(secret => ({
            ...secret,
            projectId: projectId,
            branch: branchName,
            state: 'open' // Default state
          }));
          // console.log(secrets)
      
          if (secrets.length === 0) {
            return res.status(200).json({ message: 'No secrets to store.' });
          }
      
          await Data.insertMany(secrets);
          res.status(201).json({ message: "Secret issues stored successfully" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getSecretReport = async (req, res) => {
  try {
    const { projectId, branch } = req.params;
    const secretReport = await Data.find({ projectId: projectId, branch: branch });
    res.status(200).json(secretReport);
  } catch (error) {
    res.status(500).json({ error: error.message });
  } 
  
}

exports.getAllSecretReports = async (req, res) => {
  try {
    const secretReports = await Data.find({}); // No filter
    res.status(200).json(secretReports);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createOrUpdateSecretScanReport = async (req, res) => {
    try {
        const { projectId, branch } = req.params;
        const data = req.body; // Read JSON data directly from the request body
          
        if (!data || !Array.isArray(data)) {
            return res.status(400).json({ error: 'Invalid data format. Expected a JSON with a "results" array.' });
          }
        
        const project = await Project.findById(projectId);
        if (!project) return res.status(404).json({ message: 'Project not found' });

        const secrets = data.map(secret => ({
            ...secret,
            projectId: projectId,
            branch: branch,
            state: 'open' // Default state
          }));
        // console.log(secrets);
        const existingSecrets = await Data.find({ projectId: projectId, branch: branch });
        // console.log(existingSecrets);

        if(!existingSecrets || existingSecrets.length == 0)
        {

        }


        // Process new secrets and update existing ones
        const newSecrets = [];
        const updatedSecrets = [];
        const fixedSecrets = [];
  
        for (const secret of secrets) {
          const existingSecret = existingSecrets.find(
            (s) =>
              s.Secret === secret.Secret &&
              s.StartLine === secret.StartLine &&
              s.Commit === secret.Commit &&
              s.Author === secret.Author &&
              s.File === secret.File &&
              s.Email === secret.Email &&
              s.Fingerprint === secret.Fingerprint &&
              s.RuleID === secret.RuleID
          );
  
          if (!existingSecret) {
            // New secret found, add it to the newSecrets array
            newSecrets.push(secret);
          } else {
            // Existing secret found, update if needed (or keep state as open)
            updatedSecrets.push(existingSecret);
          }
        }
  
        // Find secrets in the database that are not in the current request (fixed secrets).
        for(const existingSecret of existingSecrets){
            const stillActive = secrets.find(s=> s.Secret === existingSecret.Secret && s.StartLine === existingSecret.StartLine && s.Commit === existingSecret.Commit && s.Author === existingSecret.Author && s.File === existingSecret.File && s.Email === existingSecret.Email && s.Fingerprint === existingSecret.Fingerprint && s.RuleID === existingSecret.RuleID);
            if(!stillActive){
                fixedSecrets.push({...existingSecret, state: "fixed"});
            }
        }
        // console.log(fixedSecrets);
  
        // Insert new secrets
        if (newSecrets.length > 0) {
          await Data.insertMany(newSecrets);
        }
  
        //Update fixed secrets.
        if(fixedSecrets.length > 0){
          for(const fixedSecret of fixedSecrets){
            // console.log("fixedSecret", fixedSecret);

            // await Data.findOneAndUpdate({ _id: fixedSecret._id }, { $set: { state: "fixed" } });
            // const vulnItem = await Data.findById({_id: fixedSecret._doc._id});
            // vulnItem.state = "fixed";
            // console.log("VulItem", vulnItem);
            await Data.findByIdAndUpdate(fixedSecret._doc._id, { state: "fixed" });
          }
        }

        if(updatedSecrets.length > 0){
          for(const updateSecret of updatedSecrets){
            // console.log("updateSecret", updateSecret);

            // await Data.findOneAndUpdate({ _id: fixedSecret._id }, { $set: { state: "fixed" } });
            // const vulnItem = await Data.findById({_id: fixedSecret._doc._id});
            // vulnItem.state = "fixed";
            // console.log("VulItem", vulnItem);
            await Data.findByIdAndUpdate(updateSecret._id, { state: "open" });
          }
        }
  
        res.status(200).json({
          message: 'Secrets processed successfully',
          newSecrets: newSecrets.length,
          updatedSecrets: updatedSecrets.length,
          fixedSecrets: fixedSecrets.length,
        });
      } catch (error) {
        console.error('Error processing secrets:', error);
        res.status(500).json({ error: 'Failed to process secrets.' });
      }
};

exports.updateSecretScanReport = async (req, res) => {
    try {
        const updatedData = await Data.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedData);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.deleteSecretScanReport = async (req, res) => {
    try {
        await Data.findByIdAndDelete(req.params.id);
        res.json({ message: 'Secret Scan Report deleted' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};