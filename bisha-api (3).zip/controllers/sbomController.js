
const express = require('express');
const router = express.Router();
const SBOM = require('../models/sbomModel');


exports.createSBOM = async (req, res) => {
  try {
    const sbomData = req.body;
    const projectName = sbomData.projectName;
    const branchName = sbomData.branchName;

    const components = sbomData.components.map(component => ({
      libraryName: component.name,
      version: component.version,
      reference: component['bom-ref'],
      license: component.licenses ? component.licenses[0].id : 'Unknown',
      purl: component.purl,
      otherDetails: component,
      projectName: projectName,
      branchName: branchName
    }));

    const newSBOMs = await SBOM.insertMany(components);
    res.status(201).json(newSBOMs);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateSBOM = async (req, res) => {
  try {
    const updatedSBOM = await SBOM.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedSBOM);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteSBOM = async (req, res) => {
  try {
    await SBOM.findByIdAndDelete(req.params.id);
    res.json({ message: 'SBOM deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getSBOM = async (req, res) => {
  try {
    const sbom = await SBOM.findById(req.params.id);
    res.json(sbom);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getAllSBOM = async (req, res) => {
  try {
    const sbom = await SBOM.find({});
    res.json(sbom);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getSBOMByProjectAndBranch = async (req, res) => {
  try {
    const { project, branch } = req.params;
    // const sboms = await SBOM.find({ 'projectName': projectName, 'branchName': branchName });
    const allComponents = await SBOM.find({
      branch: branch,
      project: project
    });
    // res.json(sboms);
    res.status(200).json(allComponents);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};



// exports.createOrUpdateSBOM = async (req, res) => {
//   const sbomData = req.body;
//   console.log(sbomData)
//   const { branch, project } = req.params;
//   const components = sbomData.components;
//   let newComponents = 0;
//   let updatedComponents = 0;
//   let deletedComponents = 0;

//   for (const comp of components) {
//     const existingComponent = await SBOM.findOne({
//       libraryName: comp.name,
//       version: comp.version,
//       branch: branch,
//       project: project
//     });

//     if (existingComponent) {
//       existingComponent.state = 'updated';
//       existingComponent.rawData = comp;
//       existingComponent.purl = comp.purl;
//       existingComponent.license = comp.licenses ? comp.licenses[0].id : '';
//       await existingComponent.save();
//       updatedComponents++;
//     } else {
//       const newComponent = new SBOM({
//         libraryName: comp.name,
//         version: comp.version,
//         branch: branch,
//         project: project,
//         purl: comp.purl,
//         license: comp.licenses ? comp.licenses[0].id : '',
//         rawData: comp,
//         state: 'created'
//       });
//       await newComponent.save();
//       newComponents++;
//     }
//   }

//   // Mark components as deleted if they are not in the new request
//   const allComponents = await SBOM.find({
//     branch: branch,
//     project: project
//   });

//   for (const comp of allComponents) {
//     if (!components.some(c => c.name === comp.libraryName && c.version === comp.version)) {
//       comp.state = 'deleted';
//       await comp.save();
//       deletedComponents++;
//     }
//   }

//   res.json({
//     message: 'Components processed',
//     newComponents,
//     updatedComponents,
//     deletedComponents
//   });
// };




exports.createOrUpdateSBOM = async (req, res) => {
  try {
    // console.log(sbomData)
    const { branch, project } = req.params;
    const sbomData = req.body;
    const components = sbomData.components;
    const dependencies = sbomData.dependencies;
    let newComponents = 0;
    let updatedComponents = 0;
    let deletedComponents = 0;

    // Create a map to store component references by bomRef
    const componentMap = new Map();

    // First pass: create or update components without dependencies
    for (const comp of components) {
      let existingComponent = await SBOM.findOne({
        libraryName: comp.name,
        version: comp.version,
        branch: branch,
        project: project
      });

      if (existingComponent) {
        existingComponent.state = 'updated';
        existingComponent.rawData = comp;
        existingComponent.purl = comp.purl;
        existingComponent.license = comp.licenses ? comp.licenses[0].id : '';
        existingComponent.description = comp.description || '';
        existingComponent.lastUpdated = Date.now();
        existingComponent.bomRef = comp['bom-ref'];
        await existingComponent.save();
        updatedComponents++;
      } else {
        existingComponent = new SBOM({
          libraryName: comp.name,
          version: comp.version,
          branch: branch,
          project: project,
          purl: comp.purl,
          license: comp.licenses ? comp.licenses[0].id : '',
          description: comp.description || '',
          rawData: comp,
          state: 'created',
          firstFound: Date.now(),
          lastUpdated: Date.now(),
          bomRef: comp['bom-ref']
        });
        await existingComponent.save();
        newComponents++;
      }

      componentMap.set(comp['bom-ref'], existingComponent);
    }

    // Second pass: update dependencies
    for (const dep of dependencies) {
      if(dep.ref){
        // console.log(dep.ref);
      const parentComponent = componentMap.get(dep.ref);
      if (parentComponent) {
        parentComponent.dependencies = dep.dependsOn.map(depRef => componentMap.get(depRef)._id);
        await parentComponent.save();
      }
      else{
        // console.error('Dep ref not defined:', dep)
      }
      }
    }

    // Mark components as deleted if they are not in the new request
    const allComponents = await SBOM.find({
      branch: branch,
      project: project
    });

    for (const comp of allComponents) {
      if (!components.some(c => c.name === comp.libraryName && c.version === comp.version)) {
        comp.state = 'deleted';
        comp.lastUpdated = Date.now();
        await comp.save();
        deletedComponents++;
      }
    }

    res.json({
      message: 'Components processed',
      newComponents,
      updatedComponents,
      deletedComponents
    });

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};




