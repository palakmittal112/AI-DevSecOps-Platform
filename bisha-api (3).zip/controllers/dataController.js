const Data = require('../models/dataModel');

exports.createData = async (req, res) => {
    try {
        const newData = new Data(req.body);
        await newData.save();
        res.status(201).json(newData);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};