const Project = require('../models/projectModel');
const mongoose = require('mongoose');

/**
 * Create a new project
 * Automatically attaches the authenticated user's ID to the project
 */
exports.createProject = async (req, res) => {
    try {
        const authenticatedUserId = req.user._id;

        // Get the project data from the request body
        const projectData = {
            ...req.body,
            userId: authenticatedUserId.toString() // Always attach the authenticated user's ID as string
        };

        // Create the new project instance
        const project = new Project(projectData);

        // Save the project to the database
        const createdProject = await project.save();

        // Respond with the created project
        res.status(201).json({
            success: true,
            data: createdProject
        });

    } catch (error) {
        console.error('Error creating project:', error);

        // Handle specific Mongoose errors
        if (error.code === 11000) {
            // Duplicate key error
            return res.status(400).json({ 
                success: false,
                message: 'Project with this name already exists.' 
            });
        }
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ 
                success: false,
                message: messages.join(', ') 
            });
        }

        res.status(500).json({ 
            success: false,
            message: 'Server Error' 
        });
    }
};

/**
 * Update an existing project
 * Only allows updating projects that belong to the authenticated user
 */
exports.updateProject = async (req, res) => {
    try {
        const projectId = req.params.id;
        const authenticatedUserId = req.user._id.toString();

        // First, find the project to verify ownership
        const existingProject = await Project.findById(projectId);

        if (!existingProject) {
            return res.status(404).json({ 
                success: false,
                message: 'Project not found' 
            });
        }

        // Check if the user owns this project
        if (existingProject.userId !== authenticatedUserId) {
            return res.status(403).json({ 
                success: false,
                message: 'You do not have permission to update this project' 
            });
        }

        // Prevent userId from being modified
        const { userId, ...updateData } = req.body;

        // Update the project
        const updatedProject = await Project.findByIdAndUpdate(
            projectId, 
            updateData, 
            { new: true, runValidators: true }
        );

        res.status(200).json({
            success: true,
            data: updatedProject
        });

    } catch (error) {
        console.error('Error updating project:', error);
        
        if (error.name === 'CastError') {
            return res.status(400).json({ 
                success: false,
                message: 'Invalid project ID' 
            });
        }

        res.status(500).json({ 
            success: false,
            message: 'Server Error' 
        });
    }
};

/**
 * Delete a project
 * Only allows deleting projects that belong to the authenticated user
 */
exports.deleteProject = async (req, res) => {
    try {
        const projectId = req.params.id;
        const authenticatedUserId = req.user._id.toString();

        // First, find the project to verify ownership
        const existingProject = await Project.findById(projectId);

        if (!existingProject) {
            return res.status(404).json({ 
                success: false,
                message: 'Project not found' 
            });
        }

        // Check if the user owns this project
        if (existingProject.userId !== authenticatedUserId) {
            return res.status(403).json({ 
                success: false,
                message: 'You do not have permission to delete this project' 
            });
        }

        // Delete the project
        await Project.findByIdAndDelete(projectId);

        res.status(200).json({ 
            success: true,
            message: 'Project deleted successfully' 
        });

    } catch (error) {
        console.error('Error deleting project:', error);
        
        if (error.name === 'CastError') {
            return res.status(400).json({ 
                success: false,
                message: 'Invalid project ID' 
            });
        }

        res.status(500).json({ 
            success: false,
            message: 'Server Error' 
        });
    }
};

/**
 * Get a single project by ID
 * Only allows viewing projects that belong to the authenticated user
 */
exports.getProject = async (req, res) => {
    try {
        const projectId = req.params.id;
        const authenticatedUserId = req.user._id.toString();

        // Find the project
        const project = await Project.findById(projectId);

        if (!project) {
            return res.status(404).json({ 
                success: false,
                message: 'Project not found' 
            });
        }

        // Check if the user owns this project
        if (project.userId !== authenticatedUserId) {
            return res.status(403).json({ 
                success: false,
                message: 'You do not have permission to view this project' 
            });
        }

        res.status(200).json({
            success: true,
            data: project
        });

    } catch (error) {
        console.error('Error fetching project:', error);
        
        if (error.name === 'CastError') {
            return res.status(400).json({ 
                success: false,
                message: 'Invalid project ID' 
            });
        }

        res.status(500).json({ 
            success: false,
            message: 'Server Error' 
        });
    }
};

/**
 * Get all projects for the authenticated user
 * Returns all projects where userId matches the authenticated user's ID
 * This endpoint shows all projects in the projects page
 */
exports.getProjectsByUser = async (req, res) => {
    try {
        const authenticatedUserId = req.user._id.toString();

        console.log('Fetching projects for user:', authenticatedUserId);

        // Find all projects where userId matches (as string)
        // The userId field in your MongoDB is stored as a string
        const projects = await Project.find({ 
            userId: authenticatedUserId 
        }).sort({ created_at: -1 }); // Sort by creation date, newest first

        console.log(`Found ${projects.length} projects for user ${authenticatedUserId}`);

        // Return projects even if empty array
        res.status(200).json({
            success: true,
            count: projects.length,
            data: projects
        });

    } catch (error) {
        console.error('Error fetching projects by user:', error);
        
        res.status(500).json({ 
            success: false,
            message: 'Server Error',
            error: error.message
        });
    }
};

/**
 * Get all projects (admin function - optional)
 * Remove this if you don't need it
 */
exports.getAllProjects = async (req, res) => {
    try {
        const projects = await Project.find().sort({ created_at: -1 });

        res.status(200).json({
            success: true,
            count: projects.length,
            data: projects
        });

    } catch (error) {
        console.error('Error fetching all projects:', error);
        
        res.status(500).json({ 
            success: false,
            message: 'Server Error' 
        });
    }
};