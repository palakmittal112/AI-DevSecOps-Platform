const Data = require('../models/dataModel'); 
const SBOM = require('../models/sbomModel'); 
const SCAVulnerability = require('../models/scaVulnerabilityModel'); 
const CSVulnerability = require('../models/csModel'); 
// Add other models as needed
// const SASTModel = require('../models/sastModel');
// const DASTModel = require('../models/dastModel');
// const IaCModel = require('../models/iacModel');

/**
 * Unified Reports Controller
 * Aggregates vulnerabilities from all scan types
 */

// Get all reports across all scan types with filtering
exports.getAllReports = async (req, res) => {
  try {
    const { projectId, branch, scanType, severity, status } = req.query;
    
    const reports = [];
    
    // Secret Scan Reports
    if (!scanType || scanType === 'Secret Scan') {
      const secretQuery = {};
      if (projectId) secretQuery.projectId = projectId;
      if (branch) secretQuery.branch = branch;
      if (status) secretQuery.state = status.toLowerCase();
      
      const secrets = await Data.find(secretQuery).lean();
      
      secrets.forEach(secret => {
        const mappedSeverity = mapSecretSeverity(secret);
        
        // Apply severity filter
        if (severity && mappedSeverity.toLowerCase() !== severity.toLowerCase()) {
          return;
        }
        
        reports.push({
          _id: secret._id,
          title: `${secret.RuleID || 'Secret'} Detected`,
          severity: mappedSeverity,
          cvssScore: calculateSecretCVSS(mappedSeverity),
          file: secret.File || 'N/A',
          line: secret.StartLine || 0,
          identified: secret.Date || secret.createdAt,
          scanType: 'Secret Scan',
          status: mapStatus(secret.state),
          description: `Secret found in ${secret.File || 'file'}`,
          details: {
            author: secret.Author,
            email: secret.Email,
            commit: secret.Commit,
            fingerprint: secret.Fingerprint,
            ruleId: secret.RuleID,
            secret: secret.Secret ? '***' + secret.Secret.substring(secret.Secret.length - 4) : 'N/A'
          },
          projectId: secret.projectId,
          branch: secret.branch
        });
      });
    }
    
    // Container Scan (CS) Reports
    if (!scanType || scanType === 'CS') {
      const csQuery = {};
      if (projectId) csQuery.Project = projectId;
      if (branch) csQuery.Branch = branch;
      if (severity) csQuery.Severity = severity.toUpperCase();
      if (status) csQuery.State = status.toLowerCase();
      
      const csVulns = await CSVulnerability.find(csQuery).lean();
      
      csVulns.forEach(vuln => {
        reports.push({
          _id: vuln._id,
          title: vuln.Title || vuln.VulnerabilityID,
          severity: normalizeSeverity(vuln.Severity),
          cvssScore: extractCVSSScore(vuln.CVSS),
          file: vuln.Target || 'N/A',
          line: 0,
          identified: vuln.createdAt,
          scanType: 'CS',
          status: mapStatus(vuln.State),
          description: vuln.Description || 'Container vulnerability detected',
          details: {
            vulnerabilityId: vuln.VulnerabilityID,
            pkgName: vuln.PkgName,
            pkgId: vuln.PkgID,
            installedVersion: vuln.InstalledVersion,
            target: vuln.Target,
            class: vuln.Class,
            type: vuln.Type,
            primaryUrl: vuln.PrimaryURL,
            references: vuln.References,
            lastSeen: vuln.LastSeen
          },
          projectId: vuln.Project,
          branch: vuln.Branch
        });
      });
    }
    
    // SCA Reports - Vulnerabilities
    if (!scanType || scanType === 'SCA') {
      const scaQuery = {};
      if (projectId) scaQuery.projectId = projectId;
      if (branch) scaQuery.branchName = branch;
      if (severity) scaQuery.severity = severity;
      if (status) scaQuery.state = status.toLowerCase();
      
      const scaVulns = await SCAVulnerability.find(scaQuery).lean();
      
      scaVulns.forEach(vuln => {
        reports.push({
          _id: vuln._id,
          title: vuln.title || `${vuln.packageName} - ${vuln.vulnerabilityId}`,
          severity: normalizeSeverity(vuln.severity),
          cvssScore: parseSeverityToCVSS(vuln.severity),
          file: vuln.packageName || 'N/A',
          line: 0,
          identified: vuln.identifiedDate || vuln.createdAt,
          scanType: 'SCA',
          status: mapStatus(vuln.state),
          description: vuln.summary || vuln.details || 'Dependency vulnerability detected',
          details: {
            packageName: vuln.packageName,
            version: vuln.version,
            ecosystem: vuln.ecosystem,
            vulnerabilityId: vuln.vulnerabilityId,
            aliases: vuln.aliases,
            fixedVersion: vuln.fixedVersion,
            affectedVersions: vuln.affectedVersions,
            references: vuln.references,
            falsePositive: vuln.falsePositive,
            riskAccepted: vuln.riskAccepted,
            notes: vuln.notes
          },
          projectId: vuln.projectId,
          branch: vuln.branchName
        });
      });
    }
    
    // SBOM Components (optional - can be included as informational)
    // Uncomment if you want to show SBOM components as well
    /*
    if (!scanType || scanType === 'SCA') {
      const sbomQuery = {};
      if (projectId) sbomQuery.project = projectId;
      if (branch) sbomQuery.branch = branch;
      
      const sbomComponents = await SBOM.find(sbomQuery).lean();
      
      sbomComponents.forEach(comp => {
        if (comp.state !== 'deleted') {
          reports.push({
            _id: comp._id,
            title: `Component: ${comp.libraryName} ${comp.version}`,
            severity: 'Low',
            cvssScore: 0,
            file: comp.purl || comp.libraryName,
            line: 0,
            identified: comp.firstFound || comp.createdAt,
            scanType: 'SCA',
            status: mapStatus(comp.state),
            description: comp.description || `Component: ${comp.libraryName} with license ${comp.license}`,
            details: {
              libraryName: comp.libraryName,
              version: comp.version,
              license: comp.license,
              purl: comp.purl,
              bomRef: comp.bomRef,
              dependencies: comp.dependencies
            },
            projectId: comp.project,
            branch: comp.branch
          });
        }
      });
    }
    */
    
    // Add SAST, DAST, IaC reports here following the same pattern
    // if (!scanType || scanType === 'SAST') { ... }
    // if (!scanType || scanType === 'DAST') { ... }
    // if (!scanType || scanType === 'IaC') { ... }
    
    // Calculate statistics
    const stats = calculateStats(reports);
    
    // Sort by identified date (newest first) and then by severity
    reports.sort((a, b) => {
      const severityOrder = { 'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3, 'Unknown': 4 };
      const severityDiff = severityOrder[a.severity] - severityOrder[b.severity];
      if (severityDiff !== 0) return severityDiff;
      return new Date(b.identified).getTime() - new Date(a.identified).getTime();
    });
    
    res.status(200).json({
      success: true,
      data: reports,
      stats
    });
    
  } catch (error) {
    console.error('Error fetching reports:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching reports',
      error: error.message
    });
  }
};

// Get reports by project and branch
exports.getReportsByProject = async (req, res) => {
  try {
    const { projectId, branch } = req.params;
    const { scanType, severity, status } = req.query;
    
    // Add project and branch to query
    req.query.projectId = projectId;
    req.query.branch = branch;
    
    await exports.getAllReports(req, res);
    
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching project reports',
      error: error.message
    });
  }
};

// Get statistics for dashboard
exports.getStatistics = async (req, res) => {
  try {
    const { projectId, branch } = req.query;
    
    const filters = {};
    if (projectId) filters.projectId = projectId;
    if (branch) filters.branch = branch;
    
    const stats = {
      secretScan: await getSecretScanStats(filters),
      containerScan: await getContainerScanStats(filters),
      sca: await getSCAStats(filters),
      overall: {
        total: 0,
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        unknown: 0,
        open: 0,
        fixed: 0,
        fixedThisWeek: 0
      }
    };
    
    // Aggregate overall stats
    Object.keys(stats).forEach(key => {
      if (key !== 'overall') {
        stats.overall.total += stats[key].total;
        stats.overall.critical += stats[key].critical;
        stats.overall.high += stats[key].high;
        stats.overall.medium += stats[key].medium;
        stats.overall.low += stats[key].low;
        stats.overall.unknown += stats[key].unknown || 0;
        stats.overall.open += stats[key].open;
        stats.overall.fixed += stats[key].fixed;
        stats.overall.fixedThisWeek += stats[key].fixedThisWeek;
      }
    });
    
    res.status(200).json({
      success: true,
      stats
    });
    
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching statistics',
      error: error.message
    });
  }
};

// Helper Functions

function mapSecretSeverity(secret) {
  // Determine severity based on rule or default to Critical for secrets
  if (secret.RuleID) {
    const ruleId = secret.RuleID.toLowerCase();
    if (ruleId.includes('high')) return 'High';
    if (ruleId.includes('medium')) return 'Medium';
    if (ruleId.includes('low')) return 'Low';
  }
  return 'Critical'; // Default for secrets
}

function calculateSecretCVSS(severity) {
  const severityMap = {
    'Critical': 9.5,
    'High': 7.5,
    'Medium': 5.0,
    'Low': 3.0
  };
  return severityMap[severity] || 9.5;
}

function extractCVSSScore(cvss) {
  if (!cvss) return 0;
  
  // Try to extract score from various CVSS formats
  if (typeof cvss === 'number') return cvss;
  if (cvss.V3Score) return cvss.V3Score;
  if (cvss.V2Score) return cvss.V2Score;
  if (cvss.score) return cvss.score;
  
  // If CVSS is an array, try to get the first one
  if (Array.isArray(cvss) && cvss.length > 0) {
    return extractCVSSScore(cvss[0]);
  }
  
  return 0;
}

function normalizeSeverity(severity) {
  if (!severity) return 'Unknown';
  
  const sev = severity.toUpperCase();
  
  // Map various severity formats to standard ones
  if (sev === 'CRITICAL') return 'Critical';
  if (sev === 'HIGH') return 'High';
  if (sev === 'MEDIUM' || sev === 'MODERATE') return 'Medium';
  if (sev === 'LOW') return 'Low';
  
  return 'Unknown';
}

function parseSeverityToCVSS(severity) {
  const severityMap = {
    'CRITICAL': 9.0,
    'HIGH': 7.0,
    'MEDIUM': 5.0,
    'MODERATE': 5.0,
    'LOW': 3.0
  };
  
  return severityMap[severity?.toUpperCase()] || 0;
}

function mapStatus(state) {
  const statusMap = {
    'open': 'Open',
    'fixed': 'Fixed',
    'closed': 'Fixed',
    'created': 'Open',
    'updated': 'Open',
    'deleted': 'Fixed'
  };
  return statusMap[state?.toLowerCase()] || 'Open';
}

function calculateStats(reports) {
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  
  return {
    total: reports.length,
    critical: reports.filter(r => r.severity === 'Critical').length,
    high: reports.filter(r => r.severity === 'High').length,
    medium: reports.filter(r => r.severity === 'Medium').length,
    low: reports.filter(r => r.severity === 'Low').length,
    unknown: reports.filter(r => r.severity === 'Unknown').length,
    open: reports.filter(r => r.status === 'Open').length,
    fixed: reports.filter(r => r.status === 'Fixed').length,
    fixedThisWeek: reports.filter(r => {
      const identifiedDate = new Date(r.identified);
      return r.status === 'Fixed' && identifiedDate >= oneWeekAgo;
    }).length
  };
}

async function getSecretScanStats(filters) {
  const query = {};
  if (filters.projectId) query.projectId = filters.projectId;
  if (filters.branch) query.branch = filters.branch;
  
  const secrets = await Data.find(query).lean();
  const mapped = secrets.map(s => ({
    severity: mapSecretSeverity(s),
    status: mapStatus(s.state),
    identified: s.Date || s.createdAt
  }));
  
  return calculateStats(mapped);
}

async function getContainerScanStats(filters) {
  const query = {};
  if (filters.projectId) query.Project = filters.projectId;
  if (filters.branch) query.Branch = filters.branch;
  
  const vulns = await CSVulnerability.find(query).lean();
  const mapped = vulns.map(v => ({
    severity: normalizeSeverity(v.Severity),
    status: mapStatus(v.State),
    identified: v.createdAt
  }));
  
  return calculateStats(mapped);
}

async function getSCAStats(filters) {
  const query = {};
  if (filters.projectId) query.projectId = filters.projectId;
  if (filters.branch) query.branchName = filters.branch;
  
  const vulns = await SCAVulnerability.find(query).lean();
  const mapped = vulns.map(v => ({
    severity: normalizeSeverity(v.severity),
    status: mapStatus(v.state),
    identified: v.identifiedDate || v.createdAt
  }));
  
  return calculateStats(mapped);
}