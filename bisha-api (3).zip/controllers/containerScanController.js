const Vulnerability = require('../models/csModel');

exports.createOrUpdateVulnerabilities = async (req, res) => {
  try {
    const { project, branch } = req.params;
    const { Results } = req.body;
    console.log(project);
    console.log(branch);
    console.log(Results);

    if (!project || !branch || !Array.isArray(Results)) {
      
      return res.status(400).json({ message: 'Missing or invalid project, branch, or Results array.' });
    }

    const seenNow = new Set();
    const newVulnerabilities = [];
    const updatedVulnerabilities = [];
    const deletedVulnerabilities = [];

    for (const result of Results) {
      const { Target, Class, Type, Vulnerabilities } = result;

      if (!Array.isArray(Vulnerabilities)) continue;

      for (const vuln of Vulnerabilities) {
        const query = {
          VulnerabilityID: vuln.VulnerabilityID,
          Title: vuln.Title,
          InstalledVersion: vuln.InstalledVersion,
          PkgName: vuln.PkgName,
          Target,
          Class,
          Type,
          Project: project,
          Branch: branch
        };

        const update = {
          ...query,
          Description: vuln.Description || '',
          Severity: vuln.Severity || 'UNKNOWN',
          LastSeen: new Date(),
          State: 'open',
          PkgID: vuln.PkgID,
          PkgIdentifier: vuln.PkgIdentifier || {},
          CVSS: vuln.CVSS || {},
          VendorSeverity: vuln.VendorSeverity || {},
          References: vuln.References || [],
          PrimaryURL: vuln.PrimaryURL || '',
          DataSource: vuln.DataSource || {}
        };

        const existing = await Vulnerability.findOne(query);

        if (existing) {
          seenNow.add(existing._id.toString());

          if (existing.State === 'deleted' || existing.State === 'fixed') {
            update.State = 'open';
            updatedVulnerabilities.push(existing._id.toString());
          }

          await Vulnerability.updateOne({ _id: existing._id }, { $set: update });
        } else {
          const created = await Vulnerability.create(update);
          seenNow.add(created._id.toString());
          newVulnerabilities.push(created._id.toString());
        }
      }
    }

    const existingOpen = await Vulnerability.find({
      Project: project,
      Branch: branch,
      State: 'open'
    });

    for (const vuln of existingOpen) {
      if (!seenNow.has(vuln._id.toString())) {
        vuln.State = 'fixed';
        await vuln.save();
        deletedVulnerabilities.push(vuln._id.toString());
      }
    }

    return res.status(200).json({
      message: 'Container Vulnerabilities processed successfully',
      newVulnerabilities: newVulnerabilities.length,
      updatedVulnerabilities: updatedVulnerabilities.length,
      deletedVulnerabilities: deletedVulnerabilities.length
    });

  } catch (error) {
    console.error('Error syncing vulnerabilities:', error);
    return res.status(500).json({
      message: 'Internal server error',
      error: error.message
    });
  }
};

exports.getContainerScanReport = async (req, res) => {
  try {
    const { project, branch } = req.params;
    const csReport = await Vulnerability.find({ Project: project, Branch: branch });
    res.status(200).json(csReport);
  } catch (error) {
    res.status(500).json({ error: error.message });
  } 
  
}

exports.getAllContainerScanReports = async (req, res) => {
  try {
    const csReports = await Vulnerability.find({}); // No filter
    res.status(200).json(csReports);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
