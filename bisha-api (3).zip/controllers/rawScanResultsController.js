const ScanResultRaw = require('../models/rawScanResultsModel');

/**
 * GET /api/scan-results
 * Returns scan results grouped by source_tool
 */
exports.getAllScanResultsGroupedByTool = async (req, res) => {
  try {
    const { scan_type, scan_id } = req.query;

    // 🔹 Dynamic filters (optional)
    const matchStage = {};
    if (scan_type) matchStage.scan_type = scan_type;
    if (scan_id) matchStage.scan_id = scan_id;

    const results = await ScanResultRaw.aggregate([
      { $match: matchStage },

      {
        $group: {
          _id: '$source_tool',
          total_scans: { $sum: 1 },
          results: {
            $push: {
              scan_id: '$scan_id',
              scan_type: '$scan_type',
              raw_report: '$raw_report',
              metadata: '$metadata',
              created_at: '$created_at'
            }
          }
        }
      },

      {
        $project: {
          _id: 0,
          source_tool: '$_id',
          total_scans: 1,
          results: 1
        }
      },

      { $sort: { source_tool: 1 } }
    ]);

    return res.status(200).json({
      success: true,
      data: results
    });

  } catch (error) {
    console.error('Error fetching scan results:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch scan results'
    });
  }
};
