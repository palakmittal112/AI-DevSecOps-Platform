const ScanResultDeduplicated = require('../models/deduplicatedScanResultsModel');

/**
 * GET all deduplicated scan results
 * Optional filters: project_id, source_tool, severity
 */
exports.getAllScanResults = async (req, res) => {
  try {
    const { project_id, source_tool, severity } = req.query;

    const filter = {};

    if (project_id) filter.project_id = project_id;
    if (source_tool) filter.source_tool = source_tool;
    if (severity) filter.severity = severity;

    const results = await ScanResultDeduplicated
      .find(filter)
      .sort({ created_at: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      count: results.length,
      data: results
    });
  } catch (error) {
    console.error('Error fetching deduplicated scan results:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch scan results'
    });
  }
};
