const OsvReport = require('../models/osvReport');
const Project = require('../models/projectModel');

const fs = require("fs");

// ✅ Parse and store vulnerabilities from JSON file
exports.storeVulnerabilitiesFromFile = async (req, res) => {
  try {
    const { projectId, branchName } = req.params;
    const rawData = fs.readFileSync("osv-report.json");
    const data = JSON.parse(rawData);

    let vulnerabilities = [];

    data.results.forEach((result) => {
      result.packages.forEach((pkg) => {
        pkg.vulnerabilities.forEach((vuln) => {
          vulnerabilities.push({
            projectId,
            branchName,
            packageName: pkg.package.name,
            version: pkg.package.version,
            ecosystem: pkg.package.ecosystem,
            vulnerabilityId: vuln.id,
            aliases: vuln.aliases || [],
            summary: vuln.summary,
            details: vuln.details,
            severity: vuln.database_specific?.severity || "Unknown",
            affectedVersions: vuln.affected?.flatMap((aff) => aff.versions) || [],
            identifiedDate: vuln.published ? new Date(vuln.published) : null,
            lastUpdated: vuln.modified ? new Date(vuln.modified) : null,
            fixedVersion: vuln.affected?.flatMap((aff) =>
              aff.ranges?.flatMap((range) =>
                  range.events?.find((event) => event.fixed)?.fixed
              )
          )[0] || "Not Fixed",
            references: vuln.references?.map((ref) => ref.url) || [],
            affectedFunctions: vuln.affected?.flatMap(
              (aff) => aff.ecosystem_specific?.affected_functions || []
            )
          });
        });
      });
    });

    await OsvReport.insertMany(vulnerabilities);
    res.status(201).json({ message: "Vulnerabilities stored successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Parse and store vulnerabilities directly from request body
exports.storeVulnerabilities = async (req, res) => {
    try {
      const { projectId, branchName } = req.params;
      const data = req.body; // Read JSON data directly from the request body
  
      if (!data || !data.results) {
        return res.status(400).json({ error: "Invalid OSV report format" });
      }

      const project = await Project.findById(projectId);
      if (!project) return res.status(404).json({ message: 'Project not found' });
  
      let vulnerabilities = [];
  
      data.results.forEach((result) => {
        result.packages.forEach((pkg) => {
          pkg.vulnerabilities.forEach((vuln) => {
            vulnerabilities.push({
              projectId,
              branchName,
              packageName: pkg.package.name,
              version: pkg.package.version,
              ecosystem: pkg.package.ecosystem,
              vulnerabilityId: vuln.id,
              aliases: vuln.aliases || [],
              summary: vuln.summary,
              details: vuln.details,
              severity: vuln.database_specific?.severity || "Unknown",
              affectedVersions: vuln.affected?.flatMap((aff) => aff.versions) || [],
              identifiedDate: vuln.published ? new Date(vuln.published) : null,
              lastUpdated: vuln.modified ? new Date(vuln.modified) : null,
              fixedVersion: vuln.affected?.flatMap((aff) =>
                aff.ranges?.flatMap((range) =>
                    range.events?.find((event) => event.fixed)?.fixed
                )
            )[0] || "Not Fixed",
              references: vuln.references?.map((ref) => ref.url) || [],
              affectedFunctions: vuln.affected?.flatMap(
                (aff) => aff.ecosystem_specific?.affected_functions || []
              ),
              title: vuln.summary
            });
          });
        });
      });
  
      await OsvReport.insertMany(vulnerabilities);
      res.status(201).json({ message: "Vulnerabilities stored successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };


  // ✅ Parse and store vulnerabilities directly from request body
exports.storeOrUpdateVulnerabilities = async (req, res) => {
  try {
    const { projectId, branchName } = req.params;
    const data = req.body; // Read JSON data directly from the request body

    if (!data || !data.results) {
      return res.status(400).json({ error: "Invalid OSV report format" });
    }

    const project = await Project.findById(projectId);
    if (!project) return res.status(404).json({ message: 'Project not found' });

    let vulnerabilities = [];

    data.results.forEach((result) => {
      result.packages.forEach((pkg) => {
        pkg.vulnerabilities.forEach((vuln) => {
          vulnerabilities.push({
            projectId,
            branchName,
            state: "open",
            packageName: pkg.package.name,
            version: pkg.package.version,
            ecosystem: pkg.package.ecosystem,
            vulnerabilityId: vuln.id,
            aliases: vuln.aliases || [],
            summary: vuln.summary,
            details: vuln.details,
            severity: vuln.database_specific?.severity || "Unknown",
            affectedVersions: vuln.affected?.flatMap((aff) => aff.versions) || [],
            identifiedDate: vuln.published ? new Date(vuln.published) : null,
            lastUpdated: vuln.modified ? new Date(vuln.modified) : null,
            fixedVersion: vuln.affected?.flatMap((aff) =>
              aff.ranges?.flatMap((range) =>
                  range.events?.find((event) => event.fixed)?.fixed
              )
            )[0] || "Not Fixed",
            references: vuln.references?.map((ref) => ref.url) || [],
            affectedFunctions: vuln.affected?.flatMap(
              (aff) => aff.ecosystem_specific?.affected_functions || []
            ),
            title: vuln.summary
          });
        });
      });
    });

    const existingIssues = await OsvReport.find({ projectId: projectId, branchName: branchName });

      // Process new secrets and update existing ones
      const newVulnerabilities = [];
      const updatedVulnerabilities = [];
      const fixedVulnerabilities = [];

      for (const vulnerability of vulnerabilities) {
        const existingIssue = existingIssues.find(
          (s) =>
            s.packageName === vulnerability.packageName &&
            s.version === vulnerability.version &&
            s.ecosystem === vulnerability.ecosystem &&
            s.vulnerabilityId === vulnerability.vulnerabilityId &&
            s.summary === vulnerability.summary &&
            s.severity === vulnerability.severity 
        );

        if (!existingIssue) {
          // New issue found, add it to the newVulnerability array
          newVulnerabilities.push(vulnerability);
        } else {
          // Existing issue found, update if needed (or keep state as open)
          updatedVulnerabilities.push(existingIssue);
        }
      }

      // Find secrets in the database that are not in the current request (fixed secrets).
      for(const existingIssue of existingIssues){
        const stillActive = vulnerabilities.find(s=> s.packageName === existingIssue.packageName &&
          s.version === existingIssue.version &&
          s.ecosystem === existingIssue.ecosystem &&
          s.vulnerabilityId === existingIssue.vulnerabilityId &&
          s.summary === existingIssue.summary &&
          s.severity === existingIssue.severity );
        if(!stillActive){
          fixedVulnerabilities.push(existingIssue);
        }
    }

     // Insert new secrets
            if (newVulnerabilities.length > 0) {
              await OsvReport.insertMany(newVulnerabilities);
            }

    //Update fixed secrets.
            if(fixedVulnerabilities.length > 0){
              for(const fixedVuln of fixedVulnerabilities){
                // console.log("fixedSecret", fixedSecret);
    
                // await Data.findOneAndUpdate({ _id: fixedSecret._id }, { $set: { state: "fixed" } });
                // const vulnItem = await Data.findById({_id: fixedSecret._doc._id});
                // vulnItem.state = "fixed";
                // console.log("VulItem", vulnItem);
                await OsvReport.findByIdAndUpdate(fixedVuln._id, { state: "fixed" });
              }
            }
    
            if(updatedVulnerabilities.length > 0){
              for(const updatedVulnerability of updatedVulnerabilities){
                // console.log("updateSecret", updatedVulnerability);
    
                // await Data.findOneAndUpdate({ _id: fixedSecret._id }, { $set: { state: "fixed" } });
                // const vulnItem = await Data.findById({_id: fixedSecret._doc._id});
                // vulnItem.state = "fixed";
                // console.log("VulItem", vulnItem);
                await OsvReport.findByIdAndUpdate(updatedVulnerability._id, { state: "open" });
              }
            }
      
            res.status(200).json({
              message: 'Vulnerabilities processed successfully',
              newVulnerabilities: newVulnerabilities.length,
              updatedVulnerabilities: updatedVulnerabilities.length,
              fixedVulnerabilities: fixedVulnerabilities.length,
            });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Fetch vulnerabilities by project and branch
exports.getVulnerabilities = async (req, res) => {
  try {
    const { projectName, branchName } = req.params;
    const vulnerabilities = await OsvReport.find({ projectName, branchName });

    res.status(200).json(vulnerabilities);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getAllVulnerabilities = async (req, res) => {
  try {
    const vulnerabilities = await OsvReport.find({}); // No filter
    res.status(200).json(vulnerabilities);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// ✅ Update a vulnerability
exports.updateVulnerability = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;
    
    const updatedVulnerability = await OsvReport.findByIdAndUpdate(id, updatedData, { new: true });

    if (!updatedVulnerability) {
      return res.status(404).json({ message: "Vulnerability not found" });
    }

    res.status(200).json(updatedVulnerability);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Delete a vulnerability
exports.deleteVulnerability = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedVulnerability = await OsvReport.findByIdAndDelete(id);

    if (!deletedVulnerability) {
      return res.status(404).json({ message: "Vulnerability not found" });
    }

    res.status(200).json({ message: "Vulnerability deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
