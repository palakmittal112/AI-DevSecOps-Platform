const PAT = require('../models/patModel');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const generatePAT = async (req, res) => {
  try {
    const rawToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = await bcrypt.hash(rawToken, 10);

    const pat = new PAT({
      token: hashedToken,
      userId: req.user ? req.user._id : null, // Optional: Link to user
      description: req.body.description,
      expiresAt: req.body.expiresAt,
    });

    await pat.save();

    res.status(201).json({ token: rawToken }); // Send the raw token once.
  } catch (error) {
    res.status(500).json({ message: 'Error generating PAT', error: error.message });
  }
};

const deletePAT = async (req, res) => {
  try {
    const pat = await PAT.findOneAndDelete({ token: req.params.token });

    if (!pat) {
      return res.status(404).json({ message: 'PAT not found' });
    }

    res.status(200).json({ message: 'PAT deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting PAT', error: error.message });
  }
};

module.exports = { generatePAT, deletePAT };