const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

const auth1 = (roles = []) => {
    if (typeof roles === 'string') {
        roles = [roles];
    }

    return [
        (req, res, next) => {
            const token = req.header('Authorization').replace('Bearer ', '');
            if (!token) return res.status(401).json({ message: 'Access Denied' });

            try {
                const verified = jwt.verify(token, 'secretkey');
                req.user = verified;
                next();
            } catch (err) {
                res.status(400).json({ message: 'Invalid Token' });
            }
        },
        async (req, res, next) => {
            // console.log(req.user);
            const user = await User.findById(req.user._id);
            // console.log(user);
            if (!roles.length || roles.includes(user.role)) {
                req.user = user;
                next();
            } else {
                res.status(403).json({ message: 'Forbidden' });
            }
        }
    ];
};

module.exports = auth1;