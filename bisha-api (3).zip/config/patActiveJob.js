const cron = require('node-cron');
const PAT = require('../models/patModel');

function setPatActiveJobs() {
    // Schedule a job to check for expired PATs every 6 hours
    cron.schedule('0 */6 * * *', async () => {
        try {
            const expiredPats = await PAT.find({
                expiresAt: { $lt: new Date() },
                active: true,
            });

            if (expiredPats.length > 0) {
                for (const pat of expiredPats) {
                    await PAT.updateOne({ _id: pat._id }, { $set: { active: false } });
                }
                console.log(`Updated ${expiredPats.length} expired PATs.`);
            }
        } catch (error) {
            console.error('Error checking for expired PATs:', error);
        }
    });
    console.log("PAT active job scheduled.");
}

module.exports = setPatActiveJobs;


// Cron Schedule String Explanation:

// The cron schedule string '0 */6 * * *' defines when the cron job will run.

// - '0' (Minute):
//     - Specifies that the job should run at minute 0 of the hour.
//     - So at the very start of the hour.

// - '*/6' (Hour):
//     - Specifies that the job should run every 6 hours.
//     - For example, 00:00, 06:00, 12:00, 18:00, etc.

// - '*' (Day of Month):
//     - Means "every day of the month".
//     - The job will run regardless of the day of the month.

// - '*' (Month):
//     - Means "every month".
//     - The job will run regardless of the month.

// - '*' (Day of Week):
//     - Means "every day of the week".
//     - The job will run regardless of the day of the week.

// In summary, '0 */6 * * *' means "Run at minute 0 of every 6th hour, every day, every month, and every day of the week."
