const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const PAT = require('../models/patModel'); // Import your PAT model
const bcrypt = require('bcryptjs');
require('dotenv').config();

// const patAllowedRoutes = JSON.parse(process.env.PAT_ALLOWED_ROUTES || '[]');

// const patAllowedRoutes = [
//     { method: 'POST', url: '/reports' },
//     { method: 'GET', url: '/reports' },
//     { method: 'POST', url: '/project' },
// ];

// const auth = (roles = []) => {
//     if (typeof roles === 'string') {
//         roles = [roles];
//     }

    

//     return [
//         async (req, res, next) => {
//             let token = req.header('Authorization');

//             if (!token) return res.status(401).json({ message: 'Access Denied' });

//             token = token.replace('Bearer ', '');

//             try {
//                 // Check if it's a JWT token
//                 if (token.split('.').length === 3) {
//                     const verified = jwt.verify(token, process.env.JWT_SECRET);
//                     console.log(verified)
//                     req.user = verified;
//                     return next();
//                 }
//                 console.log("Pat check")

//                 // Check if it's a PAT token
//                 const pat = await PAT.findOne({ active: true });

//                 if (pat) {
//                     const isMatch = await bcrypt.compare(token, pat.token);
//                     if (isMatch) {
//                         req.pat = pat;
//                         return next();
                        
                        
//                         // req.pat = pat;

//                         // Check if the route is allowed for PATs
//                         // const allowed = patAllowedRoutes.some(
//                         //     (route) => route.method === req.method && route.url === req.path
//                         // );

//                         // if (allowed) {
//                         //     return next();
//                         // } else {
//                         //     return res.status(403).json({ message: 'PAT access forbidden for this route' });
//                         // }
//                     }
//                 }

//                 return res.status(401).json({ message: 'Invalid Token' });
//             } catch (err) {
//                 res.status(400).json({ message: 'Invalid Token' });
//             }
//         },
//         async (req, res, next) => {
//             // If PAT, skip role check
//             if (req.pat) {
//                 return next();
//             }

//             const user = await User.findById(req.user._id);

//             if (!roles.length || roles.includes(user.role)) {
//                 req.user = user;
//                 next();
//             } else {
//                 res.status(403).json({ message: 'Forbidden' });
//             }
//         }
//     ];
// };

// module.exports = auth;


// const jwt = require('jsonwebtoken');
// const User = require('../models/userModel');
// const PAT = require('../models/pat.model');
// const bcrypt = require('bcrypt');

async function authenticateJWT(req, res, next) {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        return false; // No token provided
    }

    try {
        if (token.split('.').length === 3) {
            const verified = jwt.verify(token, process.env.JWT_SECRET);
            req.user = verified;
            return true; // Valid JWT
        }
        else{
            return false;
        }
    } catch (err) {
        console.error("JWT Verification Error:", err);
        // Optionally, you can send an error response here if JWT is mandatory for some routes
        // res.status(401).json({ message: 'Invalid JWT Token' });
        return false; // Invalid JWT or not a JWT format
    }
}

async function authenticatePAT(req, res) {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        return null; // No token provided
    }

    try {
        const pats = await PAT.find({ active: true });
        if (pats && pats.length > 0) {
            for (const pat of pats) {
                const isMatch = await bcrypt.compare(token, pat.token);
                if (isMatch) {
                    return pat; // Valid PAT found
                }
            }
        }
    } catch (err) {
        console.error("PAT Authentication Error:", err);
        // Optionally, you can send an error response here if PAT is mandatory for some routes
        // res.status(500).json({ message: 'Error during PAT authentication' });
        return null; // Error during PAT authentication or no valid PAT
    }
    return null; // No valid active PAT found
}

function checkPATRoutePermission(req, pat) {
    if (!pat) {
        return false; // No PAT to check against
    }

    try {
        const patAllowedRoutes = JSON.parse(process.env.PAT_ALLOWED_ROUTES || '[]');
        const requestUrl = req.path;
        const requestMethod = req.method;

        for (const routeConfig of patAllowedRoutes) {
            if (routeConfig.url && routeConfig.method === requestMethod && routeConfig.url === requestUrl) {
                return true; // Exact match
            }
            if (routeConfig.url_prefix && routeConfig.method === requestMethod && requestUrl.startsWith(routeConfig.url_prefix)) {
                return true; // Matches prefix
            }
        }
    } catch (err) {
        console.error("PAT Route Permission Check Error:", err);
        return false; // Error during permission check (default to deny)
    }
    return false; // Route not allowed for PAT
}

const auth = (roles = []) => {
    if (typeof roles === 'string') {
        roles = [roles];
    }

    return [
        async (req, res, next) => {
            try {
                const isJWTAuthenticated = await authenticateJWT(req, res, next);
                let isPATAuthenticatedAndAllowed = false;
                let pat = null;

                if (!isJWTAuthenticated) {
                    pat = await authenticatePAT(req, res);
                    if (pat) {
                        req.pat = pat;
                        isPATAuthenticatedAndAllowed = checkPATRoutePermission(req, pat);
                    }
                }

                if (isJWTAuthenticated || isPATAuthenticatedAndAllowed) {
                    return next();
                } else {
                    return res.status(401).json({ message: 'Invalid Token: Not a valid JWT or active PAT for this route' });
                }
            } catch (err) {
                console.error("Authentication Middleware Error:", err);
                res.status(500).json({ message: 'Authentication failed due to server error' });
            }
        },
        async (req, res, next) => {
            try {
                // If PAT, skip role check
                if (req.pat) {
                    return next();
                }

                const user = await User.findById(req.user._id);

                if (!user) {
                    return res.status(404).json({ message: 'User not found' });
                }

                if (!roles.length || roles.includes(user.role)) {
                    req.user = user;
                    next();
                } else {
                    res.status(403).json({ message: 'Forbidden' });
                }
            } catch (err) {
                console.error("Role Authorization Middleware Error:", err);
                res.status(500).json({ message: 'Authorization failed due to server error' });
            }
        }
    ];
};

module.exports = auth;

// PAT_ALLOWED_ROUTES=[{"method":"POST","url":"/secretScanReport/:projectId/:branch/createOrUpdate"},{"method":"GET","url":"/reports"},{"method":"POST","url":"/project"},{"method":"POST","url":"/osvReport/"},{"method":"POST","url":"/osvReport/:projectId/:branchName/storeOrUpdate"},{"method":"POST","url":"/secretScanReport"}]
