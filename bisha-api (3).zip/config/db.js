// const mongoose = require('mongoose');
// const setPatActiveJobs = require('./patActiveJob'); // Adjust path as needed

// const connectDB = async () => {
//     try {
//         await mongoose.connect('mongodb://localhost:27017/cybershield');
//         console.log('MongoDB connected...');
//         setPatActiveJobs();
//     } catch (err) {
//         console.error(err.message);
//         process.exit(1);
//     }
// };

// module.exports = connectDB;


const mongoose = require('mongoose');
const setPatActiveJobs = require('./patActiveJob'); // Adjust path as needed

const connectDB = async (mongoURI) => {
    try {
        console.log('MongoDB URI', mongoURI);
        await mongoose.connect(mongoURI);
        console.log('MongoDB connected...');
        setPatActiveJobs();
    } catch (err) {
        console.error('MongoDB connection error:',err.message);
        process.exit(1);
    }
};

module.exports = connectDB;
