require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./config/db');
const cors = require('cors');

const dataRoutes = require('./routes/dataRoutes');
const userRoutes = require('./routes/userRoutes');
const projectRoutes = require('./routes/projectRoutes');
const secretScanReportRoutes = require('./routes/secretScanReportRoutes');
const sbomRoutes = require('./routes/sbomRoutes');
const osvReportRoutes = require('./routes/osvRoutes');
const patRoutes = require('./routes/patRoutes');
const csRoutes = require('./routes/csReportRoutes');
const summaryRoutes = require('./routes/summaryRoutes');
const healthRoute = require('./routes/health');
const scanResultsRoutes = require('./routes/rawScanResultsRoutes')
const scanResultsDeduplicated = require('./routes/deduplicatedScanResultsRoutes')

const path = require('path');
const fs = require('fs');

// Prepare data directory for onboarded repos
const dataRoot = process.env.BASE_DATA_DIR || path.join(process.cwd(), 'data');
fs.mkdirSync(path.join(dataRoot, 'repos'), { recursive: true });

const app = express();

// ---- Database ----
const mongoURI = process.env.MONGO_URI || 'mongodb://localhost:27017/cybershield';
connectDB(mongoURI);

// ---- Middleware ----
app.use(bodyParser.json({ limit: '5mb' }));
app.use(cors());

// ---- Routes ----
app.use('/api', dataRoutes);
app.use('/api', userRoutes);
app.use('/api', projectRoutes);
app.use('/api', secretScanReportRoutes);
app.use('/api', sbomRoutes);
app.use('/api', osvReportRoutes);
app.use('/api', patRoutes);
app.use('/api', csRoutes);
app.use('/api', summaryRoutes);
app.use('/api', scanResultsRoutes);
app.use('/api', scanResultsDeduplicated);

// health check
app.use('/api/health', healthRoute);

// ---- Server ----
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// require('dotenv').config();

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const path = require('path');
// const fs = require('fs');

// const connectDB = require('./config/db');

// // ---- Routes ----
// const dataRoutes = require('./routes/dataRoutes');
// const userRoutes = require('./routes/userRoutes');
// const projectRoutes = require('./routes/projectRoutes');
// const secretScanReportRoutes = require('./routes/secretScanReportRoutes');
// const sbomRoutes = require('./routes/sbomRoutes');
// const osvReportRoutes = require('./routes/osvRoutes');
// const patRoutes = require('./routes/patRoutes');
// const csRoutes = require('./routes/csReportRoutes');
// const summaryRoutes = require('./routes/summaryRoutes');
// const healthRoute = require('./routes/health');

// // ---- App Init ----
// const app = express();

// // ---- Data directory setup ----
// const dataRoot = process.env.BASE_DATA_DIR || path.join(process.cwd(), 'data');
// fs.mkdirSync(path.join(dataRoot, 'repos'), { recursive: true });

// // ---- Middleware ----
// app.use(bodyParser.json({ limit: '5mb' }));
// app.use(cors());

// // ---- MongoDB Atlas Connection ----
// // MUST be Atlas URI in production
// const mongoURI = process.env.MONGO_URI;

// if (!mongoURI) {
//   console.error('❌ MONGO_URI is not defined');
//   process.exit(1);
// }

// connectDB(mongoURI);

// // ---- Routes ----
// app.use('/api', dataRoutes);
// app.use('/api', userRoutes);
// app.use('/api', projectRoutes);
// app.use('/api', secretScanReportRoutes);
// app.use('/api', sbomRoutes);
// app.use('/api', osvReportRoutes);
// app.use('/api', patRoutes);
// app.use('/api', csRoutes);
// app.use('/api', summaryRoutes);
// app.use('/api/health', healthRoute);

// // ---- Server ----
// const PORT = process.env.PORT || 5000;

// app.listen(PORT, () => {
//   console.log(`✅ Server running on port ${PORT}`);
// });
